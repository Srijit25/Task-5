import React from 'react';
import { Link } from 'react-router-dom';
import { User } from '../../types';
import styles from './UserCard.module.css';

interface UserCardProps {
  user: User;
  showFollowButton?: boolean;
  isFollowing?: boolean;
  onFollowToggle?: (userId: string) => void;
  className?: string;
}

const UserCard: React.FC<UserCardProps> = ({
  user,
  showFollowButton = false,
  isFollowing = false,
  onFollowToggle,
  className = ''
}) => {
  const handleFollowClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (onFollowToggle) {
      onFollowToggle(user.id);
    }
  };

  return (
    <div className={`${styles.userCard} ${className}`}>
      <Link to={`/profile/${user.id}`} className={styles.userLink}>
        {/* Profile Image */}
        <div className={styles.profileImageContainer}>
          {user.profileImageUrl ? (
            <img 
              src={user.profileImageUrl} 
              alt={`${user.username}'s profile`}
              className={styles.profileImage}
            />
          ) : (
            <div className={styles.profileAvatar}>
              {user.username.charAt(0).toUpperCase()}
            </div>
          )}
        </div>

        {/* User Info */}
        <div className={styles.userInfo}>
          <div className={styles.username}>
            {user.username}
          </div>
          {(user.firstName || user.lastName) && (
            <div className={styles.displayName}>
              {`${user.firstName || ''} ${user.lastName || ''}`.trim()}
            </div>
          )}
          {user.bio && (
            <div className={styles.bio}>
              {user.bio}
            </div>
          )}
          
          {/* User Stats */}
          <div className={styles.userStats}>
            <span className={styles.stat}>
              <strong>{user.followersCount || 0}</strong> followers
            </span>
            <span className={styles.stat}>
              <strong>{user.followingCount || 0}</strong> following
            </span>
            <span className={styles.stat}>
              <strong>{user.postsCount || 0}</strong> posts
            </span>
          </div>
        </div>
      </Link>

      {/* Follow Button */}
      {showFollowButton && (
        <button
          onClick={handleFollowClick}
          className={`${styles.followButton} ${isFollowing ? styles.following : styles.notFollowing}`}
        >
          {isFollowing ? 'Unfollow' : 'Follow'}
        </button>
      )}
    </div>
  );
};

export default UserCard;