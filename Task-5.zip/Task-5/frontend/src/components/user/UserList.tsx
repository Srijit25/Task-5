import React from 'react';
import { User } from '../../types';
import UserCard from './UserCard';
import styles from './UserList.module.css';

interface UserListProps {
  users: User[];
  loading?: boolean;
  error?: string;
  emptyMessage?: string;
  showFollowButtons?: boolean;
  followingUsers?: Set<string>;
  onFollowToggle?: (userId: string) => void;
  className?: string;
  variant?: 'grid' | 'list';
}

const UserList: React.FC<UserListProps> = ({
  users,
  loading = false,
  error,
  emptyMessage = 'No users found',
  showFollowButtons = false,
  followingUsers = new Set(),
  onFollowToggle,
  className = '',
  variant = 'grid'
}) => {
  if (loading) {
    return (
      <div className={`${styles.userList} ${styles[variant]} ${className}`}>
        {Array.from({ length: 6 }).map((_, index) => (
          <div key={index} className={styles.userCardSkeleton}>
            <div className={styles.skeletonAvatar}></div>
            <div className={styles.skeletonContent}>
              <div className={styles.skeletonLine}></div>
              <div className={styles.skeletonLine}></div>
              <div className={styles.skeletonLine}></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className={styles.errorContainer}>
        <div className={styles.errorIcon}>⚠️</div>
        <div className={styles.errorMessage}>
          {error}
        </div>
        <button 
          className={styles.retryButton}
          onClick={() => window.location.reload()}
        >
          Try Again
        </button>
      </div>
    );
  }

  if (users.length === 0) {
    return (
      <div className={styles.emptyContainer}>
        <div className={styles.emptyIcon}>👥</div>
        <div className={styles.emptyMessage}>
          {emptyMessage}
        </div>
      </div>
    );
  }

  return (
    <div className={`${styles.userList} ${styles[variant]} ${className}`}>
      {users.map((user) => (
        <UserCard
          key={user.id}
          user={user}
          showFollowButton={showFollowButtons}
          isFollowing={followingUsers.has(user.id)}
          onFollowToggle={onFollowToggle}
          className={variant === 'list' ? styles.listItem : ''}
        />
      ))}
    </div>
  );
};

export default UserList;