import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Tag } from './TagInput';
import styles from './TagSelector.module.css';

interface TagSelectorProps {
  availableTags: Tag[];
  selectedTags: Tag[];
  onTagsChange: (tags: Tag[]) => void;
  onSearchTags?: (query: string) => Promise<Tag[]>;
  placeholder?: string;
  multiple?: boolean;
  maxSelections?: number;
  showClearAll?: boolean;
  showSelectAll?: boolean;
  searchable?: boolean;
  groupByCategory?: boolean;
  categories?: { [key: string]: Tag[] };
  disabled?: boolean;
  error?: string;
  className?: string;
}

interface TagCategory {
  name: string;
  tags: Tag[];
}

const TagSelector: React.FC<TagSelectorProps> = ({
  availableTags = [],
  selectedTags = [],
  onTagsChange,
  onSearchTags,
  placeholder = "Search tags...",
  multiple = true,
  maxSelections,
  showClearAll = true,
  showSelectAll = true,
  searchable = true,
  groupByCategory = false,
  categories,
  disabled = false,
  error,
  className
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [allTags, setAllTags] = useState<Tag[]>(availableTags);
  const [isLoading, setIsLoading] = useState(false);
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (onSearchTags && searchQuery.trim()) {
      const fetchTags = async () => {
        setIsLoading(true);
        try {
          const searchResults = await onSearchTags(searchQuery);
          setAllTags(searchResults);
        } catch (err) {
          console.error('Error searching tags:', err);
          setAllTags([]);
        } finally {
          setIsLoading(false);
        }
      };
      const debounceTimer = setTimeout(fetchTags, 300);
      return () => clearTimeout(debounceTimer);
    } else {
      setAllTags(availableTags);
    }
  }, [searchQuery, availableTags, onSearchTags]);

  const filteredTags = useMemo(() => {
    if (!searchQuery.trim() && !onSearchTags) {
      return allTags;
    }
    return allTags.filter(tag =>
      tag.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [searchQuery, allTags, onSearchTags]);

  const organizedTags = useMemo((): TagCategory[] => {
    if (!groupByCategory || !categories) {
      return [{ name: 'All Tags', tags: filteredTags }];
    }

    const categorized: { [key: string]: Tag[] } = {};
    const uncategorized: Tag[] = [];

    for (const tag of filteredTags) {
      let found = false;
      for (const [catName, catTags] of Object.entries(categories)) {
        if (catTags.some(t => t.id === tag.id)) {
          if (!categorized[catName]) categorized[catName] = [];
          categorized[catName].push(tag);
          found = true;
          break;
        }
      }
      if (!found) uncategorized.push(tag);
    }

    const result: TagCategory[] = Object.entries(categorized).map(([name, tags]) => ({ name, tags }));
    if (uncategorized.length > 0) result.push({ name: 'Other', tags: uncategorized });

    return result;
  }, [filteredTags, groupByCategory, categories]);

  const isTagSelected = useCallback((tag: Tag) => selectedTags.some(t => t.id === tag.id), [selectedTags]);

  const handleTagToggle = (tag: Tag) => {
    if (disabled) return;
    const isSelected = isTagSelected(tag);
    
    if (isSelected) {
      onTagsChange(selectedTags.filter(t => t.id !== tag.id));
    } else if (!multiple) {
      onTagsChange([tag]);
    } else if (!maxSelections || selectedTags.length < maxSelections) {
      onTagsChange([...selectedTags, tag]);
    }
  };

  const handleSelectAll = () => {
    if (disabled) return;
    const newSelections = filteredTags.filter(t => !isTagSelected(t));
    const combined = [...selectedTags, ...newSelections];
    onTagsChange(maxSelections ? combined.slice(0, maxSelections) : combined);
  };

  const handleClearAll = () => {
    if (disabled) return;
    onTagsChange([]);
  };

  const toggleCategory = (categoryName: string) => {
    setExpandedCategories(prev => {
      const next = new Set(prev);
      if (next.has(categoryName)) next.delete(categoryName);
      else next.add(categoryName);
      return next;
    });
  };

  const canSelectMore = !maxSelections || selectedTags.length < maxSelections;

  return (
    <div className={`${styles.container} ${className || ''}`}>
      {searchable && (
        <div className={styles.searchContainer}>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={placeholder}
            className={`${styles.searchInput} ${error ? styles.error : ''}`}
            disabled={disabled}
            aria-label="Search tags"
          />
          {isLoading && <div className={styles.loadingSpinner}><div className={styles.spinner} /></div>}
        </div>
      )}

      {(showClearAll || showSelectAll) && (
        <div className={styles.actions}>
          {showSelectAll && filteredTags.length > 0 && canSelectMore && (
            <button type="button" onClick={handleSelectAll} disabled={disabled} className={styles.actionButton}>
              Select All Visible
            </button>
          )}
          {showClearAll && selectedTags.length > 0 && (
            <button type="button" onClick={handleClearAll} disabled={disabled} className={`${styles.actionButton} ${styles.clearButton}`}>
              Clear All
            </button>
          )}
        </div>
      )}

      {selectedTags.length > 0 && (
        <div className={styles.selectedSummary}>
          <span className={styles.selectedCount}>
            {selectedTags.length} selected {maxSelections && `of ${maxSelections}`}
          </span>
          <div className={styles.selectedTags}>
            {selectedTags.map(tag => (
              <span key={tag.id} className={styles.selectedTag} data-color={tag.color}>
                {tag.name}
              </span>
            ))}
          </div>
        </div>
      )}

      <div className={styles.tagsContainer}>
        {organizedTags.map(category => (
          <div key={category.name} className={styles.category}>
            {groupByCategory && organizedTags.length > 1 && (
              <button
                type="button"
                className={styles.categoryHeader}
                onClick={() => toggleCategory(category.name)}
                // eslint-disable-next-line jsx-a11y/aria-proptypes
                aria-expanded={expandedCategories.has(category.name) ? "true" : "false"}
              >
                <span className={styles.categoryName}>{category.name}</span>
                <span className={styles.categoryCount}>({category.tags.length})</span>
                <span className={`${styles.chevron} ${expandedCategories.has(category.name) ? styles.expanded : ''}`}>▼</span>
              </button>
            )}
            <div className={`${styles.categoryTags} ${!groupByCategory || expandedCategories.has(category.name) ? styles.expanded : ''}`}>
              {category.tags.map(tag => {
                const selected = isTagSelected(tag);
                const canSelect = canSelectMore || selected;
                return (
                  <button
                    key={tag.id}
                    type="button"
                    className={`${styles.tagOption} ${selected ? styles.selected : ''} ${!canSelect ? styles.disabled : ''}`}
                    onClick={() => handleTagToggle(tag)}
                    disabled={disabled || !canSelect}
                    data-color={tag.color}
                    // eslint-disable-next-line jsx-a11y/aria-proptypes
                    aria-pressed={selected ? "true" : "false"}
                  >
                    <span className={styles.tagName}>{tag.name}</span>
                    {selected && <span className={styles.checkmark}>✓</span>}
                  </button>
                );
              })}
            </div>
          </div>
        ))}

        {filteredTags.length === 0 && !isLoading && (
          <div className={styles.emptyState}>
            <span className={styles.emptyIcon}>{searchQuery ? '🔍' : '🏷️'}</span>
            <span className={styles.emptyMessage}>
              {searchQuery ? `No tags found for "${searchQuery}"` : 'No tags available'}
            </span>
          </div>
        )}
      </div>

      {error && <div className={styles.errorMessage} role="alert">{error}</div>}

      {maxSelections && (
        <div className={styles.helperText}>
          {multiple ? `Select up to ${maxSelections} tags` : 'Select one tag'}
        </div>
      )}
    </div>
  );
};

export default TagSelector;
