import React, { useState, useRef, useEffect, KeyboardEvent, useCallback } from 'react';
import styles from './TagInput.module.css';

export interface Tag {
  id: string;
  name: string;
  color?: string;
}

interface TagInputProps {
  tags: Tag[];
  onTagsChange: (tags: Tag[]) => void;
  suggestions?: Tag[];
  placeholder?: string;
  maxTags?: number;
  allowCustomTags?: boolean;
  disabled?: boolean;
  error?: string;
  className?: string;
  onInputChange?: (value: string) => void;
  onSearchTags?: (query: string) => Promise<Tag[]>;
}

const TagInput: React.FC<TagInputProps> = ({
  tags = [],
  onTagsChange,
  suggestions = [],
  placeholder = "Add tags...",
  maxTags = 10,
  allowCustomTags = true,
  disabled = false,
  error,
  className,
  onInputChange,
  onSearchTags
}) => {
  const [inputValue, setInputValue] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [filteredSuggestions, setFilteredSuggestions] = useState<Tag[]>([]);
  const [activeSuggestionIndex, setActiveSuggestionIndex] = useState(-1);
  const [isLoading, setIsLoading] = useState(false);
  
  const inputRef = useRef<HTMLInputElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const memoizedOnTagsChange = useCallback(onTagsChange, [onTagsChange]);

  useEffect(() => {
    const searchTags = async () => {
      if (!inputValue.trim()) {
        setFilteredSuggestions([]);
        setShowSuggestions(false);
        return;
      }

      setIsLoading(true);
      try {
        const searchResults = onSearchTags 
          ? await onSearchTags(inputValue)
          : suggestions.filter(s => s.name.toLowerCase().includes(inputValue.toLowerCase()));
        
        const availableSuggestions = searchResults.filter(
          suggestion => !tags.some(tag => tag.id === suggestion.id)
        );
        
        setFilteredSuggestions(availableSuggestions);
        setShowSuggestions(availableSuggestions.length > 0);
      } catch (err) {
        console.error('Error searching tags:', err);
        setFilteredSuggestions([]);
      } finally {
        setIsLoading(false);
      }
    };

    const debounceTimer = setTimeout(searchTags, 300);
    return () => clearTimeout(debounceTimer);
  }, [inputValue, suggestions, tags, onSearchTags]);

  const addTag = useCallback((tag: Tag) => {
    if (tags.length >= maxTags || tags.some(t => t.id === tag.id)) return;

    memoizedOnTagsChange([...tags, tag]);
    setInputValue('');
    setShowSuggestions(false);
    setActiveSuggestionIndex(-1);
    inputRef.current?.focus();
  }, [tags, maxTags, memoizedOnTagsChange]);

  const createNewTag = useCallback((name: string): Tag => ({
    id: `custom-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    name: name.trim(),
    color: '#3b82f6'
  }), []);

  const removeTag = useCallback((tagId: string) => {
    memoizedOnTagsChange(tags.filter(tag => tag.id !== tagId));
    inputRef.current?.focus();
  }, [tags, memoizedOnTagsChange]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setInputValue(value);
    setActiveSuggestionIndex(-1);
    onInputChange?.(value);
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (disabled) return;

    switch (e.key) {
      case 'Enter':
        e.preventDefault();
        if (activeSuggestionIndex >= 0 && filteredSuggestions[activeSuggestionIndex]) {
          addTag(filteredSuggestions[activeSuggestionIndex]);
        } else if (inputValue.trim() && allowCustomTags && tags.length < maxTags) {
          const newTag = createNewTag(inputValue);
          addTag(newTag);
        }
        break;

      case 'ArrowDown':
        e.preventDefault();
        if (showSuggestions) {
          const nextIndex = (activeSuggestionIndex + 1) % filteredSuggestions.length;
          setActiveSuggestionIndex(nextIndex);
        }
        break;

      case 'ArrowUp':
        e.preventDefault();
        if (showSuggestions) {
          const prevIndex = (activeSuggestionIndex - 1 + filteredSuggestions.length) % filteredSuggestions.length;
          setActiveSuggestionIndex(prevIndex);
        }
        break;

      case 'Escape':
        setShowSuggestions(false);
        setActiveSuggestionIndex(-1);
        break;

      case 'Backspace':
        if (!inputValue && tags.length > 0) {
          removeTag(tags[tags.length - 1].id);
        }
        break;
    }
  };

  const handleInputFocus = () => {
    if (filteredSuggestions.length > 0) {
      setShowSuggestions(true);
    }
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const isMaxTagsReached = tags.length >= maxTags;

  return (
    <div ref={containerRef} className={`${styles.container} ${className || ''}`}>
      <div className={`${styles.tagInput} ${error ? styles.error : ''} ${disabled ? styles.disabled : ''}`}>
        <div className={styles.tagsContainer}>
          {tags.map((tag) => (
            <div key={tag.id} className={styles.tag} data-color={tag.color}>
              <span className={styles.tagName}>{tag.name}</span>
              {!disabled && (
                <button
                  type="button"
                  className={styles.removeTag}
                  onClick={() => removeTag(tag.id)}
                  aria-label={`Remove ${tag.name} tag`}
                >
                  ×
                </button>
              )}
            </div>
          ))}

          {!isMaxTagsReached && (
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              onFocus={handleInputFocus}
              placeholder={tags.length === 0 ? placeholder : ''}
              className={styles.input}
              disabled={disabled}
              autoComplete="off"
              role="combobox"
              aria-expanded={showSuggestions ? "true" : "false"}
              aria-haspopup="listbox"
              aria-autocomplete="list"
              aria-label="Add tags"
              aria-controls="tag-suggestions"
              aria-activedescendant={activeSuggestionIndex >= 0 ? `suggestion-${activeSuggestionIndex}` : undefined}
            />
          )}
        </div>

        {isLoading && <div className={styles.loadingIndicator}><div className={styles.spinner} /></div>}
      </div>

      {showSuggestions && (
        <div 
          className={styles.suggestions} 
          role="listbox"
          id="tag-suggestions"
          aria-label="Tag suggestions"
        >
          {filteredSuggestions.map((suggestion, index) => (
            <div
              key={suggestion.id}
              id={`suggestion-${index}`}
              role="option"
              // eslint-disable-next-line jsx-a11y/aria-proptypes
              aria-selected={index === activeSuggestionIndex ? "true" : "false"}
              className={`${styles.suggestion} ${index === activeSuggestionIndex ? styles.activeSuggestion : ''}`}
              onClick={() => addTag(suggestion)}
              onMouseEnter={() => setActiveSuggestionIndex(index)}
            >
              <span className={styles.suggestionColor} data-color={suggestion.color} />
              <span className={styles.suggestionName}>{suggestion.name}</span>
            </div>
          ))}

          {allowCustomTags && inputValue.trim() && !filteredSuggestions.some(s => s.name.toLowerCase() === inputValue.toLowerCase()) && (
            <div
              role="option"
              aria-selected="false"
              className={`${styles.suggestion} ${styles.createNew}`}
              onClick={() => addTag(createNewTag(inputValue))}
            >
              <span className={styles.createIcon}>+</span>
              <span>Create "{inputValue}"</span>
            </div>
          )}

          {filteredSuggestions.length === 0 && !allowCustomTags && !isLoading && (
            <div className={styles.noSuggestions}>No matching tags found</div>
          )}
        </div>
      )}

      {error && <div className={styles.errorMessage} role="alert">{error}</div>}

      <div className={styles.helperText}>
        {isMaxTagsReached
          ? `Maximum ${maxTags} tags allowed`
          : allowCustomTags
          ? 'Type to search or create new tags. Press Enter to add.'
          : 'Type to search existing tags.'}
      </div>
    </div>
  );
};

export default TagInput;
