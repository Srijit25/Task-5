import React from 'react';
import { Tag } from './TagInput';
import styles from './TagList.module.css';

interface TagListProps {
  tags: Tag[];
  onTagClick?: (tag: Tag) => void;
  onTagRemove?: (tagId: string) => void;
  removable?: boolean;
  clickable?: boolean;
  size?: 'small' | 'medium' | 'large';
  variant?: 'default' | 'outline' | 'minimal';
  className?: string;
  emptyMessage?: string;
  maxDisplay?: number;
  showMore?: boolean;
}

const TagList: React.FC<TagListProps> = ({
  tags = [],
  onTagClick,
  onTagRemove,
  removable = false,
  clickable = false,
  size = 'medium',
  variant = 'default',
  className,
  emptyMessage = 'No tags',
  maxDisplay,
  showMore = false
}) => {
  const [showAll, setShowAll] = React.useState(false);

  if (tags.length === 0) {
    return (
      <div className={`${styles.emptyState} ${className || ''}`}>
        <span className={styles.emptyMessage}>{emptyMessage}</span>
      </div>
    );
  }

  const displayTags = maxDisplay && !showAll 
    ? tags.slice(0, maxDisplay)
    : tags;
  
  const hiddenCount = maxDisplay && !showAll 
    ? tags.length - maxDisplay 
    : 0;

  const handleTagClick = (tag: Tag) => {
    if (clickable && onTagClick) {
      onTagClick(tag);
    }
  };

  const handleTagRemove = (e: React.MouseEvent, tagId: string) => {
    e.stopPropagation();
    if (removable && onTagRemove) {
      onTagRemove(tagId);
    }
  };

  return (
    <div className={`${styles.tagList} ${className || ''}`}>
      <div className={styles.tagsContainer}>
        {displayTags.map((tag) => (
          <button
            key={tag.id}
            type="button"
            className={`
              ${styles.tag} 
              ${styles[size]} 
              ${styles[variant]}
              ${clickable ? styles.clickable : ''}
              ${removable ? styles.removable : ''}
            `}
            data-color={tag.color}
            onClick={() => handleTagClick(tag)}
            disabled={!clickable}
            aria-label={clickable ? `Filter by ${tag.name}` : tag.name}
          >
            <span className={styles.tagName}>{tag.name}</span>
            {removable && (
              <button
                type="button"
                className={styles.removeButton}
                onClick={(e) => handleTagRemove(e, tag.id)}
                aria-label={`Remove ${tag.name} tag`}
                tabIndex={-1}
              >
                ×
              </button>
            )}
          </button>
        ))}

        {/* Show more/less toggle */}
        {maxDisplay && hiddenCount > 0 && showMore && (
          <button
            type="button"
            className={`${styles.showMoreButton} ${styles[size]}`}
            onClick={() => setShowAll(!showAll)}
            aria-label={showAll ? 'Show fewer tags' : `Show ${hiddenCount} more tags`}
          >
            {showAll ? (
              <>
                <span>Show less</span>
                <span className={styles.chevron}>▲</span>
              </>
            ) : (
              <>
                <span>+{hiddenCount} more</span>
                <span className={styles.chevron}>▼</span>
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
};

export default TagList;