import React, { useState, useEffect } from 'react';
import { User, Like } from '../../types';
import { UserCard } from '../user';
import styles from './LikesList.module.css';

interface LikesListProps {
  targetId: string;
  targetType: 'post' | 'comment';
  likes?: Like[];
  loading?: boolean;
  error?: string | null;
  onLoadMore?: () => void;
  onClose?: () => void;
  hasMore?: boolean;
  className?: string;
}

const LikesList: React.FC<LikesListProps> = ({
  targetId,
  targetType,
  likes = [],
  loading = false,
  error = null,
  onLoadMore,
  onClose,
  hasMore = false,
  className = ''
}) => {
  const [showModal, setShowModal] = useState(true);

  const handleClose = () => {
    setShowModal(false);
    if (onClose) {
      onClose();
    }
  };

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      handleClose();
    }
  };

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleClose();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, []);

  if (!showModal) return null;

  return (
    <div className={`${styles.overlay} ${className}`} onClick={handleBackdropClick}>
      <div className={styles.modal}>
        <div className={styles.header}>
          <h2 className={styles.title}>
            {likes.length > 0 ? `${likes.length.toLocaleString()} likes` : 'Likes'}
          </h2>
          <button 
            onClick={handleClose}
            className={styles.closeButton}
            aria-label="Close likes list"
          >
            ✕
          </button>
        </div>

        <div className={styles.content}>
          {loading && likes.length === 0 ? (
            <div className={styles.loadingContainer}>
              {[...Array(5)].map((_, index) => (
                <div key={index} className={styles.userSkeleton}>
                  <div className={styles.skeletonAvatar}></div>
                  <div className={styles.skeletonInfo}>
                    <div className={styles.skeletonLine}></div>
                    <div className={styles.skeletonLine}></div>
                  </div>
                </div>
              ))}
            </div>
          ) : error ? (
            <div className={styles.errorContainer}>
              <div className={styles.errorIcon}>⚠️</div>
              <div className={styles.errorMessage}>
                {error}
              </div>
              <button 
                onClick={() => window.location.reload()}
                className={styles.retryButton}
              >
                Try Again
              </button>
            </div>
          ) : likes.length === 0 ? (
            <div className={styles.emptyContainer}>
              <div className={styles.emptyIcon}>❤️</div>
              <div className={styles.emptyMessage}>
                No likes yet
              </div>
              <div className={styles.emptySubtext}>
                Be the first to like this {targetType}!
              </div>
            </div>
          ) : (
            <div className={styles.likesList}>
              {likes.map((like) => (
                <div key={like.id} className={styles.likeItem}>
                  <UserCard
                    user={like.user!}
                    showFollowButton={true}
                    className={styles.userCard}
                  />
                  <div className={styles.likeInfo}>
                    <span className={styles.likeDate}>
                      {formatDate(like.createdAt)}
                    </span>
                  </div>
                </div>
              ))}
              
              {hasMore && (
                <div className={styles.loadMoreContainer}>
                  <button
                    onClick={onLoadMore}
                    disabled={loading}
                    className={styles.loadMoreButton}
                  >
                    {loading ? 'Loading...' : 'Load More'}
                  </button>
                </div>
              )}
              
              {loading && likes.length > 0 && (
                <div className={styles.loadingMore}>
                  <div className={styles.loadingSpinner}></div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  const now = new Date();
  const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
  
  if (diffInHours < 1) {
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    return diffInMinutes < 1 ? 'just now' : `${diffInMinutes}m ago`;
  } else if (diffInHours < 24) {
    return `${diffInHours}h ago`;
  } else {
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) {
      return `${diffInDays}d ago`;
    } else {
      return date.toLocaleDateString();
    }
  }
};

export default LikesList;