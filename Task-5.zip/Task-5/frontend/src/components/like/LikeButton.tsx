import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import styles from './LikeButton.module.css';

interface LikeButtonProps {
  targetId: string;
  targetType: 'post' | 'comment';
  isLiked?: boolean;
  likesCount: number;
  onLike?: (targetId: string) => Promise<void>;
  onUnlike?: (targetId: string) => Promise<void>;
  onShowLikes?: (targetId: string, targetType: 'post' | 'comment') => void;
  size?: 'small' | 'medium' | 'large';
  variant?: 'default' | 'compact' | 'icon-only';
  animated?: boolean;
  disabled?: boolean;
  className?: string;
}

const LikeButton: React.FC<LikeButtonProps> = ({
  targetId,
  targetType,
  isLiked = false,
  likesCount,
  onLike,
  onUnlike,
  onShowLikes,
  size = 'medium',
  variant = 'default',
  animated = true,
  disabled = false,
  className = ''
}) => {
  const { state } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [currentLiked, setCurrentLiked] = useState(isLiked);
  const [currentCount, setCurrentCount] = useState(likesCount);

  const handleLikeToggle = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (!state.user || isLoading || disabled) return;

    try {
      setIsLoading(true);
      
      if (currentLiked) {
        // Optimistic update
        setCurrentLiked(false);
        setCurrentCount(prev => Math.max(0, prev - 1));
        
        if (onUnlike) {
          await onUnlike(targetId);
        }
      } else {
        // Optimistic update
        setCurrentLiked(true);
        setCurrentCount(prev => prev + 1);
        
        if (onLike) {
          await onLike(targetId);
        }
      }
    } catch (error) {
      // Revert optimistic update on error
      setCurrentLiked(isLiked);
      setCurrentCount(likesCount);
      console.error('Failed to toggle like:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleShowLikes = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (onShowLikes && currentCount > 0) {
      onShowLikes(targetId, targetType);
    }
  };

  const getButtonClass = () => {
    const baseClass = styles.likeButton;
    const sizeClass = styles[size];
    const variantClass = styles[variant];
    const stateClass = currentLiked ? styles.liked : '';
    const loadingClass = isLoading ? styles.loading : '';
    const disabledClass = disabled ? styles.disabled : '';
    const animatedClass = animated ? styles.animated : '';
    
    return `${baseClass} ${sizeClass} ${variantClass} ${stateClass} ${loadingClass} ${disabledClass} ${animatedClass} ${className}`.trim();
  };

  const getIconClass = () => {
    return `${styles.icon} ${currentLiked ? styles.iconLiked : styles.iconUnliked} ${animated ? styles.iconAnimated : ''}`;
  };

  const renderIcon = () => {
    if (isLoading) {
      return <span className={styles.loadingIcon}>⏳</span>;
    }
    
    return (
      <span className={getIconClass()}>
        {currentLiked ? '❤️' : '🤍'}
      </span>
    );
  };

  const renderCount = () => {
    if (variant === 'icon-only') return null;
    
    if (currentCount === 0) {
      return variant === 'compact' ? null : <span className={styles.count}>Like</span>;
    }
    
    return (
      <span 
        className={`${styles.count} ${currentCount > 0 && onShowLikes ? styles.clickable : ''}`}
        onClick={currentCount > 0 && onShowLikes ? handleShowLikes : undefined}
      >
        {currentCount.toLocaleString()}
        {variant === 'default' && currentCount !== 1 ? ' likes' : ''}
      </span>
    );
  };

  if (!state.user) {
    return (
      <div className={`${styles.likeButton} ${styles[size]} ${styles.disabled} ${className}`}>
        {renderIcon()}
        {renderCount()}
      </div>
    );
  }

  return (
    <button
      className={getButtonClass()}
      onClick={handleLikeToggle}
      disabled={disabled || isLoading}
      aria-label={`${currentLiked ? 'Unlike' : 'Like'} this ${targetType}`}
      title={`${currentLiked ? 'Unlike' : 'Like'} this ${targetType}`}
    >
      {renderIcon()}
      {renderCount()}
    </button>
  );
};

export default LikeButton;