import React, { useState, useEffect } from 'react';
import { useRealTimeNotifications, useNotificationPermission } from '../../hooks/useRealTime';
import styles from './NotificationCenter.module.css';

interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'like' | 'comment' | 'follow' | 'mention' | 'system';
  isRead: boolean;
  createdAt: string;
  userId?: string;
  postId?: string;
  avatar?: string;
}

const NotificationCenter: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { notifications, unreadCount, markAsRead, markAllAsRead } = useRealTimeNotifications();
  const { permission, requestPermission, isSupported } = useNotificationPermission();

  const handleNotificationClick = (notification: NotificationItem) => {
    if (!notification.isRead) {
      markAsRead(notification.id);
    }
    
    // Handle navigation based on notification type
    if (notification.postId) {
      // Navigate to post
      window.location.href = `/post/${notification.postId}`;
    } else if (notification.userId) {
      // Navigate to user profile
      window.location.href = `/profile/${notification.userId}`;
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'like': return '❤️';
      case 'comment': return '💬';
      case 'follow': return '👤';
      case 'mention': return '📢';
      case 'system': return '🔔';
      default: return '📨';
    }
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const time = new Date(timestamp);
    const diffInMs = now.getTime() - time.getTime();
    const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
    const diffInHours = Math.floor(diffInMinutes / 60);
    const diffInDays = Math.floor(diffInHours / 24);

    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInHours < 24) return `${diffInHours}h ago`;
    if (diffInDays < 7) return `${diffInDays}d ago`;
    return time.toLocaleDateString();
  };

  // Request notification permission on mount if supported
  useEffect(() => {
    if (isSupported && permission === 'default') {
      requestPermission();
    }
  }, [isSupported, permission, requestPermission]);

  return (
    <div className={styles.notificationCenter}>
      {/* Notification Bell Button */}
      <button
        className={styles.notificationButton}
        onClick={() => setIsOpen(!isOpen)}
        aria-label={`Notifications ${unreadCount > 0 ? `(${unreadCount} unread)` : ''}`}
      >
        <span className={styles.bellIcon}>🔔</span>
        {unreadCount > 0 && (
          <span className={styles.unreadBadge}>
            {unreadCount > 99 ? '99+' : unreadCount}
          </span>
        )}
      </button>

      {/* Notification Dropdown */}
      {isOpen && (
        <div className={styles.notificationDropdown}>
          <div className={styles.notificationHeader}>
            <h3 className={styles.notificationTitle}>Notifications</h3>
            {unreadCount > 0 && (
              <button
                className={styles.markAllButton}
                onClick={markAllAsRead}
              >
                Mark all as read
              </button>
            )}
          </div>

          {/* Browser Notification Permission */}
          {isSupported && permission !== 'granted' && (
            <div className={styles.permissionBanner}>
              <p>Enable browser notifications to stay updated</p>
              <button
                className={styles.enableButton}
                onClick={requestPermission}
              >
                Enable
              </button>
            </div>
          )}

          <div className={styles.notificationList}>
            {notifications.length === 0 ? (
              <div className={styles.emptyState}>
                <span className={styles.emptyIcon}>📭</span>
                <p>No notifications yet</p>
              </div>
            ) : (
              notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`${styles.notificationItem} ${
                    !notification.isRead ? styles.unread : ''
                  }`}
                  onClick={() => handleNotificationClick(notification)}
                >
                  <div className={styles.notificationIcon}>
                    {notification.avatar ? (
                      <img
                        src={notification.avatar}
                        alt="User avatar"
                        className={styles.userAvatar}
                      />
                    ) : (
                      <span className={styles.typeIcon}>
                        {getNotificationIcon(notification.type)}
                      </span>
                    )}
                  </div>
                  
                  <div className={styles.notificationContent}>
                    <div className={styles.notificationText}>
                      <span className={styles.notificationTitle}>
                        {notification.title}
                      </span>
                      <p className={styles.notificationMessage}>
                        {notification.message}
                      </p>
                    </div>
                    <div className={styles.notificationMeta}>
                      <span className={styles.timestamp}>
                        {formatTimeAgo(notification.createdAt)}
                      </span>
                      {!notification.isRead && (
                        <span className={styles.unreadDot}></span>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* View All Link */}
          {notifications.length > 5 && (
            <div className={styles.notificationFooter}>
              <a href="/notifications" className={styles.viewAllLink}>
                View all notifications
              </a>
            </div>
          )}
        </div>
      )}

      {/* Overlay to close dropdown */}
      {isOpen && (
        <div
          className={styles.overlay}
          onClick={() => setIsOpen(false)}
        />
      )}
    </div>
  );
};

export default NotificationCenter;