import React from 'react';
import Header from './Header';
import styles from './Layout.module.css';

interface LayoutProps {
  children: React.ReactNode;
  className?: string;
}

const Layout: React.FC<LayoutProps> = ({ children, className = '' }) => {
  return (
    <div className={styles.layout}>
      <Header />
      <main className={`${styles.main} ${className}`}>
        {children}
      </main>
    </div>
  );
};

export default Layout;