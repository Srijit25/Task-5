import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import NotificationCenter from '../notifications/NotificationCenter';
import styles from './Header.module.css';

const Header: React.FC = () => {
  const { state, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const isActivePage = (path: string) => {
    return location.pathname === path;
  };

  return (
    <header className={styles.header}>
      <div className={styles.container}>
        {/* Logo */}
        <Link to="/" className={styles.logo}>
          <span className={styles.logoIcon}>📱</span>
          SocialApp
        </Link>

        {/* Navigation */}
        <nav className={`${styles.nav} ${isMenuOpen ? styles.navOpen : ''}`}>
          <Link 
            to="/" 
            className={`${styles.navLink} ${isActivePage('/') ? styles.active : ''}`}
            onClick={() => setIsMenuOpen(false)}
          >
            Home
          </Link>
          <Link 
            to="/explore" 
            className={`${styles.navLink} ${isActivePage('/explore') ? styles.active : ''}`}
            onClick={() => setIsMenuOpen(false)}
          >
            Explore
          </Link>
          <Link 
            to="/notifications" 
            className={`${styles.navLink} ${isActivePage('/notifications') ? styles.active : ''}`}
            onClick={() => setIsMenuOpen(false)}
          >
            Notifications
          </Link>
        </nav>

        {/* User actions */}
        <div className={styles.userActions}>
          {/* Search */}
          <div className={styles.searchContainer}>
            <input 
              type="text" 
              placeholder="Search..." 
              className={styles.searchInput}
            />
            <button className={styles.searchButton}>
              🔍
            </button>
          </div>

          {/* Real-time Notifications */}
          <NotificationCenter />

          {/* User menu */}
          <div className={styles.userMenu}>
            <Link to={`/profile/${state.user?.id}`} className={styles.userProfile}>
              {state.user?.profileImageUrl ? (
                <img 
                  src={state.user.profileImageUrl} 
                  alt="Profile" 
                  className={styles.profileImage}
                />
              ) : (
                <div className={styles.profileAvatar}>
                  {state.user?.username?.charAt(0).toUpperCase()}
                </div>
              )}
              <span className={styles.username}>{state.user?.username}</span>
            </Link>

            <button 
              onClick={handleLogout}
              className={styles.logoutButton}
              title="Logout"
            >
              🚪
            </button>
          </div>

          {/* Mobile menu toggle */}
          <button 
            className={styles.menuToggle}
            onClick={toggleMenu}
            aria-label="Toggle menu"
          >
            <span className={`${styles.hamburger} ${isMenuOpen ? styles.hamburgerOpen : ''}`}>
              <span></span>
              <span></span>
              <span></span>
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;