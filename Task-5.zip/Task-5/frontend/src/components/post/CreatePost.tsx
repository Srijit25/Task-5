import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { postService } from '../../services/postService';
import styles from './CreatePost.module.css';

interface CreatePostProps {
  onPostCreated?: (post: any) => void;
  className?: string;
  placeholder?: string;
}

const CreatePost: React.FC<CreatePostProps> = ({
  onPostCreated,
  className = '',
  placeholder = "What's on your mind?"
}) => {
  const { state } = useAuth();
  const [content, setContent] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [previewUrls, setPreviewUrls] = useState<string[]>([]);

  const handleInputFocus = () => {
    setIsExpanded(true);
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    const maxFiles = 4;
    
    if (files.length > maxFiles) {
      alert(`You can only upload up to ${maxFiles} files`);
      return;
    }

    setSelectedFiles(files);
    
    // Create preview URLs
    const urls = files.map(file => URL.createObjectURL(file));
    setPreviewUrls(urls);
  };

  const handleRemoveFile = (index: number) => {
    const newFiles = selectedFiles.filter((_, i) => i !== index);
    const newUrls = previewUrls.filter((_, i) => i !== index);
    
    // Revoke the removed URL to prevent memory leaks
    URL.revokeObjectURL(previewUrls[index]);
    
    setSelectedFiles(newFiles);
    setPreviewUrls(newUrls);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!content.trim() && selectedFiles.length === 0) return;

    try {
      setIsSubmitting(true);
      
      // Use the actual API service
      const postData = {
        content: content.trim(),
        tags: [] // TODO: Add tag selection functionality
      };

      let newPost;
      if (selectedFiles.length > 0) {
        // Use the media upload version
        newPost = await postService.createPost({ 
          ...postData, 
          image: selectedFiles[0] // For now, just use the first file
        });
      } else {
        // Text-only post
        newPost = await postService.createPost(postData);
      }
      
      if (onPostCreated) {
        onPostCreated(newPost);
      }

      // Reset form
      setContent('');
      setSelectedFiles([]);
      setPreviewUrls([]);
      setIsExpanded(false);
      
    } catch (error) {
      console.error('Failed to create post:', error);
      alert('Failed to create post. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    setContent('');
    setSelectedFiles([]);
    setPreviewUrls([]);
    setIsExpanded(false);
  };

  return (
    <div className={`${styles.createPost} ${className}`}>
      <form onSubmit={handleSubmit}>
        <div className={styles.header}>
          <div className={styles.userAvatar}>
            {state.user?.profileImageUrl ? (
              <img 
                src={state.user.profileImageUrl} 
                alt="Your avatar"
                className={styles.avatarImage}
              />
            ) : (
              <div className={styles.avatarPlaceholder}>
                {state.user?.username?.charAt(0).toUpperCase()}
              </div>
            )}
          </div>
          
          <div className={styles.inputContainer}>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              onFocus={handleInputFocus}
              placeholder={placeholder}
              className={`${styles.textInput} ${isExpanded ? styles.expanded : ''}`}
              rows={isExpanded ? 4 : 1}
              maxLength={280}
            />
            
            {isExpanded && (
              <div className={styles.characterCount}>
                <span className={content.length > 260 ? styles.warning : ''}>
                  {content.length}/280
                </span>
              </div>
            )}
          </div>
        </div>

        {/* File Previews */}
        {previewUrls.length > 0 && (
          <div className={styles.filePreview}>
            <div className={styles.previewGrid}>
              {previewUrls.map((url, index) => {
                const file = selectedFiles[index];
                const isImage = file.type.startsWith('image/');
                const isVideo = file.type.startsWith('video/');

                return (
                  <div key={index} className={styles.previewItem}>
                    {isImage && (
                      <img 
                        src={url} 
                        alt={`Preview ${index + 1}`}
                        className={styles.previewImage}
                      />
                    )}
                    {isVideo && (
                      <video 
                        src={url} 
                        className={styles.previewVideo}
                        controls
                      />
                    )}
                    <button
                      type="button"
                      onClick={() => handleRemoveFile(index)}
                      className={styles.removeFileButton}
                    >
                      ✕
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Actions */}
        {isExpanded && (
          <div className={styles.actions}>
            <div className={styles.mediaActions}>
              <label className={styles.mediaButton}>
                📷
                <input
                  type="file"
                  accept="image/*,video/*"
                  multiple
                  onChange={handleFileSelect}
                  className={styles.fileInput}
                />
              </label>
              
              <button type="button" className={styles.mediaButton} title="Add emoji">
                😊
              </button>
              
              <button type="button" className={styles.mediaButton} title="Add poll">
                📊
              </button>
            </div>

            <div className={styles.submitActions}>
              <button
                type="button"
                onClick={handleCancel}
                className={styles.cancelButton}
              >
                Cancel
              </button>
              
              <button
                type="submit"
                disabled={(!content.trim() && selectedFiles.length === 0) || isSubmitting}
                className={styles.submitButton}
              >
                {isSubmitting ? 'Posting...' : 'Post'}
              </button>
            </div>
          </div>
        )}
      </form>
    </div>
  );
};

export default CreatePost;