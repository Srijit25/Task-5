import React, { useState, useEffect } from 'react';
import { Post } from '../../types';
import PostCard from './PostCard';
import { postService } from '../../services/postService';
import styles from './PostFeed.module.css';

interface PostFeedProps {
  posts?: Post[];
  loading?: boolean;
  error?: string;
  emptyMessage?: string;
  onLike?: (postId: string) => void;
  onComment?: (postId: string) => void;
  onShare?: (postId: string) => void;
  onEdit?: (postId: string) => void;
  onDelete?: (postId: string) => void;
  className?: string;
  refreshTrigger?: number; // Add this to trigger refresh when new post is created
}

const PostFeed: React.FC<PostFeedProps> = ({
  posts: externalPosts,
  loading: externalLoading = false,
  error: externalError,
  emptyMessage = 'No posts to show',
  onLike,
  onComment,
  onShare,
  onEdit,
  onDelete,
  className = '',
  refreshTrigger = 0
}) => {
  const [internalPosts, setInternalPosts] = useState<Post[]>([]);
  const [internalLoading, setInternalLoading] = useState(true);
  const [internalError, setInternalError] = useState<string | null>(null);

  // Use external props if provided, otherwise use internal state
  const posts = externalPosts || internalPosts;
  const loading = externalLoading || internalLoading;
  const error = externalError || internalError;

  useEffect(() => {
    // If external posts are provided, don't fetch internally
    if (externalPosts) {
      setInternalLoading(false);
      return;
    }

    const fetchPosts = async () => {
      try {
        setInternalLoading(true);
        setInternalError(null);
        
        // Use real API service
        const response = await postService.getPosts(1, 10);
        setInternalPosts(response.data);
      } catch (err) {
        setInternalError(err instanceof Error ? err.message : 'Failed to fetch posts');
        
        // Fallback to mock data if API fails
        const mockPosts: Post[] = [
          {
            id: '1',
            content: 'Welcome to our social media platform! 🎉',
            userId: 'user1',
            user: {
              id: 'user1',
              username: 'john_doe',
              email: 'john@example.com',
              firstName: 'John',
              lastName: 'Doe',
              followersCount: 150,
              followingCount: 75,
              postsCount: 12,
              isVerified: false,
              createdAt: '2024-01-01T00:00:00Z',
              updatedAt: '2024-01-01T00:00:00Z'
            },
            likesCount: 5,
            commentsCount: 2,
            isLiked: false,
            tags: [],
            createdAt: '2024-01-15T10:30:00Z',
            updatedAt: '2024-01-15T10:30:00Z'
          },
          {
            id: '2',
            content: 'Just shared some amazing photos from my vacation! 📸',
            userId: 'user2',
            user: {
              id: 'user2',
              username: 'jane_smith',
              email: 'jane@example.com',
              firstName: 'Jane',
              lastName: 'Smith',
              followersCount: 300,
              followingCount: 120,
              postsCount: 25,
              isVerified: true,
              createdAt: '2024-01-01T00:00:00Z',
              updatedAt: '2024-01-01T00:00:00Z'
            },
            imageUrl: 'https://via.placeholder.com/500x300',
            likesCount: 12,
            commentsCount: 4,
            isLiked: true,
            tags: [],
            createdAt: '2024-01-14T15:45:00Z',
            updatedAt: '2024-01-14T15:45:00Z'
          }
        ];
        setInternalPosts(mockPosts);
      } finally {
        setInternalLoading(false);
      }
    };

    fetchPosts();
  }, [externalPosts, refreshTrigger]);

  const handleLike = async (postId: string) => {
    if (onLike) {
      onLike(postId);
      return;
    }

    // Internal like handling
    try {
      const currentPost = posts.find(p => p.id === postId);
      if (!currentPost) return;

      if (currentPost.isLiked) {
        await postService.unlikePost(postId);
      } else {
        await postService.likePost(postId);
      }

      // Update local state
      setInternalPosts(prevPosts => 
        prevPosts.map(post => 
          post.id === postId 
            ? { 
                ...post, 
                isLiked: !post.isLiked,
                likesCount: post.isLiked ? post.likesCount - 1 : post.likesCount + 1
              }
            : post
        )
      );
    } catch (error) {
      console.error('Failed to like/unlike post:', error);
    }
  };

  const handleComment = (postId: string) => {
    if (onComment) {
      onComment(postId);
    } else {
      // TODO: Implement comment functionality
      console.log('Comment on post:', postId);
    }
  };

  const handleShare = (postId: string) => {
    if (onShare) {
      onShare(postId);
    } else {
      // TODO: Implement share functionality
      console.log('Share post:', postId);
    }
  };

  const handleEdit = (postId: string) => {
    if (onEdit) {
      onEdit(postId);
    } else {
      // TODO: Implement edit functionality
      console.log('Edit post:', postId);
    }
  };

  const handleDelete = async (postId: string) => {
    if (onDelete) {
      onDelete(postId);
      return;
    }

    // Internal delete handling
    try {
      await postService.deletePost(postId);
      
      // Remove from local state
      setInternalPosts(prevPosts => prevPosts.filter(post => post.id !== postId));
    } catch (error) {
      console.error('Failed to delete post:', error);
    }
  };
  if (loading) {
    return (
      <div className={`${styles.postFeed} ${className}`}>
        {Array.from({ length: 3 }).map((_, index) => (
          <div key={index} className={styles.postSkeleton}>
            <div className={styles.skeletonHeader}>
              <div className={styles.skeletonAvatar}></div>
              <div className={styles.skeletonUserInfo}>
                <div className={styles.skeletonLine}></div>
                <div className={styles.skeletonLine}></div>
              </div>
            </div>
            <div className={styles.skeletonContent}>
              <div className={styles.skeletonLine}></div>
              <div className={styles.skeletonLine}></div>
              <div className={styles.skeletonLine}></div>
            </div>
            <div className={styles.skeletonActions}>
              <div className={styles.skeletonAction}></div>
              <div className={styles.skeletonAction}></div>
              <div className={styles.skeletonAction}></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className={styles.errorContainer}>
        <div className={styles.errorIcon}>⚠️</div>
        <div className={styles.errorMessage}>
          {error}
        </div>
        <button 
          className={styles.retryButton}
          onClick={() => window.location.reload()}
        >
          Try Again
        </button>
      </div>
    );
  }

  if (posts.length === 0) {
    return (
      <div className={styles.emptyContainer}>
        <div className={styles.emptyIcon}>📝</div>
        <div className={styles.emptyMessage}>
          {emptyMessage}
        </div>
        <p className={styles.emptySubtext}>
          Posts you create or from people you follow will appear here.
        </p>
      </div>
    );
  }

  return (
    <div className={`${styles.postFeed} ${className}`}>
      {posts.map((post) => (
        <PostCard
          key={post.id}
          post={post}
          onLike={handleLike}
          onComment={handleComment}
          onShare={handleShare}
          onEdit={handleEdit}
          onDelete={handleDelete}
        />
      ))}
    </div>
  );
};

export default PostFeed;