import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Post } from '../../types';
import { useRealTimePosts } from '../../hooks/useRealTime';
import styles from './PostCard.module.css';

interface PostCardProps {
  post: Post;
  onLike?: (postId: string) => void;
  onComment?: (postId: string) => void;
  onShare?: (postId: string) => void;
  onEdit?: (postId: string) => void;
  onDelete?: (postId: string) => void;
  showActions?: boolean;
  className?: string;
}

const PostCard: React.FC<PostCardProps> = ({
  post,
  onLike,
  onComment,
  onShare,
  onEdit,
  onDelete,
  showActions = true,
  className = ''
}) => {
  const navigate = useNavigate();
  const [showMenu, setShowMenu] = useState(false);
  const [isLiking, setIsLiking] = useState(false);
  const [currentPost, setCurrentPost] = useState(post);
  
  // Real-time post updates
  const { posts } = useRealTimePosts();

  const isOwner = post.userId === 'current-user-id'; // TODO: Replace with actual user check

  // Update post data when real-time updates come in
  useEffect(() => {
    const updatedPost = posts.find(p => p.id === post.id);
    if (updatedPost) {
      setCurrentPost(updatedPost);
    }
  }, [posts, post.id]);

  // Use currentPost instead of post for rendering
  const displayPost = currentPost;

  const handleLike = async () => {
    if (isLiking || !onLike) return;
    
    try {
      setIsLiking(true);
      await onLike(displayPost.id);
    } finally {
      setIsLiking(false);
    }
  };

  const handleComment = () => {
    if (onComment) {
      onComment(displayPost.id);
    } else {
      // Navigate to post details page to show comments
      navigate(`/post/${displayPost.id}`);
    }
  };

  const handleMenuToggle = () => {
    setShowMenu(!showMenu);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
      const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
      return diffInMinutes < 1 ? 'now' : `${diffInMinutes}m`;
    } else if (diffInHours < 24) {
      return `${diffInHours}h`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      return diffInDays < 7 ? `${diffInDays}d` : date.toLocaleDateString();
    }
  };

  return (
    <article className={`${styles.postCard} ${className}`}>
      {/* Post Header */}
      <div className={styles.header}>
        <Link to={`/profile/${displayPost.userId}`} className={styles.authorLink}>
          <div className={styles.authorAvatar}>
            {displayPost.user?.profileImageUrl ? (
              <img 
                src={displayPost.user.profileImageUrl} 
                alt={`${displayPost.user.username}'s avatar`}
                className={styles.avatarImage}
              />
            ) : (
              <div className={styles.avatarPlaceholder}>
                {displayPost.user?.username?.charAt(0).toUpperCase() || 'U'}
              </div>
            )}
          </div>
          
          <div className={styles.authorInfo}>
            <div className={styles.authorName}>
              {displayPost.user?.username || 'Unknown User'}
              {displayPost.user?.isVerified && (
                <span className={styles.verifiedBadge}>✓</span>
              )}
            </div>
            <div className={styles.postDate}>
              {formatDate(displayPost.createdAt)}
              {displayPost.createdAt !== displayPost.updatedAt && (
                <span className={styles.editedIndicator}> • edited</span>
              )}
            </div>
          </div>
        </Link>

        {/* Post Menu */}
        <div className={styles.postMenu}>
          <button 
            className={styles.menuButton}
            onClick={handleMenuToggle}
          >
            ⋯
          </button>
          
          {showMenu && (
            <div className={styles.menuDropdown}>
              {onEdit && (
                <button onClick={() => { onEdit(displayPost.id); setShowMenu(false); }}>
                  ✏️ Edit
                </button>
              )}
              {onDelete && (
                <button 
                  onClick={() => { onDelete(displayPost.id); setShowMenu(false); }}
                  className={styles.deleteButton}
                >
                  🗑️ Delete
                </button>
              )}
              <button onClick={() => setShowMenu(false)}>
                🔗 Copy Link
              </button>
              <button onClick={() => setShowMenu(false)}>
                🚫 Report
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Post Content */}
      <div className={styles.content}>
        {displayPost.content && (
          <div className={styles.textContent}>
            {displayPost.content}
          </div>
        )}

        {/* Media Content */}
        {(displayPost.imageUrl || displayPost.videoUrl) && (
          <div className={styles.mediaContent}>
            {displayPost.imageUrl && (
              <img 
                src={displayPost.imageUrl}
                alt="Post image"
                className={styles.postImage}
              />
            )}
            {displayPost.videoUrl && (
              <video 
                src={displayPost.videoUrl}
                className={styles.postVideo}
                controls
                preload="metadata"
              />
            )}
          </div>
        )}
      </div>

      {/* Post Actions */}
      {showActions && (
        <div className={styles.actions}>
          <button 
            className={`${styles.actionButton} ${styles.commentButton}`}
            onClick={handleComment}
          >
            💬 {displayPost.commentsCount || 0}
          </button>

          <button 
            className={`${styles.actionButton} ${styles.likeButton} ${displayPost.isLiked ? styles.liked : ''}`}
            onClick={handleLike}
            disabled={isLiking}
          >
            {displayPost.isLiked ? '❤️' : '🤍'} {displayPost.likesCount || 0}
          </button>

          <button 
            className={`${styles.actionButton} ${styles.shareButton}`}
            onClick={() => onShare?.(displayPost.id)}
          >
            🔄 0
          </button>

          <button className={`${styles.actionButton} ${styles.bookmarkButton}`}>
            🔖
          </button>
        </div>
      )}
    </article>
  );
};

export default PostCard;