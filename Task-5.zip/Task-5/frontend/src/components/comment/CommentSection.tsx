import React, { useState, useEffect } from 'react';
import { Comment } from '../../types';
import { useRealTimeComments, useTypingIndicator } from '../../hooks/useRealTime';
import styles from './CommentSection.module.css';

interface CommentSectionProps {
  postId: string;
  comments: Comment[];
  onAddComment?: (postId: string, content: string) => Promise<void>;
  onLikeComment?: (commentId: string) => Promise<void>;
  onDeleteComment?: (commentId: string) => Promise<void>;
  className?: string;
}

const CommentSection: React.FC<CommentSectionProps> = ({
  postId,
  comments: initialComments,
  onAddComment,
  onLikeComment,
  onDeleteComment,
  className = ''
}) => {
  const [newComment, setNewComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [currentComments, setCurrentComments] = useState(initialComments);
  
  // Real-time comment updates
  const { comments: realTimeComments } = useRealTimeComments(postId);
  const { typingUsers, sendTyping } = useTypingIndicator('post', postId);

  // Update comments when real-time updates come in
  useEffect(() => {
    if (realTimeComments.length > 0) {
      setCurrentComments(realTimeComments);
    }
  }, [realTimeComments]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || !onAddComment || isSubmitting) return;

    try {
      setIsSubmitting(true);
      await onAddComment(postId, newComment.trim());
      setNewComment('');
      sendTyping(false);
    } catch (error) {
      console.error('Failed to add comment:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    setNewComment(value);
    
    if (value.trim()) {
      sendTyping(true);
    } else {
      sendTyping(false);
    }
  };

  const handleCommentLike = async (commentId: string) => {
    if (!onLikeComment) return;
    
    try {
      await onLikeComment(commentId);
    } catch (error) {
      console.error('Failed to like comment:', error);
    }
  };

  const handleCommentDelete = async (commentId: string) => {
    if (!onDeleteComment) return;
    
    if (window.confirm('Are you sure you want to delete this comment?')) {
      try {
        await onDeleteComment(commentId);
      } catch (error) {
        console.error('Failed to delete comment:', error);
      }
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMs = now.getTime() - date.getTime();
    const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
    const diffInHours = Math.floor(diffInMinutes / 60);
    const diffInDays = Math.floor(diffInHours / 24);

    if (diffInMinutes < 1) return 'now';
    if (diffInMinutes < 60) return `${diffInMinutes}m`;
    if (diffInHours < 24) return `${diffInHours}h`;
    if (diffInDays < 7) return `${diffInDays}d`;
    return date.toLocaleDateString();
  };

  return (
    <div className={`${styles.commentSection} ${className}`}>
      {/* Comment Form */}
      <form onSubmit={handleSubmit} className={styles.commentForm}>
        <div className={styles.inputContainer}>
          <textarea
            value={newComment}
            onChange={handleInputChange}
            placeholder="Write a comment..."
            className={styles.commentInput}
            rows={1}
            disabled={isSubmitting}
            onFocus={() => sendTyping(true)}
            onBlur={() => sendTyping(false)}
          />
          <button
            type="submit"
            disabled={!newComment.trim() || isSubmitting}
            className={styles.submitButton}
          >
            {isSubmitting ? '📤' : '➤'}
          </button>
        </div>
      </form>

      {/* Typing Indicators */}
      {typingUsers.length > 0 && (
        <div className={styles.typingIndicator}>
          <div className={styles.typingDots}>
            <span></span>
            <span></span>
            <span></span>
          </div>
          <span className={styles.typingText}>
            {typingUsers.length === 1
              ? `${typingUsers[0]} is typing...`
              : `${typingUsers.length} people are typing...`
            }
          </span>
        </div>
      )}

      {/* Comments List */}
      <div className={styles.commentsList}>
        {currentComments.length === 0 ? (
          <div className={styles.emptyState}>
            <span className={styles.emptyIcon}>💬</span>
            <p>No comments yet. Be the first to comment!</p>
          </div>
        ) : (
          currentComments.map((comment) => (
            <div key={comment.id} className={styles.comment}>
              <div className={styles.commentAvatar}>
                {comment.user?.profileImageUrl ? (
                  <img
                    src={comment.user.profileImageUrl}
                    alt={`${comment.user.username}'s avatar`}
                    className={styles.avatarImage}
                  />
                ) : (
                  <div className={styles.avatarPlaceholder}>
                    {comment.user?.username?.charAt(0).toUpperCase() || 'U'}
                  </div>
                )}
              </div>
              
              <div className={styles.commentContent}>
                <div className={styles.commentHeader}>
                  <span className={styles.commentAuthor}>
                    {comment.user?.username || 'Unknown User'}
                  </span>
                  <span className={styles.commentDate}>
                    {formatDate(comment.createdAt)}
                  </span>
                </div>
                
                <div className={styles.commentText}>
                  {comment.content}
                </div>
                
                <div className={styles.commentActions}>
                  <button
                    className={`${styles.likeButton} ${comment.isLiked ? styles.liked : ''}`}
                    onClick={() => handleCommentLike(comment.id)}
                  >
                    {comment.isLiked ? '❤️' : '🤍'} {comment.likesCount || 0}
                  </button>
                  
                  <button className={styles.replyButton}>
                    Reply
                  </button>
                  
                  {comment.userId === 'current-user-id' && (
                    <button
                      className={styles.deleteButton}
                      onClick={() => handleCommentDelete(comment.id)}
                    >
                      Delete
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default CommentSection;