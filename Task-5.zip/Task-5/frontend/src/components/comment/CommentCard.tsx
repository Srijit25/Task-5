import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Comment } from '../../types';
import { useAuth } from '../../contexts/AuthContext';
import CommentForm from './CommentForm';
import styles from './CommentCard.module.css';

interface CommentCardProps {
  comment: Comment;
  onLike?: (commentId: string) => void;
  onReply?: (commentId: string, content: string) => Promise<void>;
  onEdit?: (commentId: string, content: string) => Promise<void>;
  onDelete?: (commentId: string) => void;
  level?: number;
  maxLevel?: number;
  className?: string;
}

const CommentCard: React.FC<CommentCardProps> = ({
  comment,
  onLike,
  onReply,
  onEdit,
  onDelete,
  level = 0,
  maxLevel = 3,
  className = ''
}) => {
  const { state } = useAuth();
  const [showReplyForm, setShowReplyForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [isLiking, setIsLiking] = useState(false);
  const [showMenu, setShowMenu] = useState(false);

  const isOwner = state.user?.id === comment.userId;
  const canReply = level < maxLevel;

  const handleLike = async () => {
    if (isLiking || !onLike) return;
    
    try {
      setIsLiking(true);
      await onLike(comment.id);
    } finally {
      setIsLiking(false);
    }
  };

  const handleReply = async (content: string) => {
    if (!onReply) return;
    
    try {
      await onReply(comment.id, content);
      setShowReplyForm(false);
    } catch (error) {
      throw error; // Let CommentForm handle the error
    }
  };

  const handleEdit = async (content: string) => {
    if (!onEdit) return;
    
    try {
      await onEdit(comment.id, content);
      setShowEditForm(false);
    } catch (error) {
      throw error; // Let CommentForm handle the error
    }
  };

  const handleDelete = () => {
    if (window.confirm('Are you sure you want to delete this comment?')) {
      onDelete?.(comment.id);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
      const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
      return diffInMinutes < 1 ? 'just now' : `${diffInMinutes}m ago`;
    } else if (diffInHours < 24) {
      return `${diffInHours}h ago`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      return diffInDays === 1 ? '1 day ago' : `${diffInDays} days ago`;
    }
  };

  const getIndentClass = () => {
    if (level === 0) return '';
    if (level === 1) return styles.level1;
    if (level === 2) return styles.level2;
    return styles.level3;
  };

  return (
    <div className={`${styles.commentCard} ${getIndentClass()} ${className}`}>
      <div className={styles.commentHeader}>
        <div className={styles.userInfo}>
          <Link to={`/profile/${comment.user?.username}`} className={styles.avatar}>
            {comment.user?.profileImageUrl ? (
              <img 
                src={comment.user.profileImageUrl} 
                alt={comment.user.username}
                className={styles.avatarImage}
              />
            ) : (
              <div className={styles.avatarPlaceholder}>
                {comment.user?.username?.charAt(0).toUpperCase() || '?'}
              </div>
            )}
          </Link>
          
          <div className={styles.userDetails}>
            <Link to={`/profile/${comment.user?.username}`} className={styles.username}>
              {comment.user?.username}
              {comment.user?.isVerified && (
                <span className={styles.verifiedBadge}>✓</span>
              )}
            </Link>
            <span className={styles.timestamp}>
              {formatDate(comment.createdAt)}
              {comment.updatedAt !== comment.createdAt && (
                <span className={styles.edited}> (edited)</span>
              )}
            </span>
          </div>
        </div>

        {isOwner && (
          <div className={styles.menuContainer}>
            <button 
              onClick={() => setShowMenu(!showMenu)}
              className={styles.menuButton}
              aria-label="Comment options"
            >
              ⋯
            </button>
            
            {showMenu && (
              <div className={styles.dropdown}>
                <button 
                  onClick={() => {
                    setShowEditForm(true);
                    setShowMenu(false);
                  }}
                  className={styles.dropdownItem}
                >
                  Edit
                </button>
                <button 
                  onClick={() => {
                    handleDelete();
                    setShowMenu(false);
                  }}
                  className={`${styles.dropdownItem} ${styles.deleteItem}`}
                >
                  Delete
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      <div className={styles.commentContent}>
        {showEditForm ? (
          <CommentForm
            postId={comment.postId}
            parentId={comment.parentId}
            placeholder="Edit your comment..."
            onSubmit={handleEdit}
            onCancel={() => setShowEditForm(false)}
            autoFocus
            className={styles.editForm}
          />
        ) : (
          <p className={styles.content}>{comment.content}</p>
        )}
      </div>

      <div className={styles.commentActions}>
        <button 
          onClick={handleLike}
          className={`${styles.actionButton} ${comment.isLiked ? styles.liked : ''}`}
          disabled={isLiking}
        >
          <span className={styles.actionIcon}>
            {comment.isLiked ? '❤️' : '🤍'}
          </span>
          {comment.likesCount > 0 && (
            <span className={styles.actionCount}>{comment.likesCount}</span>
          )}
        </button>

        {canReply && (
          <button 
            onClick={() => setShowReplyForm(!showReplyForm)}
            className={styles.actionButton}
          >
            <span className={styles.actionIcon}>💬</span>
            Reply
          </button>
        )}
      </div>

      {showReplyForm && (
        <div className={styles.replyForm}>
          <CommentForm
            postId={comment.postId}
            parentId={comment.id}
            placeholder={`Reply to ${comment.user?.username}...`}
            onSubmit={handleReply}
            onCancel={() => setShowReplyForm(false)}
            autoFocus
          />
        </div>
      )}

      {comment.replies && comment.replies.length > 0 && (
        <div className={styles.replies}>
          {comment.replies.map((reply) => (
            <CommentCard
              key={reply.id}
              comment={reply}
              onLike={onLike}
              onReply={onReply}
              onEdit={onEdit}
              onDelete={onDelete}
              level={level + 1}
              maxLevel={maxLevel}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default CommentCard;