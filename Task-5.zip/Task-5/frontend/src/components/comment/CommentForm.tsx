import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import styles from './CommentForm.module.css';

interface CommentFormProps {
  postId: string;
  parentId?: string;
  placeholder?: string;
  onSubmit: (content: string) => Promise<void>;
  onCancel?: () => void;
  autoFocus?: boolean;
  className?: string;
}

const CommentForm: React.FC<CommentFormProps> = ({
  postId,
  parentId,
  placeholder = 'Write a comment...',
  onSubmit,
  onCancel,
  autoFocus = false,
  className = ''
}) => {
  const { state } = useAuth();
  const [content, setContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!content.trim()) return;

    try {
      setIsSubmitting(true);
      await onSubmit(content.trim());
      setContent(''); // Clear form on success
    } catch (error) {
      console.error('Failed to submit comment:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    setContent('');
    if (onCancel) {
      onCancel();
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  if (!state.user) {
    return (
      <div className={`${styles.loginPrompt} ${className}`}>
        <p>Please log in to comment</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className={`${styles.commentForm} ${className}`}>
      <div className={styles.userInfo}>
        <div className={styles.avatar}>
          {state.user.profileImageUrl ? (
            <img 
              src={state.user.profileImageUrl} 
              alt={state.user.username}
              className={styles.avatarImage}
            />
          ) : (
            <div className={styles.avatarPlaceholder}>
              {state.user.username.charAt(0).toUpperCase()}
            </div>
          )}
        </div>
      </div>

      <div className={styles.inputSection}>
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder={placeholder}
          className={styles.textarea}
          rows={2}
          autoFocus={autoFocus}
          disabled={isSubmitting}
          maxLength={500}
        />
        
        <div className={styles.formActions}>
          <div className={styles.characterCount}>
            <span className={content.length > 450 ? styles.warning : ''}>
              {content.length}/500
            </span>
          </div>
          
          <div className={styles.buttons}>
            {(onCancel || content.length > 0) && (
              <button
                type="button"
                onClick={handleCancel}
                className={styles.cancelButton}
                disabled={isSubmitting}
              >
                Cancel
              </button>
            )}
            
            <button
              type="submit"
              className={styles.submitButton}
              disabled={!content.trim() || isSubmitting}
            >
              {isSubmitting ? 'Posting...' : parentId ? 'Reply' : 'Comment'}
            </button>
          </div>
        </div>
      </div>
    </form>
  );
};

export default CommentForm;