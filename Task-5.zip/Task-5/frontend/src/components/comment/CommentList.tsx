import React, { useState, useEffect } from 'react';
import { Comment } from '../../types';
import CommentCard from './CommentCard';
import CommentForm from './CommentForm';
import styles from './CommentList.module.css';

interface CommentListProps {
  postId: string;
  comments?: Comment[];
  loading?: boolean;
  error?: string | null;
  onAddComment?: (postId: string, content: string) => Promise<void>;
  onReplyComment?: (commentId: string, content: string) => Promise<void>;
  onEditComment?: (commentId: string, content: string) => Promise<void>;
  onDeleteComment?: (commentId: string) => void;
  onLikeComment?: (commentId: string) => void;
  showAddForm?: boolean;
  maxLevel?: number;
  className?: string;
}

const CommentList: React.FC<CommentListProps> = ({
  postId,
  comments = [],
  loading = false,
  error = null,
  onAddComment,
  onReplyComment,
  onEditComment,
  onDeleteComment,
  onLikeComment,
  showAddForm = true,
  maxLevel = 3,
  className = ''
}) => {
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'popular'>('newest');
  const [showAllComments, setShowAllComments] = useState(false);

  // Sort comments based on selected criteria
  const sortedComments = [...comments].sort((a, b) => {
    switch (sortBy) {
      case 'oldest':
        return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      case 'popular':
        return b.likesCount - a.likesCount;
      case 'newest':
      default:
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
  });

  // Show limited comments initially
  const displayComments = showAllComments ? sortedComments : sortedComments.slice(0, 5);
  const hasMoreComments = comments.length > 5;

  const handleAddComment = async (content: string) => {
    if (!onAddComment) return;
    
    try {
      await onAddComment(postId, content);
    } catch (error) {
      throw error; // Let CommentForm handle the error
    }
  };

  if (loading) {
    return (
      <div className={`${styles.commentList} ${className}`}>
        <div className={styles.header}>
          <h3 className={styles.title}>Comments</h3>
        </div>
        
        <div className={styles.loadingContainer}>
          {[...Array(3)].map((_, index) => (
            <div key={index} className={styles.commentSkeleton}>
              <div className={styles.skeletonAvatar}></div>
              <div className={styles.skeletonContent}>
                <div className={styles.skeletonLine}></div>
                <div className={styles.skeletonLine}></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`${styles.commentList} ${className}`}>
        <div className={styles.header}>
          <h3 className={styles.title}>Comments</h3>
        </div>
        
        <div className={styles.errorContainer}>
          <p className={styles.errorMessage}>⚠️ {error}</p>
          <button 
            onClick={() => window.location.reload()} 
            className={styles.retryButton}
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={`${styles.commentList} ${className}`}>
      <div className={styles.header}>
        <h3 className={styles.title}>
          Comments ({comments.length})
        </h3>
        
        {comments.length > 0 && (
          <div className={styles.sortContainer}>
            <label htmlFor="sort-select" className={styles.sortLabel}>
              Sort by:
            </label>
            <select
              id="sort-select"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'newest' | 'oldest' | 'popular')}
              className={styles.sortSelect}
            >
              <option value="newest">Newest</option>
              <option value="oldest">Oldest</option>
              <option value="popular">Most Liked</option>
            </select>
          </div>
        )}
      </div>

      {showAddForm && (
        <div className={styles.addCommentSection}>
          <CommentForm
            postId={postId}
            placeholder="Write a comment..."
            onSubmit={handleAddComment}
          />
        </div>
      )}

      {comments.length === 0 ? (
        <div className={styles.emptyContainer}>
          <p className={styles.emptyMessage}>
            💬 No comments yet
          </p>
          <p className={styles.emptySubtext}>
            Be the first to share your thoughts!
          </p>
        </div>
      ) : (
        <div className={styles.commentsContainer}>
          {displayComments.map((comment) => (
            <CommentCard
              key={comment.id}
              comment={comment}
              onLike={onLikeComment}
              onReply={onReplyComment}
              onEdit={onEditComment}
              onDelete={onDeleteComment}
              maxLevel={maxLevel}
            />
          ))}
          
          {hasMoreComments && !showAllComments && (
            <button
              onClick={() => setShowAllComments(true)}
              className={styles.showMoreButton}
            >
              Show {comments.length - 5} more comments
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default CommentList;