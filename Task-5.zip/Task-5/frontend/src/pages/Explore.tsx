import React, { useState, useEffect } from 'react';
import { Layout } from '../components/layout';
import { UserList } from '../components/user';
import { User } from '../types';
import styles from './Explore.module.css';

const Explore: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | undefined>(undefined);
  const [followingUsers, setFollowingUsers] = useState<Set<string>>(new Set());
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'suggested' | 'trending'>('all');

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setLoading(true);
        setError(undefined);
        
        // Mock data for demonstration
        // In a real app, this would be an API call
        const mockUsers: User[] = [
          {
            id: '1',
            username: 'alex_johnson',
            email: 'alex@example.com',
            firstName: 'Alex',
            lastName: 'Johnson',
            bio: 'Software developer passionate about React and TypeScript. Love building amazing user experiences.',
            profileImageUrl: undefined,
            followersCount: 1250,
            followingCount: 350,
            postsCount: 89,
            isVerified: true,
            createdAt: new Date('2023-01-15').toISOString(),
            updatedAt: new Date().toISOString()
          },
          {
            id: '2',
            username: 'sarah_design',
            email: 'sarah@example.com',
            firstName: 'Sarah',
            lastName: 'Wilson',
            bio: 'UI/UX Designer creating beautiful and intuitive digital experiences. Coffee enthusiast and traveler.',
            profileImageUrl: undefined,
            followersCount: 890,
            followingCount: 420,
            postsCount: 156,
            isVerified: false,
            createdAt: new Date('2023-03-22').toISOString(),
            updatedAt: new Date().toISOString()
          },
          {
            id: '3',
            username: 'mike_photographer',
            email: 'mike@example.com',
            firstName: 'Mike',
            lastName: 'Chen',
            bio: 'Professional photographer capturing life\'s beautiful moments. Travel enthusiast and storyteller.',
            profileImageUrl: undefined,
            followersCount: 2100,
            followingCount: 180,
            postsCount: 412,
            isVerified: true,
            createdAt: new Date('2022-11-10').toISOString(),
            updatedAt: new Date().toISOString()
          },
          {
            id: '4',
            username: 'emma_writer',
            email: 'emma@example.com',
            firstName: 'Emma',
            lastName: 'Davis',
            bio: 'Content writer and storyteller. Sharing thoughts about technology, life, and everything in between.',
            profileImageUrl: undefined,
            followersCount: 650,
            followingCount: 280,
            postsCount: 203,
            isVerified: false,
            createdAt: new Date('2023-05-08').toISOString(),
            updatedAt: new Date().toISOString()
          },
          {
            id: '5',
            username: 'david_tech',
            email: 'david@example.com',
            firstName: 'David',
            lastName: 'Rodriguez',
            bio: 'Tech entrepreneur and startup founder. Building the future one line of code at a time.',
            profileImageUrl: undefined,
            followersCount: 3200,
            followingCount: 450,
            postsCount: 78,
            isVerified: true,
            createdAt: new Date('2022-08-12').toISOString(),
            updatedAt: new Date().toISOString()
          },
          {
            id: '6',
            username: 'lisa_fitness',
            email: 'lisa@example.com',
            firstName: 'Lisa',
            lastName: 'Thompson',
            bio: 'Fitness coach helping people achieve their health goals. Strong body, strong mind.',
            profileImageUrl: undefined,
            followersCount: 1800,
            followingCount: 320,
            postsCount: 234,
            isVerified: false,
            createdAt: new Date('2023-02-14').toISOString(),
            updatedAt: new Date().toISOString()
          }
        ];

        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        setUsers(mockUsers);
        
        // Random follow status for demonstration
        const randomFollowing = new Set<string>();
        mockUsers.forEach(user => {
          if (Math.random() > 0.7) {
            randomFollowing.add(user.id);
          }
        });
        setFollowingUsers(randomFollowing);
        
      } catch (err) {
        console.error('Failed to fetch users:', err);
        setError('Failed to load users');
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, [activeTab]);

  const handleFollowToggle = async (userId: string) => {
    try {
      const newFollowingUsers = new Set(followingUsers);
      const isCurrentlyFollowing = followingUsers.has(userId);
      
      if (isCurrentlyFollowing) {
        newFollowingUsers.delete(userId);
      } else {
        newFollowingUsers.add(userId);
      }
      
      setFollowingUsers(newFollowingUsers);
      
      // Update user follower count
      setUsers(prevUsers => 
        prevUsers.map(user => 
          user.id === userId 
            ? {
                ...user,
                followersCount: isCurrentlyFollowing 
                  ? user.followersCount - 1 
                  : user.followersCount + 1
              }
            : user
        )
      );
      
      // In a real app, make API call here
      console.log(`${isCurrentlyFollowing ? 'Unfollowed' : 'Followed'} user ${userId}`);
      
    } catch (err) {
      console.error('Failed to toggle follow:', err);
    }
  };

  const filteredUsers = users.filter(user =>
    user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.firstName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.lastName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.bio?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getTabUsers = () => {
    switch (activeTab) {
      case 'suggested':
        return filteredUsers.filter(user => !followingUsers.has(user.id)).slice(0, 3);
      case 'trending':
        return filteredUsers.sort((a, b) => b.followersCount - a.followersCount);
      default:
        return filteredUsers;
    }
  };

  return (
    <Layout>
      <div className={styles.exploreContainer}>
        <div className={styles.header}>
          <h1>Discover People</h1>
          <p>Find and connect with amazing people in our community</p>
        </div>

        {/* Search */}
        <div className={styles.searchSection}>
          <div className={styles.searchContainer}>
            <input
              type="text"
              placeholder="Search people..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className={styles.searchInput}
            />
            <button
              type="button"
              className={styles.searchButton}
              aria-label="Search"
            >
              <span aria-hidden="true">{String.fromCodePoint(0x1F50D)}</span>
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className={styles.tabNavigation}>
          <button
            className={`${styles.tab} ${activeTab === 'all' ? styles.active : ''}`}
            onClick={() => setActiveTab('all')}
          >
            All People
          </button>
          <button
            className={`${styles.tab} ${activeTab === 'suggested' ? styles.active : ''}`}
            onClick={() => setActiveTab('suggested')}
          >
            Suggested
          </button>
          <button
            className={`${styles.tab} ${activeTab === 'trending' ? styles.active : ''}`}
            onClick={() => setActiveTab('trending')}
          >
            Trending
          </button>
        </div>

        {/* Users List */}
        <div className={styles.usersSection}>
          <UserList
            users={getTabUsers()}
            loading={loading}
            error={error}
            emptyMessage={
              searchTerm 
                ? `No users found matching "${searchTerm}"` 
                : 'No users found'
            }
            showFollowButtons={true}
            followingUsers={followingUsers}
            onFollowToggle={handleFollowToggle}
            variant="grid"
          />
        </div>

        {/* Stats */}
        {!loading && !error && (
          <div className={styles.statsSection}>
            <div className={styles.stat}>
              <strong>{filteredUsers.length}</strong>
              <span>People found</span>
            </div>
            <div className={styles.stat}>
              <strong>{followingUsers.size}</strong>
              <span>Following</span>
            </div>
            <div className={styles.stat}>
              <strong>{users.reduce((sum, user) => sum + user.followersCount, 0).toLocaleString()}</strong>
              <span>Total followers</span>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Explore;