import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Layout } from '../components/layout';
import { CreatePost, PostFeed } from '../components/post';
import styles from './Home.module.css';

const Home: React.FC = () => {
  const { state } = useAuth();
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  const handlePostCreated = (post: any) => {
    // Trigger refresh of the post feed
    setRefreshTrigger(prev => prev + 1);
  };

  return (
    <Layout>
      <div className={styles.container}>
        <div className={styles.content}>
          <div className={styles.createPostSection}>
            <CreatePost onPostCreated={handlePostCreated} />
          </div>
          
          <div className={styles.feedSection}>
            <PostFeed refreshTrigger={refreshTrigger} />
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Home;