import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Layout } from '../components/layout';
import { User } from '../types';
import styles from './Profile.module.css';

const Profile: React.FC = () => {
  const { userId } = useParams<{ userId: string }>();
  const { state } = useAuth();
  const navigate = useNavigate();
  
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isFollowing, setIsFollowing] = useState(false);
  const [followLoading, setFollowLoading] = useState(false);

  const isOwnProfile = userId === state.user?.id;

  useEffect(() => {
    const fetchUser = async () => {
      if (!userId) {
        setError('User ID is required');
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setError(null);
        
        // In a real app, we would fetch from the API
        // For now, we'll use the current user or mock data
        if (userId === state.user?.id) {
          setUser(state.user);
        } else {
          // Mock user data for demonstration
          const mockUser: User = {
            id: userId,
            username: `user_${userId.slice(0, 8)}`,
            email: `user${userId}@example.com`,
            firstName: 'John',
            lastName: 'Doe',
            bio: 'This is a sample user profile. In a real application, this would be fetched from the backend API.',
            profileImageUrl: undefined,
            followersCount: Math.floor(Math.random() * 1000),
            followingCount: Math.floor(Math.random() * 500),
            postsCount: Math.floor(Math.random() * 100),
            isVerified: Math.random() > 0.7,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          };
          setUser(mockUser);
          setIsFollowing(Math.random() > 0.5); // Random follow status
        }
      } catch (err) {
        console.error('Failed to fetch user:', err);
        setError('Failed to load user profile');
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, [userId, state.user]);

  const handleFollowToggle = async () => {
    if (!user || isOwnProfile) return;

    try {
      setFollowLoading(true);
      
      // In a real app, we would call the follow/unfollow API
      // For now, we'll just toggle the state
      const newFollowState = !isFollowing;
      setIsFollowing(newFollowState);
      
      // Update follower count
      setUser(prev => prev ? {
        ...prev,
        followersCount: newFollowState 
          ? prev.followersCount + 1 
          : prev.followersCount - 1
      } : null);
      
    } catch (err) {
      console.error('Failed to toggle follow:', err);
      setError('Failed to update follow status');
    } finally {
      setFollowLoading(false);
    }
  };

  const handleEditProfile = () => {
    navigate('/settings/profile');
  };

  if (loading) {
    return (
      <Layout>
        <div className={styles.loadingContainer}>
          <div className={styles.loadingSkeleton}>
            <div className={styles.skeletonAvatar}></div>
            <div className={styles.skeletonContent}>
              <div className={styles.skeletonLine}></div>
              <div className={styles.skeletonLine}></div>
              <div className={styles.skeletonLine}></div>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (error || !user) {
    return (
      <Layout>
        <div className={styles.errorContainer}>
          <div className={styles.errorIcon}>⚠️</div>
          <div className={styles.errorMessage}>
            {error || 'User not found'}
          </div>
          <button 
            className={styles.retryButton}
            onClick={() => window.location.reload()}
          >
            Try Again
          </button>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className={styles.profileContainer}>
        {/* Profile Header */}
        <div className={styles.profileHeader}>
          {/* Cover Image */}
          <div className={styles.coverImage}>
            <div className={styles.coverPlaceholder}></div>
          </div>

          {/* Profile Info */}
          <div className={styles.profileInfo}>
            {/* Profile Image */}
            <div className={styles.profileImageContainer}>
              {user.profileImageUrl ? (
                <img 
                  src={user.profileImageUrl} 
                  alt={`${user.username}'s profile`}
                  className={styles.profileImage}
                />
              ) : (
                <div className={styles.profileAvatar}>
                  {user.username.charAt(0).toUpperCase()}
                </div>
              )}
              {user.isVerified && (
                <div className={styles.verifiedBadge} title="Verified Account">
                  ✓
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className={styles.actionButtons}>
              {isOwnProfile ? (
                <button 
                  className={styles.editButton}
                  onClick={handleEditProfile}
                >
                  Edit Profile
                </button>
              ) : (
                <button 
                  className={`${styles.followButton} ${isFollowing ? styles.following : styles.notFollowing}`}
                  onClick={handleFollowToggle}
                  disabled={followLoading}
                >
                  {followLoading ? '...' : (isFollowing ? 'Unfollow' : 'Follow')}
                </button>
              )}
            </div>
          </div>

          {/* User Details */}
          <div className={styles.userDetails}>
            <div className={styles.names}>
              <h1 className={styles.username}>
                {user.username}
                {user.isVerified && <span className={styles.verifiedIcon}>✓</span>}
              </h1>
              {(user.firstName || user.lastName) && (
                <div className={styles.displayName}>
                  {`${user.firstName || ''} ${user.lastName || ''}`.trim()}
                </div>
              )}
            </div>

            {user.bio && (
              <div className={styles.bio}>
                {user.bio}
              </div>
            )}

            <div className={styles.joinDate}>
              Joined {new Date(user.createdAt).toLocaleDateString('en-US', {
                month: 'long',
                year: 'numeric'
              })}
            </div>

            {/* User Stats */}
            <div className={styles.userStats}>
              <div className={styles.stat}>
                <strong>{user.postsCount}</strong>
                <span>Posts</span>
              </div>
              <div className={styles.stat}>
                <strong>{user.followingCount}</strong>
                <span>Following</span>
              </div>
              <div className={styles.stat}>
                <strong>{user.followersCount}</strong>
                <span>Followers</span>
              </div>
            </div>
          </div>
        </div>

        {/* Profile Content */}
        <div className={styles.profileContent}>
          {/* Navigation Tabs */}
          <div className={styles.tabNavigation}>
            <button className={`${styles.tab} ${styles.active}`}>
              Posts
            </button>
            <button className={styles.tab}>
              Media
            </button>
            <button className={styles.tab}>
              Likes
            </button>
          </div>

          {/* Posts Content */}
          <div className={styles.postsContainer}>
            <div className={styles.emptyPosts}>
              <div className={styles.emptyIcon}>📝</div>
              <div className={styles.emptyMessage}>
                {isOwnProfile 
                  ? "You haven't posted anything yet" 
                  : `${user.username} hasn't posted anything yet`
                }
              </div>
              {isOwnProfile && (
                <button className={styles.createPostButton}>
                  Create your first post
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Profile;