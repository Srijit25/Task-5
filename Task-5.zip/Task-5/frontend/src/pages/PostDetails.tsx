import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Layout } from '../components/layout';
import { PostCard } from '../components/post';
import { CommentList } from '../components/comment';
import { Post, Comment } from '../types';
import { postService } from '../services/postService';
import styles from './PostDetails.module.css';

const PostDetails: React.FC = () => {
  const { postId } = useParams<{ postId: string }>();
  const navigate = useNavigate();
  
  const [post, setPost] = useState<Post | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [commentsLoading, setCommentsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!postId) {
      navigate('/');
      return;
    }

    fetchPost();
    fetchComments();
  }, [postId, navigate]);

  const fetchPost = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await postService.getPost(postId!);
      setPost(response);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch post');
    } finally {
      setLoading(false);
    }
  };

  const fetchComments = async () => {
    try {
      setCommentsLoading(true);
      const response = await postService.getPostComments(postId!, 1, 50);
      setComments(response.data);
    } catch (err) {
      console.error('Failed to fetch comments:', err);
      // Don't set error for comments, just show empty state
    } finally {
      setCommentsLoading(false);
    }
  };

  const handleAddComment = async (postId: string, content: string) => {
    try {
      const newComment = await postService.createComment(postId, { content });
      setComments(prev => [newComment, ...prev]);
      
      // Update post comment count
      if (post) {
        setPost(prev => prev ? { ...prev, commentsCount: prev.commentsCount + 1 } : null);
      }
    } catch (error) {
      throw error; // Let CommentList handle the error
    }
  };

  const handleReplyComment = async (commentId: string, content: string) => {
    try {
      // For now, treat replies as top-level comments
      // TODO: Implement proper nested comment structure
      const newComment = await postService.createComment(post!.id, { content });
      setComments(prev => [newComment, ...prev]);
      
      // Update post comment count
      if (post) {
        setPost(prev => prev ? { ...prev, commentsCount: prev.commentsCount + 1 } : null);
      }
    } catch (error) {
      throw error; // Let CommentList handle the error
    }
  };

  const handleEditComment = async (commentId: string, content: string) => {
    try {
      const updatedComment = await postService.updateComment(commentId, { content });
      setComments(prev => 
        prev.map(comment => 
          comment.id === commentId ? updatedComment : comment
        )
      );
    } catch (error) {
      throw error; // Let CommentList handle the error
    }
  };

  const handleDeleteComment = async (commentId: string) => {
    try {
      await postService.deleteComment(commentId);
      setComments(prev => prev.filter(comment => comment.id !== commentId));
      
      // Update post comment count
      if (post) {
        setPost(prev => prev ? { ...prev, commentsCount: prev.commentsCount - 1 } : null);
      }
    } catch (error) {
      console.error('Failed to delete comment:', error);
    }
  };

  const handleLikeComment = async (commentId: string) => {
    try {
      const comment = comments.find(c => c.id === commentId);
      if (!comment) return;

      if (comment.isLiked) {
        await postService.unlikeComment(commentId);
      } else {
        await postService.likeComment(commentId);
      }

      // Update local state
      setComments(prev =>
        prev.map(comment =>
          comment.id === commentId
            ? {
                ...comment,
                isLiked: !comment.isLiked,
                likesCount: comment.isLiked ? comment.likesCount - 1 : comment.likesCount + 1
              }
            : comment
        )
      );
    } catch (error) {
      console.error('Failed to like/unlike comment:', error);
    }
  };

  const handlePostLike = async (postId: string) => {
    if (!post) return;

    try {
      if (post.isLiked) {
        await postService.unlikePost(postId);
      } else {
        await postService.likePost(postId);
      }

      // Update local state
      setPost(prev => prev ? {
        ...prev,
        isLiked: !prev.isLiked,
        likesCount: prev.isLiked ? prev.likesCount - 1 : prev.likesCount + 1
      } : null);
    } catch (error) {
      console.error('Failed to like/unlike post:', error);
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className={styles.container}>
          <div className={styles.loadingContainer}>
            <div className={styles.postSkeleton}>
              <div className={styles.skeletonHeader}>
                <div className={styles.skeletonAvatar}></div>
                <div className={styles.skeletonUserInfo}>
                  <div className={styles.skeletonLine}></div>
                  <div className={styles.skeletonLine}></div>
                </div>
              </div>
              <div className={styles.skeletonContent}>
                <div className={styles.skeletonLine}></div>
                <div className={styles.skeletonLine}></div>
                <div className={styles.skeletonLine}></div>
              </div>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (error || !post) {
    return (
      <Layout>
        <div className={styles.container}>
          <div className={styles.errorContainer}>
            <div className={styles.errorContent}>
              <h1>Post Not Found</h1>
              <p>{error || 'The post you\'re looking for doesn\'t exist or has been removed.'}</p>
              <button 
                onClick={() => navigate('/')}
                className={styles.backButton}
              >
                ← Back to Home
              </button>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className={styles.container}>
        <div className={styles.content}>
          <div className={styles.postSection}>
            <PostCard
              post={post}
              onLike={handlePostLike}
              onComment={() => {}} // Comments are shown below, not in a modal
              showActions={true}
              className={styles.detailsPostCard}
            />
          </div>

          <div className={styles.commentsSection}>
            <CommentList
              postId={post.id}
              comments={comments}
              loading={commentsLoading}
              onAddComment={handleAddComment}
              onReplyComment={handleReplyComment}
              onEditComment={handleEditComment}
              onDeleteComment={handleDeleteComment}
              onLikeComment={handleLikeComment}
              showAddForm={true}
              maxLevel={3}
            />
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default PostDetails;