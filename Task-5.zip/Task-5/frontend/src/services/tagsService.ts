import { api } from './api';
import { Tag, PaginatedResponse } from '../types';

export interface TagsQueryParams {
  page?: number;
  limit?: number;
  search?: string;
  category?: string;
  sortBy?: 'name' | 'usage' | 'created';
  sortOrder?: 'asc' | 'desc';
  minUsage?: number;
}

export interface TagWithStats extends Tag {
  usageCount: number;
  postsCount: number;
  followersCount: number;
  isFollowed?: boolean;
}

export interface TagCategory {
  id: string;
  name: string;
  description?: string;
  color?: string;
  tags: Tag[];
}

class TagsService {
  // Get all tags with optional filtering
  async getTags(params?: TagsQueryParams): Promise<PaginatedResponse<TagWithStats>> {
    const response = await api.get<PaginatedResponse<TagWithStats>>('/tags', params);
    return response.data;
  }

  // Get a single tag by ID
  async getTag(id: string): Promise<TagWithStats> {
    const response = await api.get<TagWithStats>(`/tags/${id}`);
    return response.data;
  }

  // Search tags by name
  async searchTags(query: string, limit?: number): Promise<Tag[]> {
    const response = await api.get<Tag[]>('/tags/search', { query, limit });
    return response.data;
  }

  // Create a new tag
  async createTag(data: { name: string; color?: string; description?: string }): Promise<Tag> {
    const response = await api.post<Tag>('/tags', data);
    return response.data;
  }

  // Update a tag
  async updateTag(id: string, data: { name?: string; color?: string; description?: string }): Promise<Tag> {
    const response = await api.patch<Tag>(`/tags/${id}`, data);
    return response.data;
  }

  // Delete a tag (admin only)
  async deleteTag(id: string): Promise<void> {
    await api.delete(`/tags/${id}`);
  }

  // Get popular/trending tags
  async getTrendingTags(timeframe: 'day' | 'week' | 'month' = 'week', limit?: number): Promise<TagWithStats[]> {
    const response = await api.get<TagWithStats[]>('/tags/trending', { timeframe, limit });
    return response.data;
  }

  // Get tag suggestions based on post content
  async getTagSuggestions(content: string, limit?: number): Promise<Tag[]> {
    const response = await api.post<Tag[]>('/tags/suggestions', { content, limit });
    return response.data;
  }

  // Get posts with a specific tag
  async getPostsByTag(tagId: string, params?: { page?: number; limit?: number }): Promise<PaginatedResponse<any>> {
    const response = await api.get<PaginatedResponse<any>>(`/tags/${tagId}/posts`, params);
    return response.data;
  }

  // Follow a tag
  async followTag(id: string): Promise<void> {
    await api.post(`/tags/${id}/follow`);
  }

  // Unfollow a tag
  async unfollowTag(id: string): Promise<void> {
    await api.delete(`/tags/${id}/follow`);
  }

  // Get followed tags for current user
  async getFollowedTags(params?: TagsQueryParams): Promise<PaginatedResponse<TagWithStats>> {
    const response = await api.get<PaginatedResponse<TagWithStats>>('/tags/followed', params);
    return response.data;
  }

  // Get tag categories
  async getTagCategories(): Promise<TagCategory[]> {
    const response = await api.get<TagCategory[]>('/tags/categories');
    return response.data;
  }

  // Get tags by category
  async getTagsByCategory(categoryId: string, params?: TagsQueryParams): Promise<PaginatedResponse<TagWithStats>> {
    const response = await api.get<PaginatedResponse<TagWithStats>>(`/tags/categories/${categoryId}/tags`, params);
    return response.data;
  }

  // Get tag statistics
  async getTagStats(id: string): Promise<{
    postsCount: number;
    commentsCount: number;
    followersCount: number;
    usageGrowth: { period: string; count: number }[];
  }> {
    const response = await api.get<{
      postsCount: number;
      commentsCount: number;
      followersCount: number;
      usageGrowth: { period: string; count: number }[];
    }>(`/tags/${id}/stats`);
    return response.data;
  }

  // Get related tags
  async getRelatedTags(id: string, limit?: number): Promise<TagWithStats[]> {
    const response = await api.get<TagWithStats[]>(`/tags/${id}/related`, { limit });
    return response.data;
  }

  // Get user's most used tags
  async getUserTopTags(userId: string, limit?: number): Promise<TagWithStats[]> {
    const response = await api.get<TagWithStats[]>(`/users/${userId}/top-tags`, { limit });
    return response.data;
  }

  // Merge tags (admin only)
  async mergeTags(sourceTagId: string, targetTagId: string): Promise<void> {
    await api.post(`/tags/${sourceTagId}/merge`, { targetTagId });
  }

  // Report a tag
  async reportTag(id: string, reason: string, details?: string): Promise<void> {
    await api.post(`/tags/${id}/report`, { reason, details });
  }

  // Get tag feed (posts from followed tags)
  async getTagFeed(params?: { page?: number; limit?: number }): Promise<PaginatedResponse<any>> {
    const response = await api.get<PaginatedResponse<any>>('/tags/feed', params);
    return response.data;
  }

  // Batch operations for tags
  async batchFollowTags(tagIds: string[]): Promise<void> {
    await api.post('/tags/batch/follow', { tagIds });
  }

  async batchUnfollowTags(tagIds: string[]): Promise<void> {
    await api.post('/tags/batch/unfollow', { tagIds });
  }

  // Get tag autocomplete suggestions
  async getAutocomplete(query: string, limit: number = 10): Promise<Tag[]> {
    const response = await api.get<Tag[]>('/tags/autocomplete', { query, limit });
    return response.data;
  }

  // Get tag history (for analytics)
  async getTagHistory(id: string, timeframe: 'day' | 'week' | 'month' = 'month'): Promise<{
    date: string;
    postsCount: number;
    usage: number;
  }[]> {
    const response = await api.get<{
      date: string;
      postsCount: number;
      usage: number;
    }[]>(`/tags/${id}/history`, { timeframe });
    return response.data;
  }

  // Validate tag name
  async validateTagName(name: string): Promise<{ isValid: boolean; message?: string }> {
    const response = await api.post<{ isValid: boolean; message?: string }>('/tags/validate', { name });
    return response.data;
  }

  // Get tag recommendations for user
  async getTagRecommendations(limit?: number): Promise<TagWithStats[]> {
    const response = await api.get<TagWithStats[]>('/tags/recommendations', { limit });
    return response.data;
  }
}

export const tagsService = new TagsService();