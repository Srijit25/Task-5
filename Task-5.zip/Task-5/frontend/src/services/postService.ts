import { api, uploadFile } from './api';
import { 
  Post, 
  Comment, 
  Like, 
  Tag,
  PostFormData,
  CommentFormData,
  PaginatedResponse,
  ApiResponse 
} from '../types';

export const postService = {
  // Get posts with pagination
  getPosts: async (page = 1, limit = 10, tag?: string): Promise<PaginatedResponse<Post>> => {
    const params: any = { page, limit };
    if (tag) params.tag = tag;
    
    const response = await api.get<PaginatedResponse<Post>>('/posts', params);
    return response.data;
  },

  // Get user's posts
  getUserPosts: async (userId: string, page = 1, limit = 10): Promise<PaginatedResponse<Post>> => {
    const response = await api.get<PaginatedResponse<Post>>(`/users/${userId}/posts`, { page, limit });
    return response.data;
  },

  // Get current user's posts
  getMyPosts: async (page = 1, limit = 10): Promise<PaginatedResponse<Post>> => {
    const response = await api.get<PaginatedResponse<Post>>('/posts/me', { page, limit });
    return response.data;
  },

  // Get post by ID
  getPost: async (postId: string): Promise<Post> => {
    const response = await api.get<Post>(`/posts/${postId}`);
    return response.data;
  },

  // Create new post
  createPost: async (data: PostFormData & { image?: File }): Promise<Post> => {
    let mediaUrl: string | undefined;
    
    // Upload media file if provided
    if (data.image) {
      try {
        const uploadResponse = await uploadFile('/uploads/media', data.image);
        mediaUrl = uploadResponse.data.url;
      } catch (error) {
        throw new Error('Failed to upload media file');
      }
    }

    const postData = {
      content: data.content,
      media_url: mediaUrl,
      media_type: data.image?.type.startsWith('image/') ? 'image' : 
                  data.image?.type.startsWith('video/') ? 'video' : undefined,
      tags: data.tags,
    };

    const response = await api.post<Post>('/posts', postData);
    return response.data;
  },

  // Update post
  updatePost: async (postId: string, data: Partial<PostFormData & { image?: File }>): Promise<Post> => {
    let mediaUrl: string | undefined;
    
    // Upload new media file if provided
    if (data.image) {
      try {
        const uploadResponse = await uploadFile('/uploads/media', data.image);
        mediaUrl = uploadResponse.data.url;
      } catch (error) {
        throw new Error('Failed to upload media file');
      }
    }

    const updateData: any = {};
    if (data.content !== undefined) updateData.content = data.content;
    if (mediaUrl) {
      updateData.media_url = mediaUrl;
      updateData.media_type = data.image?.type.startsWith('image/') ? 'image' : 
                             data.image?.type.startsWith('video/') ? 'video' : undefined;
    }
    if (data.tags !== undefined) updateData.tags = data.tags;

    const response = await api.put<Post>(`/posts/${postId}`, updateData);
    return response.data;
  },

  // Delete post
  deletePost: async (postId: string): Promise<void> => {
    await api.delete<void>(`/posts/${postId}`);
  },

  // Like/Unlike post
  likePost: async (postId: string): Promise<Like> => {
    const response = await api.post<Like>(`/posts/${postId}/like`);
    return response.data;
  },

  unlikePost: async (postId: string): Promise<void> => {
    await api.delete<void>(`/posts/${postId}/like`);
  },

  // Get post likes
  getPostLikes: async (postId: string, page = 1, limit = 10): Promise<PaginatedResponse<Like>> => {
    const response = await api.get<PaginatedResponse<Like>>(`/posts/${postId}/likes`, { page, limit });
    return response.data;
  },

  // Comments
  getPostComments: async (postId: string, page = 1, limit = 10): Promise<PaginatedResponse<Comment>> => {
    const response = await api.get<PaginatedResponse<Comment>>(`/posts/${postId}/comments`, { page, limit });
    return response.data;
  },

  createComment: async (postId: string, data: CommentFormData): Promise<Comment> => {
    const response = await api.post<Comment>(`/posts/${postId}/comments`, data);
    return response.data;
  },

  updateComment: async (commentId: string, data: Partial<CommentFormData>): Promise<Comment> => {
    const response = await api.put<Comment>(`/comments/${commentId}`, data);
    return response.data;
  },

  deleteComment: async (commentId: string): Promise<void> => {
    await api.delete<void>(`/comments/${commentId}`);
  },

  likeComment: async (commentId: string): Promise<Like> => {
    const response = await api.post<Like>(`/comments/${commentId}/like`);
    return response.data;
  },

  unlikeComment: async (commentId: string): Promise<void> => {
    await api.delete<void>(`/comments/${commentId}/like`);
  },

  // Search posts
  searchPosts: async (query: string, page = 1, limit = 10): Promise<PaginatedResponse<Post>> => {
    const response = await api.get<PaginatedResponse<Post>>('/posts/search', { query, page, limit });
    return response.data;
  },

  // Get trending posts
  getTrendingPosts: async (page = 1, limit = 10): Promise<PaginatedResponse<Post>> => {
    const response = await api.get<PaginatedResponse<Post>>('/posts/trending', { page, limit });
    return response.data;
  },

  // Get posts by tag
  getPostsByTag: async (tagName: string, page = 1, limit = 10): Promise<PaginatedResponse<Post>> => {
    const response = await api.get<PaginatedResponse<Post>>(`/posts/tag/${tagName}`, { page, limit });
    return response.data;
  },

  // Get popular tags
  getPopularTags: async (limit = 20): Promise<Tag[]> => {
    const response = await api.get<Tag[]>('/tags/popular', { limit });
    return response.data;
  },

  // Get feed (posts from followed users)
  getFeed: async (page = 1, limit = 10): Promise<PaginatedResponse<Post>> => {
    const response = await api.get<PaginatedResponse<Post>>('/posts/feed', { page, limit });
    return response.data;
  }
};