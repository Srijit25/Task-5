﻿import { io, Socket } from 'socket.io-client';

class SocketService {
  private socket: Socket | null = null;
  private connected = false;

  public async connect(): Promise<boolean> {
    try {
      this.socket = io('http://localhost:3001');
      this.connected = true;
      return true;
    } catch {
      return false;
    }
  }

  public disconnect(): void {
    this.socket?.disconnect();
    this.connected = false;
  }

  public isConnected(): boolean {
    return this.connected;
  }

  public on(event: string, callback: (...args: any[]) => void): void {
    this.socket?.on(event, callback);
  }

  public emit(event: string, data?: any): void {
    this.socket?.emit(event, data);
  }
}

export const socketService = new SocketService();
export default socketService;
