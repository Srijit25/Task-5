import { api, uploadFile } from './api';
import { 
  User, 
  Follow,
  FollowStatus,
  ProfileFormData,
  PaginatedResponse,
  ApiResponse 
} from '../types';

export const userService = {
  // Get user profile
  getUser: async (userId: string): Promise<User> => {
    const response = await api.get<User>(`/users/${userId}`);
    return response.data;
  },

  // Get current user profile
  getCurrentUser: async (): Promise<User> => {
    const response = await api.get<User>('/users/me');
    return response.data;
  },

  // Update current user profile
  updateProfile: async (data: ProfileFormData): Promise<User> => {
    let profileImageUrl: string | undefined;
    
    // Upload profile image if provided
    if (data.profileImage) {
      try {
        const uploadResponse = await uploadFile('/uploads/profile', data.profileImage);
        profileImageUrl = uploadResponse.data.url;
      } catch (error) {
        throw new Error('Failed to upload profile image');
      }
    }

    const updateData: any = {};
    if (data.firstName !== undefined) updateData.firstName = data.firstName;
    if (data.lastName !== undefined) updateData.lastName = data.lastName;
    if (data.bio !== undefined) updateData.bio = data.bio;
    if (profileImageUrl) updateData.profileImageUrl = profileImageUrl;

    const response = await api.put<User>('/users/me', updateData);
    return response.data;
  },

  // Search users
  searchUsers: async (query: string, page = 1, limit = 10): Promise<PaginatedResponse<User>> => {
    const response = await api.get<PaginatedResponse<User>>('/users/search', { query, page, limit });
    return response.data;
  },

  // Get suggested users
  getSuggestedUsers: async (limit = 10): Promise<User[]> => {
    const response = await api.get<User[]>('/users/suggested', { limit });
    return response.data;
  },

  // Follow/Unfollow user
  followUser: async (userId: string): Promise<Follow> => {
    const response = await api.post<Follow>(`/users/${userId}/follow`);
    return response.data;
  },

  unfollowUser: async (userId: string): Promise<void> => {
    await api.delete<void>(`/users/${userId}/follow`);
  },

  // Get follow status
  getFollowStatus: async (userId: string): Promise<FollowStatus> => {
    const response = await api.get<FollowStatus>(`/users/${userId}/follow-status`);
    return response.data;
  },

  // Get followers
  getFollowers: async (userId: string, page = 1, limit = 10): Promise<PaginatedResponse<Follow>> => {
    const response = await api.get<PaginatedResponse<Follow>>(`/users/${userId}/followers`, { page, limit });
    return response.data;
  },

  // Get following
  getFollowing: async (userId: string, page = 1, limit = 10): Promise<PaginatedResponse<Follow>> => {
    const response = await api.get<PaginatedResponse<Follow>>(`/users/${userId}/following`, { page, limit });
    return response.data;
  },

  // Get current user's followers
  getMyFollowers: async (page = 1, limit = 10): Promise<PaginatedResponse<Follow>> => {
    const response = await api.get<PaginatedResponse<Follow>>('/users/me/followers', { page, limit });
    return response.data;
  },

  // Get current user's following
  getMyFollowing: async (page = 1, limit = 10): Promise<PaginatedResponse<Follow>> => {
    const response = await api.get<PaginatedResponse<Follow>>('/users/me/following', { page, limit });
    return response.data;
  },

  // Delete account
  deleteAccount: async (): Promise<void> => {
    await api.delete<void>('/users/me');
  },

  // Update privacy settings
  updatePrivacySettings: async (settings: {
    isPrivate?: boolean;
    allowMessagesFromAnyone?: boolean;
    showOnlineStatus?: boolean;
  }): Promise<User> => {
    const response = await api.put<User>('/users/me/privacy', settings);
    return response.data;
  },

  // Block/Unblock user
  blockUser: async (userId: string): Promise<void> => {
    await api.post<void>(`/users/${userId}/block`);
  },

  unblockUser: async (userId: string): Promise<void> => {
    await api.delete<void>(`/users/${userId}/block`);
  },

  // Get blocked users
  getBlockedUsers: async (page = 1, limit = 10): Promise<PaginatedResponse<User>> => {
    const response = await api.get<PaginatedResponse<User>>('/users/me/blocked', { page, limit });
    return response.data;
  },

  // Report user
  reportUser: async (userId: string, reason: string, description?: string): Promise<void> => {
    await api.post<void>(`/users/${userId}/report`, { reason, description });
  }
};