import { io, Socket } from 'socket.io-client';
import { tokenManager } from './api';

// Types for real-time events
export interface SocketEvents {
  // Connection events
  connect: () => void;
  disconnect: (reason: string) => void;
  error: (error: Error) => void;

  // Post events
  'post:created': (post: any) => void;
  'post:updated': (post: any) => void;
  'post:deleted': (postId: string) => void;
  'post:liked': (data: { postId: string; userId: string; likeCount: number }) => void;
  'post:unliked': (data: { postId: string; userId: string; likeCount: number }) => void;

  // Comment events
  'comment:created': (comment: any) => void;
  'comment:updated': (comment: any) => void;
  'comment:deleted': (commentId: string) => void;
  'comment:liked': (data: { commentId: string; userId: string; likeCount: number }) => void;
  'comment:unliked': (data: { commentId: string; userId: string; likeCount: number }) => void;

  // Notification events
  'notification:new': (notification: any) => void;
  'notification:read': (notificationId: string) => void;
  'notification:deleted': (notificationId: string) => void;

  // User events
  'user:online': (userId: string) => void;
  'user:offline': (userId: string) => void;
  'user:typing': (data: { userId: string; postId?: string; isTyping: boolean }) => void;

  // Direct message events
  'message:new': (message: any) => void;
  'message:read': (messageId: string) => void;
  'message:typing': (data: { userId: string; chatId: string; isTyping: boolean }) => void;

  // Follow events
  'follow:new': (data: { followerId: string; followingId: string }) => void;
  'follow:removed': (data: { followerId: string; followingId: string }) => void;
}

class SocketService {
  private socket: Socket | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectDelay = 1000;
  private eventListeners: Map<string, Set<Function>> = new Map();
  private isConnecting = false;

  /**
   * Connect to the Socket.io server
   */
  public async connect(userId?: string): Promise<void> {
    if (this.isConnecting || this.isConnected()) {
      return;
    }

    this.isConnecting = true;

    try {
      const token = await tokenManager.getToken();
      
      if (!token) {
        throw new Error('No authentication token available');
      }

      const serverUrl = process.env.REACT_APP_SOCKET_URL || 'http://localhost:3001';

      this.socket = io(serverUrl, {
        auth: {
          token,
          userId
        },
        transports: ['websocket', 'polling'],
        upgrade: true,
        rememberUpgrade: true,
        timeout: 20000,
        reconnection: true,
        reconnectionAttempts: this.maxReconnectAttempts,
        reconnectionDelay: this.reconnectDelay,
        reconnectionDelayMax: 5000
      });

      this.setupEventHandlers();
      this.isConnecting = false;

      // Wait for connection
      return new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          reject(new Error('Socket connection timeout'));
        }, 10000);

        this.socket!.on('connect', () => {
          clearTimeout(timeout);
          this.reconnectAttempts = 0;
          console.log('Socket connected successfully');
          resolve();
        });

        this.socket!.on('connect_error', (error) => {
          clearTimeout(timeout);
          this.isConnecting = false;
          reject(error);
        });
      });
    } catch (error) {
      this.isConnecting = false;
      console.error('Socket connection error:', error);
      throw error;
    }
  }

  /**
   * Disconnect from the Socket.io server
   */
  public disconnect(): void {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
    this.eventListeners.clear();
  }

  /**
   * Check if socket is connected
   */
  public isConnected(): boolean {
    return this.socket?.connected || false;
  }

  /**
   * Emit an event to the server
   */
  public emit<K extends keyof SocketEvents>(event: K, data?: any): void {
    if (this.socket && this.isConnected()) {
      this.socket.emit(event, data);
    } else {
      console.warn(`Cannot emit ${String(event)}: Socket not connected`);
    }
  }

  /**
   * Listen to an event from the server
   */
  public on<K extends keyof SocketEvents>(
    event: K,
    callback: SocketEvents[K]
  ): () => void {
    if (!this.eventListeners.has(event as string)) {
      this.eventListeners.set(event as string, new Set());
    }

    const listeners = this.eventListeners.get(event as string)!;
    listeners.add(callback);

    if (this.socket) {
      this.socket.on(event as string, callback);
    }

    // Return unsubscribe function
    return () => {
      this.off(event, callback);
    };
  }

  /**
   * Remove event listener
   */
  public off<K extends keyof SocketEvents>(
    event: K,
    callback: SocketEvents[K]
  ): void {
    const listeners = this.eventListeners.get(event as string);
    if (listeners) {
      listeners.delete(callback);
      if (listeners.size === 0) {
        this.eventListeners.delete(event as string);
      }
    }

    if (this.socket) {
      this.socket.off(event as string, callback);
    }
  }

  /**
   * Join a room for targeted updates
   */
  public joinRoom(roomId: string): void {
    this.emit('join:room' as any, { roomId });
  }

  /**
   * Leave a room
   */
  public leaveRoom(roomId: string): void {
    this.emit('leave:room' as any, { roomId });
  }

  /**
   * Send typing indicator
   */
  public sendTyping(data: { postId?: string; chatId?: string; isTyping: boolean }): void {
    this.emit('user:typing', data);
  }

  /**
   * Mark user as online
   */
  public setOnlineStatus(isOnline: boolean): void {
    if (isOnline) {
      this.emit('user:online' as any, {});
    } else {
      this.emit('user:offline' as any, {});
    }
  }

  /**
   * Get connection status
   */
  public getStatus(): {
    connected: boolean;
    reconnectAttempts: number;
    maxReconnectAttempts: number;
  } {
    return {
      connected: this.isConnected(),
      reconnectAttempts: this.reconnectAttempts,
      maxReconnectAttempts: this.maxReconnectAttempts
    };
  }

  /**
   * Setup internal event handlers
   */
  private setupEventHandlers(): void {
    if (!this.socket) return;

    this.socket.on('connect', () => {
      console.log('Socket connected:', this.socket!.id);
      this.setOnlineStatus(true);
    });

    this.socket.on('disconnect', (reason) => {
      console.log('Socket disconnected:', reason);
      this.setOnlineStatus(false);
    });

    this.socket.on('connect_error', (error) => {
      console.error('Socket connection error:', error);
      this.reconnectAttempts++;
    });

    this.socket.on('reconnect', (attempt) => {
      console.log('Socket reconnected after', attempt, 'attempts');
      this.reconnectAttempts = 0;
    });

    this.socket.on('reconnect_error', (error) => {
      console.error('Socket reconnection error:', error);
    });

    this.socket.on('reconnect_failed', () => {
      console.error('Socket reconnection failed after maximum attempts');
    });

    // Handle authentication errors
    this.socket.on('auth:error', async (error) => {
      console.error('Socket authentication error:', error);
      
      // Try to clear tokens and reconnect
      try {
        tokenManager.clearTokens();
        this.disconnect();
      } catch (refreshError) {
        console.error('Token management failed:', refreshError);
        this.disconnect();
      }
    });
  }

  /**
   * Force reconnection with new token
   */
  public async reconnectWithNewToken(): Promise<void> {
    this.disconnect();
    await this.connect();
  }
}

// Create singleton instance
export const socketService = new SocketService();

// Auto-connect when user is authenticated
if (typeof window !== 'undefined') {
  // Check if user is authenticated and auto-connect
  const checkAuthAndConnect = async () => {
    try {
      const token = await tokenManager.getToken();
      if (token && !socketService.isConnected()) {
        await socketService.connect();
      }
    } catch (error) {
      console.log('No token available for socket connection');
    }
  };

  // Connect when page loads
  document.addEventListener('DOMContentLoaded', checkAuthAndConnect);
  
  // Handle page visibility changes
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      socketService.setOnlineStatus(true);
    } else {
      socketService.setOnlineStatus(false);
    }
  });

  // Handle beforeunload
  window.addEventListener('beforeunload', () => {
    socketService.setOnlineStatus(false);
    socketService.disconnect();
  });
}