import { api, uploadFile } from './api';
import { Post, CreatePostData, UpdatePostData, PaginatedResponse } from '../types';

export interface PostsQueryParams {
  page?: number;
  limit?: number;
  tag?: string;
  author?: string;
  search?: string;
  sortBy?: 'created' | 'updated' | 'likes' | 'comments';
  sortOrder?: 'asc' | 'desc';
}

export interface PostStats {
  id: string;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  viewsCount: number;
}

class PostsService {
  // Get all posts with pagination and filtering
  async getPosts(params?: PostsQueryParams): Promise<PaginatedResponse<Post>> {
    const response = await api.get<PaginatedResponse<Post>>('/posts', params);
    return response.data;
  }

  // Get a single post by ID
  async getPost(id: string): Promise<Post> {
    const response = await api.get<Post>(`/posts/${id}`);
    return response.data;
  }

  // Create a new post
  async createPost(data: CreatePostData): Promise<Post> {
    const response = await api.post<Post>('/posts', data);
    return response.data;
  }

  // Update an existing post
  async updatePost(id: string, data: UpdatePostData): Promise<Post> {
    const response = await api.patch<Post>(`/posts/${id}`, data);
    return response.data;
  }

  // Delete a post
  async deletePost(id: string): Promise<void> {
    await api.delete(`/posts/${id}`);
  }

  // Upload media for a post
  async uploadPostMedia(file: File, onProgress?: (progress: number) => void): Promise<{ url: string }> {
    const response = await uploadFile('/posts/media', file, onProgress);
    return response.data;
  }

  // Get posts by user
  async getUserPosts(userId: string, params?: PostsQueryParams): Promise<PaginatedResponse<Post>> {
    const response = await api.get<PaginatedResponse<Post>>(`/users/${userId}/posts`, params);
    return response.data;
  }

  // Get posts user liked
  async getLikedPosts(params?: PostsQueryParams): Promise<PaginatedResponse<Post>> {
    const response = await api.get<PaginatedResponse<Post>>('/posts/liked', params);
    return response.data;
  }

  // Get trending posts
  async getTrendingPosts(timeframe: 'day' | 'week' | 'month' = 'week'): Promise<Post[]> {
    const response = await api.get<Post[]>('/posts/trending', { timeframe });
    return response.data;
  }

  // Search posts
  async searchPosts(query: string, params?: PostsQueryParams): Promise<PaginatedResponse<Post>> {
    const searchParams = { ...params, search: query };
    const response = await api.get<PaginatedResponse<Post>>('/posts/search', searchParams);
    return response.data;
  }

  // Get post statistics
  async getPostStats(id: string): Promise<PostStats> {
    const response = await api.get<PostStats>(`/posts/${id}/stats`);
    return response.data;
  }

  // Report a post
  async reportPost(id: string, reason: string, details?: string): Promise<void> {
    await api.post(`/posts/${id}/report`, { reason, details });
  }

  // Pin/unpin a post (for post authors)
  async togglePin(id: string): Promise<Post> {
    const response = await api.patch<Post>(`/posts/${id}/pin`);
    return response.data;
  }

  // Archive/unarchive a post
  async toggleArchive(id: string): Promise<Post> {
    const response = await api.patch<Post>(`/posts/${id}/archive`);
    return response.data;
  }

  // Get archived posts
  async getArchivedPosts(params?: PostsQueryParams): Promise<PaginatedResponse<Post>> {
    const response = await api.get<PaginatedResponse<Post>>('/posts/archived', params);
    return response.data;
  }

  // Get post drafts
  async getDrafts(params?: PostsQueryParams): Promise<PaginatedResponse<Post>> {
    const response = await api.get<PaginatedResponse<Post>>('/posts/drafts', params);
    return response.data;
  }

  // Save post as draft
  async saveDraft(data: CreatePostData): Promise<Post> {
    const response = await api.post<Post>('/posts/drafts', data);
    return response.data;
  }

  // Publish a draft
  async publishDraft(id: string): Promise<Post> {
    const response = await api.patch<Post>(`/posts/drafts/${id}/publish`);
    return response.data;
  }

  // Get posts feed (following users)
  async getFeed(params?: PostsQueryParams): Promise<PaginatedResponse<Post>> {
    const response = await api.get<PaginatedResponse<Post>>('/posts/feed', params);
    return response.data;
  }

  // Bookmark/unbookmark a post
  async toggleBookmark(id: string): Promise<void> {
    await api.patch(`/posts/${id}/bookmark`);
  }

  // Get bookmarked posts
  async getBookmarks(params?: PostsQueryParams): Promise<PaginatedResponse<Post>> {
    const response = await api.get<PaginatedResponse<Post>>('/posts/bookmarks', params);
    return response.data;
  }

  // Share a post
  async sharePost(id: string, platform?: string): Promise<{ shareUrl: string }> {
    const response = await api.post<{ shareUrl: string }>(`/posts/${id}/share`, { platform });
    return response.data;
  }

  // Get post sharing analytics
  async getSharingStats(id: string): Promise<{ platform: string; count: number }[]> {
    const response = await api.get<{ platform: string; count: number }[]>(`/posts/${id}/shares`);
    return response.data;
  }
}

export const postsService = new PostsService();