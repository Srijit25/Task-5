import { api } from './api';
import { Like, PaginatedResponse } from '../types';

export interface LikesQueryParams {
  page?: number;
  limit?: number;
  sortBy?: 'created';
  sortOrder?: 'asc' | 'desc';
}

export interface LikeTarget {
  id: string;
  type: 'post' | 'comment';
}

export interface LikeUser {
  id: string;
  name: string;
  avatar?: string;
  isVerified?: boolean;
}

export interface LikeWithUser {
  id: string;
  userId: string;
  targetId: string;
  targetType: 'post' | 'comment';
  createdAt: string;
  user: LikeUser;
}

class LikesService {
  // Like a post
  async likePost(postId: string): Promise<void> {
    await api.post(`/posts/${postId}/like`);
  }

  // Unlike a post
  async unlikePost(postId: string): Promise<void> {
    await api.delete(`/posts/${postId}/like`);
  }

  // Like a comment
  async likeComment(commentId: string): Promise<void> {
    await api.post(`/comments/${commentId}/like`);
  }

  // Unlike a comment
  async unlikeComment(commentId: string): Promise<void> {
    await api.delete(`/comments/${commentId}/like`);
  }

  // Get users who liked a post
  async getPostLikes(postId: string, params?: LikesQueryParams): Promise<PaginatedResponse<LikeWithUser>> {
    const response = await api.get<PaginatedResponse<LikeWithUser>>(`/posts/${postId}/likes`, params);
    return response.data;
  }

  // Get users who liked a comment
  async getCommentLikes(commentId: string, params?: LikesQueryParams): Promise<PaginatedResponse<LikeWithUser>> {
    const response = await api.get<PaginatedResponse<LikeWithUser>>(`/comments/${commentId}/likes`, params);
    return response.data;
  }

  // Check if user liked a post
  async isPostLiked(postId: string): Promise<{ isLiked: boolean }> {
    const response = await api.get<{ isLiked: boolean }>(`/posts/${postId}/like/status`);
    return response.data;
  }

  // Check if user liked a comment
  async isCommentLiked(commentId: string): Promise<{ isLiked: boolean }> {
    const response = await api.get<{ isLiked: boolean }>(`/comments/${commentId}/like/status`);
    return response.data;
  }

  // Get posts liked by a user
  async getUserLikedPosts(userId: string, params?: LikesQueryParams): Promise<PaginatedResponse<any>> {
    const response = await api.get<PaginatedResponse<any>>(`/users/${userId}/liked-posts`, params);
    return response.data;
  }

  // Get comments liked by a user
  async getUserLikedComments(userId: string, params?: LikesQueryParams): Promise<PaginatedResponse<any>> {
    const response = await api.get<PaginatedResponse<any>>(`/users/${userId}/liked-comments`, params);
    return response.data;
  }

  // Get like counts for multiple posts
  async getMultiplePostLikeCounts(postIds: string[]): Promise<Record<string, number>> {
    const response = await api.post<Record<string, number>>('/posts/like-counts', { postIds });
    return response.data;
  }

  // Get like counts for multiple comments
  async getMultipleCommentLikeCounts(commentIds: string[]): Promise<Record<string, number>> {
    const response = await api.post<Record<string, number>>('/comments/like-counts', { commentIds });
    return response.data;
  }

  // Get user's recent likes activity
  async getRecentLikes(params?: LikesQueryParams): Promise<PaginatedResponse<LikeWithUser & { target: LikeTarget }>> {
    const response = await api.get<PaginatedResponse<LikeWithUser & { target: LikeTarget }>>('/likes/recent', params);
    return response.data;
  }

  // Get like statistics for a user
  async getUserLikeStats(userId: string): Promise<{
    totalLikesGiven: number;
    totalLikesReceived: number;
    postsLiked: number;
    commentsLiked: number;
  }> {
    const response = await api.get<{
      totalLikesGiven: number;
      totalLikesReceived: number;
      postsLiked: number;
      commentsLiked: number;
    }>(`/users/${userId}/like-stats`);
    return response.data;
  }

  // Toggle like for post (like if not liked, unlike if liked)
  async togglePostLike(postId: string): Promise<{ isLiked: boolean; likeCount: number }> {
    const response = await api.patch<{ isLiked: boolean; likeCount: number }>(`/posts/${postId}/like/toggle`);
    return response.data;
  }

  // Toggle like for comment (like if not liked, unlike if liked)
  async toggleCommentLike(commentId: string): Promise<{ isLiked: boolean; likeCount: number }> {
    const response = await api.patch<{ isLiked: boolean; likeCount: number }>(`/comments/${commentId}/like/toggle`);
    return response.data;
  }

  // Get trending liked content
  async getTrendingLikedContent(type: 'posts' | 'comments', timeframe: 'day' | 'week' | 'month' = 'week'): Promise<any[]> {
    const response = await api.get<any[]>(`/likes/trending/${type}`, { timeframe });
    return response.data;
  }

  // Get like notifications for user
  async getLikeNotifications(params?: LikesQueryParams): Promise<PaginatedResponse<{
    id: string;
    type: 'post_like' | 'comment_like';
    user: LikeUser;
    target: LikeTarget;
    createdAt: string;
    isRead: boolean;
  }>> {
    const response = await api.get<PaginatedResponse<{
      id: string;
      type: 'post_like' | 'comment_like';
      user: LikeUser;
      target: LikeTarget;
      createdAt: string;
      isRead: boolean;
    }>>('/notifications/likes', params);
    return response.data;
  }

  // Batch like operations
  async batchLike(targets: Array<{ id: string; type: 'post' | 'comment' }>): Promise<void> {
    await api.post('/likes/batch', { targets });
  }

  // Batch unlike operations
  async batchUnlike(targets: Array<{ id: string; type: 'post' | 'comment' }>): Promise<void> {
    await api.post('/likes/batch/unlike', { targets });
  }
}

export const likesService = new LikesService();