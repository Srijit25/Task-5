import { api } from './api';
import { Comment, CreateCommentData, UpdateCommentData, PaginatedResponse } from '../types';

export interface CommentsQueryParams {
  page?: number;
  limit?: number;
  sortBy?: 'created' | 'updated' | 'likes';
  sortOrder?: 'asc' | 'desc';
  includeReplies?: boolean;
}

export interface CommentThread {
  comment: Comment;
  replies: Comment[];
  totalReplies: number;
  hasMoreReplies: boolean;
}

class CommentsService {
  // Get comments for a post
  async getPostComments(postId: string, params?: CommentsQueryParams): Promise<PaginatedResponse<Comment>> {
    const response = await api.get<PaginatedResponse<Comment>>(`/posts/${postId}/comments`, params);
    return response.data;
  }

  // Get comment threads for a post (comments with their replies)
  async getPostCommentThreads(postId: string, params?: CommentsQueryParams): Promise<PaginatedResponse<CommentThread>> {
    const response = await api.get<PaginatedResponse<CommentThread>>(`/posts/${postId}/comment-threads`, params);
    return response.data;
  }

  // Get a single comment by ID
  async getComment(id: string): Promise<Comment> {
    const response = await api.get<Comment>(`/comments/${id}`);
    return response.data;
  }

  // Create a new comment
  async createComment(postId: string, data: CreateCommentData): Promise<Comment> {
    const response = await api.post<Comment>(`/posts/${postId}/comments`, data);
    return response.data;
  }

  // Reply to a comment
  async replyToComment(commentId: string, data: CreateCommentData): Promise<Comment> {
    const response = await api.post<Comment>(`/comments/${commentId}/replies`, data);
    return response.data;
  }

  // Update a comment
  async updateComment(id: string, data: UpdateCommentData): Promise<Comment> {
    const response = await api.patch<Comment>(`/comments/${id}`, data);
    return response.data;
  }

  // Delete a comment
  async deleteComment(id: string): Promise<void> {
    await api.delete(`/comments/${id}`);
  }

  // Get replies to a comment
  async getCommentReplies(commentId: string, params?: CommentsQueryParams): Promise<PaginatedResponse<Comment>> {
    const response = await api.get<PaginatedResponse<Comment>>(`/comments/${commentId}/replies`, params);
    return response.data;
  }

  // Get comments by user
  async getUserComments(userId: string, params?: CommentsQueryParams): Promise<PaginatedResponse<Comment>> {
    const response = await api.get<PaginatedResponse<Comment>>(`/users/${userId}/comments`, params);
    return response.data;
  }

  // Pin/unpin a comment (for post authors)
  async togglePin(id: string): Promise<Comment> {
    const response = await api.patch<Comment>(`/comments/${id}/pin`);
    return response.data;
  }

  // Report a comment
  async reportComment(id: string, reason: string, details?: string): Promise<void> {
    await api.post(`/comments/${id}/report`, { reason, details });
  }

  // Get comment statistics
  async getCommentStats(id: string): Promise<{ likesCount: number; repliesCount: number }> {
    const response = await api.get<{ likesCount: number; repliesCount: number }>(`/comments/${id}/stats`);
    return response.data;
  }

  // Search comments in a post
  async searchPostComments(postId: string, query: string, params?: CommentsQueryParams): Promise<PaginatedResponse<Comment>> {
    const searchParams = { ...params, search: query };
    const response = await api.get<PaginatedResponse<Comment>>(`/posts/${postId}/comments/search`, searchParams);
    return response.data;
  }

  // Get recent comments across all posts
  async getRecentComments(params?: CommentsQueryParams): Promise<PaginatedResponse<Comment>> {
    const response = await api.get<PaginatedResponse<Comment>>('/comments/recent', params);
    return response.data;
  }

  // Get trending comments
  async getTrendingComments(timeframe: 'day' | 'week' | 'month' = 'week'): Promise<Comment[]> {
    const response = await api.get<Comment[]>('/comments/trending', { timeframe });
    return response.data;
  }

  // Get comment thread (comment with all its nested replies)
  async getCommentThread(commentId: string): Promise<CommentThread> {
    const response = await api.get<CommentThread>(`/comments/${commentId}/thread`);
    return response.data;
  }

  // Mark comment as read
  async markAsRead(id: string): Promise<void> {
    await api.patch(`/comments/${id}/read`);
  }

  // Mark multiple comments as read
  async markMultipleAsRead(commentIds: string[]): Promise<void> {
    await api.patch('/comments/mark-read', { commentIds });
  }

  // Get unread comments count
  async getUnreadCount(): Promise<{ count: number }> {
    const response = await api.get<{ count: number }>('/comments/unread-count');
    return response.data;
  }

  // Mention users in comment (for autocomplete)
  async searchMentionableUsers(query: string): Promise<Array<{ id: string; name: string; avatar?: string }>> {
    const response = await api.get<Array<{ id: string; name: string; avatar?: string }>>('/users/mentionable', { query });
    return response.data;
  }

  // Get comment mentions for current user
  async getMyMentions(params?: CommentsQueryParams): Promise<PaginatedResponse<Comment>> {
    const response = await api.get<PaginatedResponse<Comment>>('/comments/mentions', params);
    return response.data;
  }

  // Archive/unarchive a comment
  async toggleArchive(id: string): Promise<Comment> {
    const response = await api.patch<Comment>(`/comments/${id}/archive`);
    return response.data;
  }

  // Get archived comments
  async getArchivedComments(params?: CommentsQueryParams): Promise<PaginatedResponse<Comment>> {
    const response = await api.get<PaginatedResponse<Comment>>('/comments/archived', params);
    return response.data;
  }
}

export const commentsService = new CommentsService();