import { api, uploadFile } from './api';
import { User, PaginatedResponse } from '../types';

export interface UsersQueryParams {
  page?: number;
  limit?: number;
  search?: string;
  sortBy?: 'name' | 'joined' | 'posts' | 'followers';
  sortOrder?: 'asc' | 'desc';
  verified?: boolean;
}

export interface UserProfile extends User {
  postsCount: number;
  followersCount: number;
  followingCount: number;
  isFollowing?: boolean;
  isFollowedBy?: boolean;
  mutualFollowersCount?: number;
}

export interface UserStats {
  postsCount: number;
  commentsCount: number;
  likesGiven: number;
  likesReceived: number;
  followersCount: number;
  followingCount: number;
  joinDate: string;
  lastActivity: string;
}

export interface FollowRequest {
  id: string;
  from: User;
  to: User;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: string;
}

class UsersService {
  // Get all users with pagination and filtering
  async getUsers(params?: UsersQueryParams): Promise<PaginatedResponse<UserProfile>> {
    const response = await api.get<PaginatedResponse<UserProfile>>('/users', params);
    return response.data;
  }

  // Get a user profile by ID
  async getUserProfile(id: string): Promise<UserProfile> {
    const response = await api.get<UserProfile>(`/users/${id}`);
    return response.data;
  }

  // Search users
  async searchUsers(query: string, params?: UsersQueryParams): Promise<PaginatedResponse<UserProfile>> {
    const searchParams = { ...params, search: query };
    const response = await api.get<PaginatedResponse<UserProfile>>('/users/search', searchParams);
    return response.data;
  }

  // Update user profile
  async updateProfile(data: {
    name?: string;
    bio?: string;
    location?: string;
    website?: string;
    birthDate?: string;
  }): Promise<User> {
    const response = await api.patch<User>('/users/me', data);
    return response.data;
  }

  // Upload profile avatar
  async uploadAvatar(file: File, onProgress?: (progress: number) => void): Promise<{ url: string }> {
    const response = await uploadFile('/users/me/avatar', file, onProgress);
    return response.data;
  }

  // Upload profile banner
  async uploadBanner(file: File, onProgress?: (progress: number) => void): Promise<{ url: string }> {
    const response = await uploadFile('/users/me/banner', file, onProgress);
    return response.data;
  }

  // Follow a user
  async followUser(id: string): Promise<void> {
    await api.post(`/users/${id}/follow`);
  }

  // Unfollow a user
  async unfollowUser(id: string): Promise<void> {
    await api.delete(`/users/${id}/follow`);
  }

  // Get user followers
  async getUserFollowers(id: string, params?: UsersQueryParams): Promise<PaginatedResponse<UserProfile>> {
    const response = await api.get<PaginatedResponse<UserProfile>>(`/users/${id}/followers`, params);
    return response.data;
  }

  // Get users that a user is following
  async getUserFollowing(id: string, params?: UsersQueryParams): Promise<PaginatedResponse<UserProfile>> {
    const response = await api.get<PaginatedResponse<UserProfile>>(`/users/${id}/following`, params);
    return response.data;
  }

  // Get mutual followers between current user and another user
  async getMutualFollowers(id: string, params?: UsersQueryParams): Promise<PaginatedResponse<UserProfile>> {
    const response = await api.get<PaginatedResponse<UserProfile>>(`/users/${id}/mutual-followers`, params);
    return response.data;
  }

  // Get user statistics
  async getUserStats(id: string): Promise<UserStats> {
    const response = await api.get<UserStats>(`/users/${id}/stats`);
    return response.data;
  }

  // Block a user
  async blockUser(id: string): Promise<void> {
    await api.post(`/users/${id}/block`);
  }

  // Unblock a user
  async unblockUser(id: string): Promise<void> {
    await api.delete(`/users/${id}/block`);
  }

  // Get blocked users
  async getBlockedUsers(params?: UsersQueryParams): Promise<PaginatedResponse<User>> {
    const response = await api.get<PaginatedResponse<User>>('/users/me/blocked', params);
    return response.data;
  }

  // Report a user
  async reportUser(id: string, reason: string, details?: string): Promise<void> {
    await api.post(`/users/${id}/report`, { reason, details });
  }

  // Get user activity feed
  async getUserActivity(id: string, params?: { page?: number; limit?: number }): Promise<PaginatedResponse<any>> {
    const response = await api.get<PaginatedResponse<any>>(`/users/${id}/activity`, params);
    return response.data;
  }

  // Get suggested users to follow
  async getSuggestedUsers(limit?: number): Promise<UserProfile[]> {
    const response = await api.get<UserProfile[]>('/users/suggestions', { limit });
    return response.data;
  }

  // Get trending users
  async getTrendingUsers(timeframe: 'day' | 'week' | 'month' = 'week', limit?: number): Promise<UserProfile[]> {
    const response = await api.get<UserProfile[]>('/users/trending', { timeframe, limit });
    return response.data;
  }

  // Send follow request (for private accounts)
  async sendFollowRequest(id: string): Promise<void> {
    await api.post(`/users/${id}/follow-request`);
  }

  // Accept follow request
  async acceptFollowRequest(requestId: string): Promise<void> {
    await api.patch(`/users/follow-requests/${requestId}/accept`);
  }

  // Reject follow request
  async rejectFollowRequest(requestId: string): Promise<void> {
    await api.patch(`/users/follow-requests/${requestId}/reject`);
  }

  // Get pending follow requests
  async getFollowRequests(type: 'sent' | 'received', params?: UsersQueryParams): Promise<PaginatedResponse<FollowRequest>> {
    const response = await api.get<PaginatedResponse<FollowRequest>>(`/users/follow-requests/${type}`, params);
    return response.data;
  }

  // Update privacy settings
  async updatePrivacySettings(settings: {
    isPrivate?: boolean;
    showEmail?: boolean;
    showOnlineStatus?: boolean;
    allowMessageFrom?: 'everyone' | 'followers' | 'none';
  }): Promise<void> {
    await api.patch('/users/me/privacy', settings);
  }

  // Update notification settings
  async updateNotificationSettings(settings: {
    emailNotifications?: boolean;
    pushNotifications?: boolean;
    followNotifications?: boolean;
    likeNotifications?: boolean;
    commentNotifications?: boolean;
    mentionNotifications?: boolean;
  }): Promise<void> {
    await api.patch('/users/me/notifications', settings);
  }

  // Deactivate account
  async deactivateAccount(): Promise<void> {
    await api.patch('/users/me/deactivate');
  }

  // Reactivate account
  async reactivateAccount(): Promise<void> {
    await api.patch('/users/me/reactivate');
  }

  // Get user mentions
  async getUserMentions(params?: { page?: number; limit?: number }): Promise<PaginatedResponse<any>> {
    const response = await api.get<PaginatedResponse<any>>('/users/me/mentions', params);
    return response.data;
  }

  // Get user's saved posts
  async getSavedPosts(params?: { page?: number; limit?: number }): Promise<PaginatedResponse<any>> {
    const response = await api.get<PaginatedResponse<any>>('/users/me/saved-posts', params);
    return response.data;
  }

  // Export user data
  async exportUserData(): Promise<{ downloadUrl: string }> {
    const response = await api.post<{ downloadUrl: string }>('/users/me/export');
    return response.data;
  }

  // Get user verification status
  async getVerificationStatus(): Promise<{
    isVerified: boolean;
    verificationRequested: boolean;
    verificationRequestDate?: string;
  }> {
    const response = await api.get<{
      isVerified: boolean;
      verificationRequested: boolean;
      verificationRequestDate?: string;
    }>('/users/me/verification');
    return response.data;
  }

  // Request verification
  async requestVerification(documents: File[]): Promise<void> {
    // Use the first document for now, can be enhanced for multiple files
    if (documents.length > 0) {
      await uploadFile('/users/me/verification/request', documents[0]);
    }
  }

  // Batch follow users
  async batchFollowUsers(userIds: string[]): Promise<void> {
    await api.post('/users/batch/follow', { userIds });
  }

  // Get users who might know current user
  async getPeopleYouMayKnow(limit?: number): Promise<UserProfile[]> {
    const response = await api.get<UserProfile[]>('/users/suggestions/people-you-may-know', { limit });
    return response.data;
  }
}

export const usersService = new UsersService();