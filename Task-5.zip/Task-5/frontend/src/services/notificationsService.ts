import { api } from './api';
import { PaginatedResponse } from '../types';

export interface Notification {
  id: string;
  type: 'like' | 'comment' | 'follow' | 'mention' | 'post' | 'system';
  title: string;
  message: string;
  data?: Record<string, any>;
  isRead: boolean;
  createdAt: string;
  user?: {
    id: string;
    name: string;
    avatar?: string;
  };
  target?: {
    id: string;
    type: 'post' | 'comment' | 'user';
    title?: string;
  };
}

export interface NotificationSettings {
  emailNotifications: boolean;
  pushNotifications: boolean;
  inAppNotifications: boolean;
  followNotifications: boolean;
  likeNotifications: boolean;
  commentNotifications: boolean;
  mentionNotifications: boolean;
  postNotifications: boolean;
  systemNotifications: boolean;
  frequency: 'instant' | 'daily' | 'weekly' | 'never';
}

export interface NotificationsQueryParams {
  page?: number;
  limit?: number;
  type?: string;
  isRead?: boolean;
  sortBy?: 'created' | 'updated';
  sortOrder?: 'asc' | 'desc';
}

class NotificationsService {
  // Get all notifications for current user
  async getNotifications(params?: NotificationsQueryParams): Promise<PaginatedResponse<Notification>> {
    const response = await api.get<PaginatedResponse<Notification>>('/notifications', params);
    return response.data;
  }

  // Get unread notifications count
  async getUnreadCount(): Promise<{ count: number }> {
    const response = await api.get<{ count: number }>('/notifications/unread-count');
    return response.data;
  }

  // Mark notification as read
  async markAsRead(id: string): Promise<void> {
    await api.patch(`/notifications/${id}/read`);
  }

  // Mark multiple notifications as read
  async markMultipleAsRead(ids: string[]): Promise<void> {
    await api.patch('/notifications/mark-read', { ids });
  }

  // Mark all notifications as read
  async markAllAsRead(): Promise<void> {
    await api.patch('/notifications/mark-all-read');
  }

  // Delete a notification
  async deleteNotification(id: string): Promise<void> {
    await api.delete(`/notifications/${id}`);
  }

  // Delete multiple notifications
  async deleteMultipleNotifications(ids: string[]): Promise<void> {
    await api.post('/notifications/batch-delete', { ids });
  }

  // Delete all notifications
  async deleteAllNotifications(): Promise<void> {
    await api.delete('/notifications/all');
  }

  // Delete all read notifications
  async deleteAllReadNotifications(): Promise<void> {
    await api.delete('/notifications/read');
  }

  // Get notification settings
  async getNotificationSettings(): Promise<NotificationSettings> {
    const response = await api.get<NotificationSettings>('/notifications/settings');
    return response.data;
  }

  // Update notification settings
  async updateNotificationSettings(settings: Partial<NotificationSettings>): Promise<NotificationSettings> {
    const response = await api.patch<NotificationSettings>('/notifications/settings', settings);
    return response.data;
  }

  // Get notifications by type
  async getNotificationsByType(type: string, params?: NotificationsQueryParams): Promise<PaginatedResponse<Notification>> {
    const response = await api.get<PaginatedResponse<Notification>>(`/notifications/type/${type}`, params);
    return response.data;
  }

  // Subscribe to push notifications
  async subscribeToPushNotifications(subscription: PushSubscription): Promise<void> {
    await api.post('/notifications/push/subscribe', {
      endpoint: subscription.endpoint,
      keys: {
        p256dh: subscription.getKey('p256dh'),
        auth: subscription.getKey('auth')
      }
    });
  }

  // Unsubscribe from push notifications
  async unsubscribeFromPushNotifications(): Promise<void> {
    await api.delete('/notifications/push/unsubscribe');
  }

  // Test notification (for development)
  async sendTestNotification(type: string, title: string, message: string): Promise<void> {
    await api.post('/notifications/test', { type, title, message });
  }

  // Get notification statistics
  async getNotificationStats(): Promise<{
    total: number;
    unread: number;
    byType: Record<string, number>;
    last7Days: { date: string; count: number }[];
  }> {
    const response = await api.get<{
      total: number;
      unread: number;
      byType: Record<string, number>;
      last7Days: { date: string; count: number }[];
    }>('/notifications/stats');
    return response.data;
  }

  // Snooze notifications for a period
  async snoozeNotifications(duration: number): Promise<void> {
    await api.patch('/notifications/snooze', { duration });
  }

  // Unsnooze notifications
  async unsnoozeNotifications(): Promise<void> {
    await api.patch('/notifications/unsnooze');
  }

  // Get snooze status
  async getSnoozeStatus(): Promise<{ isSnoozed: boolean; until?: string }> {
    const response = await api.get<{ isSnoozed: boolean; until?: string }>('/notifications/snooze-status');
    return response.data;
  }

  // Export notifications
  async exportNotifications(format: 'json' | 'csv' = 'json'): Promise<{ downloadUrl: string }> {
    const response = await api.post<{ downloadUrl: string }>('/notifications/export', { format });
    return response.data;
  }

  // Get notification templates (for admin)
  async getNotificationTemplates(): Promise<Array<{
    id: string;
    type: string;
    title: string;
    template: string;
    variables: string[];
  }>> {
    const response = await api.get<Array<{
      id: string;
      type: string;
      title: string;
      template: string;
      variables: string[];
    }>>('/notifications/templates');
    return response.data;
  }

  // Send bulk notification (for admin)
  async sendBulkNotification(data: {
    title: string;
    message: string;
    type: string;
    userIds?: string[];
    tags?: string[];
    all?: boolean;
  }): Promise<{ sent: number; failed: number }> {
    const response = await api.post<{ sent: number; failed: number }>('/notifications/bulk', data);
    return response.data;
  }

  // Schedule notification (for admin)
  async scheduleNotification(data: {
    title: string;
    message: string;
    type: string;
    scheduledFor: string;
    userIds?: string[];
    tags?: string[];
    all?: boolean;
  }): Promise<{ id: string; scheduledFor: string }> {
    const response = await api.post<{ id: string; scheduledFor: string }>('/notifications/schedule', data);
    return response.data;
  }

  // Get scheduled notifications
  async getScheduledNotifications(): Promise<Array<{
    id: string;
    title: string;
    message: string;
    type: string;
    scheduledFor: string;
    status: 'pending' | 'sent' | 'cancelled';
    targetCount: number;
  }>> {
    const response = await api.get<Array<{
      id: string;
      title: string;
      message: string;
      type: string;
      scheduledFor: string;
      status: 'pending' | 'sent' | 'cancelled';
      targetCount: number;
    }>>('/notifications/scheduled');
    return response.data;
  }

  // Cancel scheduled notification
  async cancelScheduledNotification(id: string): Promise<void> {
    await api.delete(`/notifications/scheduled/${id}`);
  }

  // Mark notification as clicked
  async markAsClicked(id: string): Promise<void> {
    await api.patch(`/notifications/${id}/clicked`);
  }

  // Get notification delivery status
  async getDeliveryStatus(id: string): Promise<{
    email: { sent: boolean; delivered: boolean; opened: boolean };
    push: { sent: boolean; delivered: boolean; clicked: boolean };
    inApp: { sent: boolean; read: boolean; clicked: boolean };
  }> {
    const response = await api.get<{
      email: { sent: boolean; delivered: boolean; opened: boolean };
      push: { sent: boolean; delivered: boolean; clicked: boolean };
      inApp: { sent: boolean; read: boolean; clicked: boolean };
    }>(`/notifications/${id}/delivery-status`);
    return response.data;
  }
}

export const notificationsService = new NotificationsService();