// Export all services
export { api, apiRequest, tokenManager, uploadFile, healthCheck } from './api';
export { authService } from './authService';
export { postsService } from './postsService';
export { commentsService } from './commentsService';
export { likesService } from './likesService';
export { tagsService } from './tagsService';
export { usersService } from './usersService';
export { notificationsService } from './notificationsService';

// Export the new API client for compatibility
export { apiClient } from './apiClient';

// Re-export types for convenience
export type { PostsQueryParams, PostStats } from './postsService';
export type { CommentsQueryParams, CommentThread } from './commentsService';
export type { LikesQueryParams, LikeTarget, LikeUser, LikeWithUser } from './likesService';
export type { TagsQueryParams, TagWithStats, TagCategory } from './tagsService';
export type { UsersQueryParams, UserProfile, UserStats, FollowRequest } from './usersService';
export type { Notification, NotificationSettings, NotificationsQueryParams } from './notificationsService';