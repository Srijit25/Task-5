import React, { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';
import { User, AuthResponse, LoginFormData, RegisterFormData } from '../types';
import { authService } from '../services/authService';
import { tokenManager } from '../services/api';
import { socketService } from '../services/socketService';

// Auth state interface
interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

// Auth actions
type AuthAction =
  | { type: 'AUTH_START' }
  | { type: 'AUTH_SUCCESS'; payload: User }
  | { type: 'AUTH_FAILURE'; payload: string }
  | { type: 'AUTH_LOGOUT' }
  | { type: 'AUTH_CLEAR_ERROR' }
  | { type: 'AUTH_UPDATE_USER'; payload: User };

// Auth context interface
interface AuthContextType {
  state: AuthState;
  login: (credentials: LoginFormData) => Promise<void>;
  register: (userData: RegisterFormData) => Promise<void>;
  logout: () => Promise<void>;
  getCurrentUser: () => Promise<void>;
  updateUser: (user: User) => void;
  clearError: () => void;
}

// Initial state
const initialState: AuthState = {
  user: null,
  isAuthenticated: false,
  isLoading: false,
  error: null,
};

// Auth reducer
const authReducer = (state: AuthState, action: AuthAction): AuthState => {
  switch (action.type) {
    case 'AUTH_START':
      return {
        ...state,
        isLoading: true,
        error: null,
      };
    case 'AUTH_SUCCESS':
      return {
        ...state,
        user: action.payload,
        isAuthenticated: true,
        isLoading: false,
        error: null,
      };
    case 'AUTH_FAILURE':
      return {
        ...state,
        user: null,
        isAuthenticated: false,
        isLoading: false,
        error: action.payload,
      };
    case 'AUTH_LOGOUT':
      return {
        ...state,
        user: null,
        isAuthenticated: false,
        isLoading: false,
        error: null,
      };
    case 'AUTH_UPDATE_USER':
      return {
        ...state,
        user: action.payload,
      };
    case 'AUTH_CLEAR_ERROR':
      return {
        ...state,
        error: null,
      };
    default:
      return state;
  }
};

// Create context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Auth provider component
interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, initialState);

  // Check for existing authentication on mount
  useEffect(() => {
    const initializeAuth = async () => {
      const token = tokenManager.getToken();
      if (token) {
        try {
          dispatch({ type: 'AUTH_START' });
          const user = await authService.getCurrentUser();
          dispatch({ type: 'AUTH_SUCCESS', payload: user });
          
          // Initialize socket connection
          socketService.connect();
        } catch (error) {
          console.error('Failed to get current user:', error);
          tokenManager.clearTokens();
          dispatch({ type: 'AUTH_FAILURE', payload: 'Session expired' });
        }
      }
    };

    initializeAuth();
  }, []);

  // Login function
  const login = async (credentials: LoginFormData): Promise<void> => {
    try {
      dispatch({ type: 'AUTH_START' });
      
      const authResponse: AuthResponse = await authService.login(credentials);
      
      // Store tokens
      tokenManager.setTokens(authResponse.token, authResponse.refreshToken);
      
      // Set user state
      dispatch({ type: 'AUTH_SUCCESS', payload: authResponse.user });
      
      // Initialize socket connection
      socketService.connect();
    } catch (error: any) {
      dispatch({ type: 'AUTH_FAILURE', payload: error.message || 'Login failed' });
      throw error;
    }
  };

  // Register function
  const register = async (userData: RegisterFormData): Promise<void> => {
    try {
      dispatch({ type: 'AUTH_START' });
      
      const authResponse: AuthResponse = await authService.register(userData);
      
      // Store tokens
      tokenManager.setTokens(authResponse.token, authResponse.refreshToken);
      
      // Set user state
      dispatch({ type: 'AUTH_SUCCESS', payload: authResponse.user });
      
      // Initialize socket connection
      socketService.connect();
    } catch (error: any) {
      dispatch({ type: 'AUTH_FAILURE', payload: error.message || 'Registration failed' });
      throw error;
    }
  };

  // Logout function
  const logout = async (): Promise<void> => {
    try {
      // Call logout API
      await authService.logout();
    } catch (error) {
      // Even if logout API fails, we should still clear local state
      console.error('Logout API failed:', error);
    } finally {
      // Clear tokens and state
      tokenManager.clearTokens();
      dispatch({ type: 'AUTH_LOGOUT' });
      
      // Cleanup socket connection
      socketService.disconnect();
    }
  };

  // Get current user function
  const getCurrentUser = async (): Promise<void> => {
    try {
      dispatch({ type: 'AUTH_START' });
      const user = await authService.getCurrentUser();
      dispatch({ type: 'AUTH_SUCCESS', payload: user });
    } catch (error: any) {
      dispatch({ type: 'AUTH_FAILURE', payload: error.message || 'Failed to get user' });
      throw error;
    }
  };

  // Update user function
  const updateUser = (user: User): void => {
    dispatch({ type: 'AUTH_UPDATE_USER', payload: user });
  };

  // Clear error function
  const clearError = (): void => {
    dispatch({ type: 'AUTH_CLEAR_ERROR' });
  };

  // Context value
  const contextValue: AuthContextType = {
    state,
    login,
    register,
    logout,
    getCurrentUser,
    updateUser,
    clearError,
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook to use auth context
export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export default AuthContext;