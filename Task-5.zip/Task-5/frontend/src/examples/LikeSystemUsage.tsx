import React, { useState } from 'react';
import { LikeButton, LikesList } from '../components/like';

// Example Post Component with Like System Integration
export const PostWithLikes: React.FC<{ post: any }> = ({ post }) => {
  const [showLikesList, setShowLikesList] = useState(false);

  return (
    <div className="post">
      {/* Post content */}
      <div className="post-content">
        <h3>{post.title}</h3>
        <p>{post.content}</p>
      </div>

      {/* Like interactions */}
      <div className="post-actions">
        <LikeButton
          targetId={post.id}
          targetType="post"
          isLiked={post.isLiked}
          likesCount={post.likeCount}
          variant="default"
          onLike={async (targetId: string) => {
            console.log('Post liked:', targetId);
          }}
          onUnlike={async (targetId: string) => {
            console.log('Post unliked:', targetId);
          }}
          onShowLikes={(targetId: string, targetType: 'post' | 'comment') => {
            setShowLikesList(true);
          }}
        />

        {/* Show likes list button */}
        {post.likeCount > 0 && (
          <button
            onClick={() => setShowLikesList(true)}
            className="likes-count-button"
          >
            {post.likeCount} {post.likeCount === 1 ? 'like' : 'likes'}
          </button>
        )}
      </div>

      {/* Likes list modal */}
      {showLikesList && (
        <LikesList
          targetId={post.id}
          targetType="post"
          onClose={() => setShowLikesList(false)}
        />
      )}
    </div>
  );
};

// Example Comment Component with Like System Integration
export const CommentWithLikes: React.FC<{ comment: any }> = ({ comment }) => {
  const [showLikesList, setShowLikesList] = useState(false);

  return (
    <div className="comment">
      {/* Comment content */}
      <div className="comment-content">
        <strong>{comment.author.name}</strong>
        <p>{comment.content}</p>
      </div>

      {/* Like interactions */}
      <div className="comment-actions">
        <LikeButton
          targetId={comment.id}
          targetType="comment"
          isLiked={comment.isLiked}
          likesCount={comment.likeCount}
          variant="compact"
          onLike={async (targetId: string) => {
            console.log('Comment liked:', targetId);
          }}
          onUnlike={async (targetId: string) => {
            console.log('Comment unliked:', targetId);
          }}
          onShowLikes={(targetId: string, targetType: 'post' | 'comment') => {
            setShowLikesList(true);
          }}
        />

        {/* Show likes list for comments with multiple likes */}
        {comment.likeCount > 1 && (
          <button
            onClick={() => setShowLikesList(true)}
            className="likes-count-button small"
          >
            {comment.likeCount} likes
          </button>
        )}
      </div>

      {/* Likes list modal */}
      {showLikesList && (
        <LikesList
          targetId={comment.id}
          targetType="comment"
          onClose={() => setShowLikesList(false)}
        />
      )}
    </div>
  );
};

// Example usage in a Post Feed
export const PostFeed: React.FC = () => {
  const posts = [
    {
      id: '1',
      title: 'My First Post',
      content: 'This is my first post on the platform!',
      isLiked: false,
      likeCount: 5,
      comments: [
        {
          id: 'c1',
          content: 'Great post!',
          author: { name: 'John Doe' },
          isLiked: true,
          likeCount: 2
        }
      ]
    }
  ];

  return (
    <div className="post-feed">
      {posts.map(post => (
        <div key={post.id} className="post-container">
          <PostWithLikes post={post} />
          
          {/* Comments section */}
          <div className="comments-section">
            {post.comments.map(comment => (
              <CommentWithLikes key={comment.id} comment={comment} />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};