// User types
export interface User {
  id: string;
  username: string;
  email: string;
  firstName?: string;
  lastName?: string;
  bio?: string;
  profileImageUrl?: string;
  followersCount: number;
  followingCount: number;
  postsCount: number;
  isVerified: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreateUserData {
  username: string;
  email: string;
  password: string;
  firstName?: string;
  lastName?: string;
}

export interface UpdateUserData {
  firstName?: string;
  lastName?: string;
  bio?: string;
  profileImageUrl?: string;
}

export interface LoginData {
  email: string;
  password: string;
}

export interface AuthResponse {
  user: User;
  token: string;
  refreshToken: string;
}

// Post types
export interface Post {
  id: string;
  content: string;
  imageUrl?: string;
  videoUrl?: string;
  userId: string;
  user?: User;
  likesCount: number;
  commentsCount: number;
  isLiked?: boolean;
  tags: Tag[];
  createdAt: string;
  updatedAt: string;
}

export interface CreatePostData {
  content: string;
  imageUrl?: string;
  videoUrl?: string;
  tagIds?: string[];
}

export interface UpdatePostData {
  content?: string;
  imageUrl?: string;
  videoUrl?: string;
  tagIds?: string[];
}

// Comment types
export interface Comment {
  id: string;
  content: string;
  userId: string;
  postId: string;
  parentId?: string;
  user?: User;
  post?: Post;
  parent?: Comment;
  replies?: Comment[];
  likesCount: number;
  isLiked?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreateCommentData {
  content: string;
  postId: string;
  parentId?: string;
}

export interface UpdateCommentData {
  content: string;
}

// Like types
export interface Like {
  id: string;
  userId: string;
  postId?: string;
  commentId?: string;
  user?: User;
  post?: Post;
  comment?: Comment;
  createdAt: string;
}

export interface LikeStatus {
  isLiked: boolean;
  likesCount: number;
}

// Tag types
export interface Tag {
  id: string;
  name: string;
  description?: string;
  postsCount: number;
  followersCount: number;
  isFollowing?: boolean;
  color?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateTagData {
  name: string;
  description?: string;
  color?: string;
}

export interface UpdateTagData {
  name?: string;
  description?: string;
  color?: string;
}

// Follow types
export interface Follow {
  id: string;
  followerId: string;
  followeeId: string;
  follower?: User;
  followee?: User;
  createdAt: string;
}

export interface FollowStatus {
  isFollowing: boolean;
  followersCount: number;
  followingCount: number;
}

// API Response types
export interface ApiResponse<T> {
  data: T;
  message?: string;
  timestamp: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    currentPage: number;
    totalPages: number;
    totalItems: number;
    itemsPerPage: number;
    hasNextPage: boolean;
    hasPreviousPage: boolean;
  };
}

export interface ApiError {
  error: string;
  message: string;
  code: string;
  details?: object;
  timestamp: string;
}

// Query parameters
export interface PaginationParams {
  page?: number;
  limit?: number;
}

export interface SearchParams extends PaginationParams {
  q?: string;
  sortBy?: 'relevance' | 'date' | 'popularity';
  sortOrder?: 'asc' | 'desc';
}

export interface PostFilters extends PaginationParams {
  userId?: string;
  tagId?: string;
  includeUser?: boolean;
  includeTags?: boolean;
}

export interface UserFilters extends PaginationParams {
  search?: string;
  isVerified?: boolean;
}

// Form types
export interface LoginFormData {
  email: string;
  password: string;
}

export interface RegisterFormData {
  username: string;
  email: string;
  password: string;
  confirmPassword: string;
  firstName?: string;
  lastName?: string;
}

export interface PostFormData {
  content: string;
  image?: File;
  tags: string[];
}

export interface CommentFormData {
  content: string;
}

export interface ProfileFormData {
  firstName?: string;
  lastName?: string;
  bio?: string;
  profileImage?: File;
}

// UI State types
export interface LoadingState {
  isLoading: boolean;
  error?: string | null;
}

export interface ModalState {
  isOpen: boolean;
  type?: 'login' | 'register' | 'createPost' | 'editPost' | 'confirmDelete';
  data?: any;
}

export interface NotificationState {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  message: string;
  duration?: number;
}

// Theme types
export interface Theme {
  name: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    surface: string;
    text: string;
    textSecondary: string;
    border: string;
    error: string;
    success: string;
    warning: string;
  };
  typography: {
    fontFamily: string;
    fontSize: {
      xs: string;
      sm: string;
      md: string;
      lg: string;
      xl: string;
      xxl: string;
    };
    fontWeight: {
      normal: number;
      medium: number;
      semibold: number;
      bold: number;
    };
  };
  spacing: {
    xs: string;
    sm: string;
    md: string;
    lg: string;
    xl: string;
    xxl: string;
  };
  borderRadius: {
    sm: string;
    md: string;
    lg: string;
    full: string;
  };
}

// Socket.io types
export interface SocketEvents {
  'user:online': (userId: string) => void;
  'user:offline': (userId: string) => void;
  'post:liked': (data: { postId: string; userId: string; likesCount: number }) => void;
  'post:unliked': (data: { postId: string; userId: string; likesCount: number }) => void;
  'comment:created': (comment: Comment) => void;
  'comment:liked': (data: { commentId: string; userId: string; likesCount: number }) => void;
  'follow:created': (data: { followerId: string; followeeId: string }) => void;
  'follow:deleted': (data: { followerId: string; followeeId: string }) => void;
}