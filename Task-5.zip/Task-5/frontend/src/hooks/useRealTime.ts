import { useEffect, useCallback, useRef, useState } from 'react';
import { socketService, SocketEvents } from '../services/realTimeService';
import { useAuth } from '../contexts/AuthContext';

/**
 * Hook to manage socket connection lifecycle
 */
export const useSocket = () => {
  const { state } = useAuth();
  const [isConnected, setIsConnected] = useState(false);
  const [connectionError, setConnectionError] = useState<string | null>(null);

  useEffect(() => {
    if (state.isAuthenticated && state.user) {
      // Connect when user is authenticated
      socketService.connect(state.user.id)
        .then(() => {
          setIsConnected(true);
          setConnectionError(null);
        })
        .catch((error) => {
          setIsConnected(false);
          setConnectionError(error.message);
        });

      // Listen for connection status changes
      const handleConnect = () => setIsConnected(true);
      const handleDisconnect = () => setIsConnected(false);
      const handleError = (error: Error) => setConnectionError(error.message);

      socketService.on('connect', handleConnect);
      socketService.on('disconnect', handleDisconnect);
      socketService.on('error', handleError);

      return () => {
        socketService.off('connect', handleConnect);
        socketService.off('disconnect', handleDisconnect);
        socketService.off('error', handleError);
      };
    } else {
      // Disconnect when user is not authenticated
      socketService.disconnect();
      setIsConnected(false);
    }
  }, [state.isAuthenticated, state.user]);

  return {
    isConnected,
    connectionError,
    reconnect: () => socketService.connect(state.user?.id),
    disconnect: () => socketService.disconnect(),
    getStatus: () => socketService.getStatus()
  };
};

/**
 * Hook to listen to real-time events
 */
export const useSocketEvent = <T = any>(
  event: string,
  callback: (data: T) => void,
  dependencies: any[] = []
) => {
  const callbackRef = useRef(callback);
  callbackRef.current = callback;

  useEffect(() => {
    const handler = (data: T) => callbackRef.current(data);
    const unsubscribe = socketService.on(event as any, handler as any);
    return unsubscribe;
  }, [event, ...dependencies]);
};

/**
 * Hook for real-time post updates
 */
export const useRealTimePosts = (onPostUpdate?: (posts: any[]) => void) => {
  const [posts, setPosts] = useState<any[]>([]);

  const updatePosts = useCallback((updatedPosts: any[]) => {
    setPosts(updatedPosts);
    onPostUpdate?.(updatedPosts);
  }, [onPostUpdate]);

  useSocketEvent('post:created', (newPost) => {
    setPosts(currentPosts => [newPost, ...currentPosts]);
  });

  useSocketEvent('post:updated', (updatedPost) => {
    setPosts(currentPosts => 
      currentPosts.map(post => 
        post.id === updatedPost.id ? { ...post, ...updatedPost } : post
      )
    );
  });

  useSocketEvent('post:deleted', (postId) => {
    setPosts(currentPosts => 
      currentPosts.filter(post => post.id !== postId)
    );
  });

  useSocketEvent('post:liked', ({ postId, likeCount }) => {
    setPosts(currentPosts => 
      currentPosts.map(post => 
        post.id === postId ? { ...post, likeCount, isLiked: true } : post
      )
    );
  });

  useSocketEvent('post:unliked', ({ postId, likeCount }) => {
    setPosts(currentPosts => 
      currentPosts.map(post => 
        post.id === postId ? { ...post, likeCount, isLiked: false } : post
      )
    );
  });

  return {
    posts,
    updatePosts
  };
};

/**
 * Hook for real-time comment updates
 */
export const useRealTimeComments = (postId: string, onCommentUpdate?: (comments: any[]) => void) => {
  const [comments, setComments] = useState<any[]>([]);

  const updateComments = useCallback((updatedComments: any[]) => {
    setComments(updatedComments);
    onCommentUpdate?.(updatedComments);
  }, [onCommentUpdate]);

  useSocketEvent('comment:created', (newComment) => {
    if (newComment.postId === postId) {
      setComments(currentComments => [...currentComments, newComment]);
    }
  });

  useSocketEvent('comment:updated', (updatedComment) => {
    if (updatedComment.postId === postId) {
      setComments(currentComments => 
        currentComments.map(comment => 
          comment.id === updatedComment.id ? { ...comment, ...updatedComment } : comment
        )
      );
    }
  });

  useSocketEvent('comment:deleted', (commentId) => {
    setComments(currentComments => 
      currentComments.filter(comment => comment.id !== commentId)
    );
  });

  useSocketEvent('comment:liked', ({ commentId, likeCount }) => {
    setComments(currentComments => 
      currentComments.map(comment => 
        comment.id === commentId ? { ...comment, likeCount, isLiked: true } : comment
      )
    );
  });

  useSocketEvent('comment:unliked', ({ commentId, likeCount }) => {
    setComments(currentComments => 
      currentComments.map(comment => 
        comment.id === commentId ? { ...comment, likeCount, isLiked: false } : comment
      )
    );
  });

  return {
    comments,
    updateComments
  };
};

/**
 * Hook for real-time notifications
 */
export const useRealTimeNotifications = () => {
  const [notifications, setNotifications] = useState<any[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  useSocketEvent('notification:new', (notification) => {
    setNotifications(current => [notification, ...current]);
    setUnreadCount(current => current + 1);
    
    // Show browser notification if supported and permitted
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(notification.title || 'New notification', {
        body: notification.message,
        icon: '/favicon.ico',
        tag: notification.id
      });
    }
  });

  useSocketEvent('notification:read', (notificationId) => {
    setNotifications(current => 
      current.map(notification => 
        notification.id === notificationId 
          ? { ...notification, isRead: true } 
          : notification
      )
    );
    setUnreadCount(current => Math.max(0, current - 1));
  });

  useSocketEvent('notification:deleted', (notificationId) => {
    setNotifications(current => 
      current.filter(notification => notification.id !== notificationId)
    );
  });

  const markAsRead = useCallback((notificationId: string) => {
    socketService.emit('notification:read', notificationId);
  }, []);

  const markAllAsRead = useCallback(() => {
    socketService.emit('notification:read_all' as any, {});
    setUnreadCount(0);
    setNotifications(current => 
      current.map(notification => ({ ...notification, isRead: true }))
    );
  }, []);

  return {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    setNotifications
  };
};

/**
 * Hook for typing indicators
 */
export const useTypingIndicator = (postId?: string, chatId?: string) => {
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useSocketEvent('user:typing', (data: { userId: string; postId?: string; chatId?: string; isTyping: boolean }) => {
    const { userId, postId: eventPostId, chatId: eventChatId, isTyping } = data;
    const isRelevant = (postId && eventPostId === postId) || (chatId && eventChatId === chatId);
    
    if (isRelevant) {
      if (isTyping) {
        setTypingUsers(current => 
          current.includes(userId) ? current : [...current, userId]
        );
      } else {
        setTypingUsers(current => current.filter(id => id !== userId));
      }
    }
  });

  const sendTyping = useCallback((isTyping: boolean) => {
    socketService.sendTyping({ postId, chatId, isTyping });
    
    if (isTyping) {
      // Clear existing timeout
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      
      // Set timeout to stop typing after 3 seconds
      typingTimeoutRef.current = setTimeout(() => {
        socketService.sendTyping({ postId, chatId, isTyping: false });
      }, 3000);
    }
  }, [postId, chatId]);

  useEffect(() => {
    return () => {
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
    };
  }, []);

  return {
    typingUsers,
    sendTyping
  };
};

/**
 * Hook for online user status
 */
export const useOnlineUsers = () => {
  const [onlineUsers, setOnlineUsers] = useState<Set<string>>(new Set());

  useSocketEvent('user:online', (userId) => {
    setOnlineUsers(current => {
      const newSet = new Set(current);
      newSet.add(userId);
      return newSet;
    });
  });

  useSocketEvent('user:offline', (userId) => {
    setOnlineUsers(current => {
      const newSet = new Set(current);
      newSet.delete(userId);
      return newSet;
    });
  });

  const isUserOnline = useCallback((userId: string) => {
    return onlineUsers.has(userId);
  }, [onlineUsers]);

  return {
    onlineUsers: Array.from(onlineUsers),
    isUserOnline
  };
};

/**
 * Hook for real-time direct messages
 */
export const useRealTimeMessages = (chatId: string) => {
  const [messages, setMessages] = useState<any[]>([]);

  useSocketEvent('message:new', (message) => {
    if (message.chatId === chatId) {
      setMessages(current => [...current, message]);
    }
  });

  useSocketEvent('message:read', (messageId) => {
    setMessages(current => 
      current.map(message => 
        message.id === messageId ? { ...message, isRead: true } : message
      )
    );
  });

  const sendMessage = useCallback((content: string, type: 'text' | 'image' | 'file' = 'text') => {
    socketService.emit('message:send' as any, {
      chatId,
      content,
      type
    });
  }, [chatId]);

  const markAsRead = useCallback((messageId: string) => {
    socketService.emit('message:read', messageId);
  }, []);

  return {
    messages,
    sendMessage,
    markAsRead,
    setMessages
  };
};

/**
 * Hook to request browser notification permission
 */
export const useNotificationPermission = () => {
  const [permission, setPermission] = useState<NotificationPermission>(
    typeof window !== 'undefined' && 'Notification' in window 
      ? Notification.permission 
      : 'default'
  );

  const requestPermission = useCallback(async () => {
    if ('Notification' in window) {
      const result = await Notification.requestPermission();
      setPermission(result);
      return result;
    }
    return 'denied';
  }, []);

  return {
    permission,
    requestPermission,
    isSupported: typeof window !== 'undefined' && 'Notification' in window
  };
};