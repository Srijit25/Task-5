import { useState } from 'react';

interface UseMediaUploadOptions {
  maxFiles?: number;
  maxFileSize?: number; // in bytes
  allowedTypes?: string[];
}

interface UseMediaUploadReturn {
  selectedFiles: File[];
  previewUrls: string[];
  isUploading: boolean;
  error: string | null;
  handleFileSelect: (event: React.ChangeEvent<HTMLInputElement>) => void;
  handleRemoveFile: (index: number) => void;
  clearFiles: () => void;
  uploadFiles: () => Promise<string[]>;
}

export const useMediaUpload = (options: UseMediaUploadOptions = {}): UseMediaUploadReturn => {
  const {
    maxFiles = 4,
    maxFileSize = 10 * 1024 * 1024, // 10MB
    allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'video/mp4', 'video/webm']
  } = options;

  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [previewUrls, setPreviewUrls] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    setError(null);

    // Validate file count
    if (files.length > maxFiles) {
      setError(`You can only upload up to ${maxFiles} files`);
      return;
    }

    // Validate file types and sizes
    const validFiles: File[] = [];
    const errors: string[] = [];

    files.forEach((file, index) => {
      if (!allowedTypes.includes(file.type)) {
        errors.push(`File ${index + 1}: Invalid file type`);
        return;
      }

      if (file.size > maxFileSize) {
        errors.push(`File ${index + 1}: File too large (max ${Math.round(maxFileSize / 1024 / 1024)}MB)`);
        return;
      }

      validFiles.push(file);
    });

    if (errors.length > 0) {
      setError(errors.join(', '));
      return;
    }

    setSelectedFiles(validFiles);
    
    // Create preview URLs
    const urls = validFiles.map(file => URL.createObjectURL(file));
    
    // Clean up old URLs
    previewUrls.forEach(url => URL.revokeObjectURL(url));
    setPreviewUrls(urls);
  };

  const handleRemoveFile = (index: number) => {
    const newFiles = selectedFiles.filter((_, i) => i !== index);
    const newUrls = previewUrls.filter((_, i) => i !== index);
    
    // Revoke the removed URL to prevent memory leaks
    URL.revokeObjectURL(previewUrls[index]);
    
    setSelectedFiles(newFiles);
    setPreviewUrls(newUrls);
    setError(null);
  };

  const clearFiles = () => {
    // Revoke all URLs to prevent memory leaks
    previewUrls.forEach(url => URL.revokeObjectURL(url));
    
    setSelectedFiles([]);
    setPreviewUrls([]);
    setError(null);
  };

  const uploadFiles = async (): Promise<string[]> => {
    if (selectedFiles.length === 0) return [];

    setIsUploading(true);
    setError(null);

    try {
      // TODO: Implement actual upload logic
      // For now, return the preview URLs (mock)
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate upload delay
      
      return previewUrls;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Upload failed';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setIsUploading(false);
    }
  };

  return {
    selectedFiles,
    previewUrls,
    isUploading,
    error,
    handleFileSelect,
    handleRemoveFile,
    clearFiles,
    uploadFiles
  };
};