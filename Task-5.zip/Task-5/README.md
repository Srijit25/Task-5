# 🚀 Social Media Frontend

<div align="center">
  <p>
    <strong>A modern, responsive React application for the Social Media Platform</strong>
  </p>
  
  <p>
    <img src="https://img.shields.io/badge/React-18.0-61DAFB?style=for-the-badge&logo=react&logoColor=white" alt="React" />
    <img src="https://img.shields.io/badge/TypeScript-5.0-3178C6?style=for-the-badge&logo=typescript&logoColor=white" alt="TypeScript" />
    <img src="https://img.shields.io/badge/TanStack_Query-5.0-FF4154?style=for-the-badge&logo=reactquery&logoColor=white" alt="TanStack Query" />
    <img src="https://img.shields.io/badge/Socket.io-4.8-010101?style=for-the-badge&logo=socketdotio&logoColor=white" alt="Socket.io" />
  </p>

  <p>
    <img src="https://img.shields.io/badge/License-MIT-green.svg?style=for-the-badge" alt="License" />
    <img src="https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=for-the-badge" alt="PRs Welcome" />
    <img src="https://img.shields.io/badge/Maintained-Yes-brightgreen.svg?style=for-the-badge" alt="Maintained" />
  </p>
</div>

---

## ✨ Features

### 🔐 Authentication & Security
- JWT-based authentication system
- Protected routes with role-based access
- Automatic token refresh
- Secure session management

### 📱 Responsive Design
- Mobile-first approach
- CSS Modules for scoped styling
- Modern UI/UX patterns
- Cross-browser compatibility

### ⚡ Real-time Features
- Socket.io integration for live updates
- Real-time notifications
- Live chat functionality
- Connection status management

### 🛠️ Developer Experience
- Full TypeScript support
- ESLint & Prettier configuration
- Comprehensive testing setup
- Hot reload development

## 🏗️ Tech Stack

<div align="center">

| **Category** | **Technology** | **Version** | **Purpose** |
|:------------:|:--------------:|:-----------:|:------------|
| **Frontend** | React | ^19.1.1 | UI Framework |
| **Language** | TypeScript | ^4.9.5 | Type Safety |
| **Routing** | React Router | ^7.9.1 | Navigation |
| **State** | TanStack Query | ^5.89.0 | Server State |
| **HTTP** | Axios | ^1.12.2 | API Client |
| **Real-time** | Socket.io | ^4.8.1 | WebSocket |
| **Testing** | Jest + RTL | ^16.3.0 | Unit Testing |
| **Styling** | CSS Modules | - | Styling |

</div>

## 🚀 Quick Start

### Prerequisites

> **Node.js** `18.0.0` or higher  
> **npm** `8.0.0` or higher  
> **Backend API** running on `http://localhost:3001`

### Installation

```bash
# Clone the repository
git clone <repository-url>
cd frontend

# Install dependencies
npm install

# Create environment file
cp .env.example .env.local

# Start development server
npm start
```

The application will be available at **`http://localhost:3000`** 🎉

## 📁 Project Structure

```
frontend/
├── 📁 public/              # Static assets
├── 📁 src/
│   ├── 📁 components/      # Reusable UI components
│   │   ├── 📁 auth/        # Authentication forms
│   │   ├── 📁 comment/     # Comment components
│   │   ├── 📁 layout/      # Layout components
│   │   ├── 📁 like/        # Like/reaction components
│   │   ├── 📁 notifications/ # Notification components
│   │   ├── 📁 post/        # Post-related components
│   │   ├── 📁 tag/         # Tag components
│   │   └── 📁 user/        # User profile components
│   ├── 📁 contexts/        # React contexts
│   │   └── AuthContext.tsx
│   ├── 📁 hooks/           # Custom React hooks
│   ├── 📁 pages/           # Page-level components
│   ├── 📁 services/        # API & Socket services
│   ├── 📁 styles/          # Global styles
│   ├── 📁 types/           # TypeScript definitions
│   ├── 📁 utils/           # Utility functions
│   ├── App.tsx             # Main application
│   └── index.tsx           # Entry point
├── 📄 package.json         # Dependencies & scripts
└── 📄 tsconfig.json        # TypeScript configuration
```

## 🎛️ Available Scripts

<table>
<tr>
<td>

**Development**
```bash
npm start          # Start dev server
npm test           # Run tests
npm run lint       # Lint code
npm run format     # Format code
```

</td>
<td>

**Production**
```bash
npm run build      # Build for production
npm run preview    # Preview build
npm run analyze    # Analyze bundle
```

</td>
</tr>
</table>

## 🌍 Environment Configuration

Create a `.env.local` file in the root directory:

```env
# API Configuration
REACT_APP_API_URL=http://localhost:3001/api
REACT_APP_SOCKET_URL=http://localhost:3001

# Feature Flags
REACT_APP_ENABLE_DEVTOOLS=true
REACT_APP_ENABLE_NOTIFICATIONS=true

# Analytics (Optional)
REACT_APP_ANALYTICS_ID=your-analytics-id
```

## 🧪 Testing Strategy

<div align="center">

| **Test Type** | **Framework** | **Coverage** |
|:-------------:|:-------------:|:------------:|
| Unit Tests | Jest + RTL | Components |
| Integration | Cypress | User Flows |
| E2E | Playwright | Critical Paths |

</div>

```bash
# Run all tests
npm test

# Run tests with coverage
npm run test:coverage

# Run E2E tests
npm run test:e2e
```

## 📊 Performance Metrics

- **Lighthouse Score**: 95+ (Performance, Accessibility, Best Practices, SEO)
- **Bundle Size**: < 500KB (gzipped)
- **First Contentful Paint**: < 1.5s
- **Largest Contentful Paint**: < 2.5s
- **Cumulative Layout Shift**: < 0.1

## 🔧 Development Guidelines

### Code Style
```typescript
// Use functional components with hooks
const MyComponent: React.FC<Props> = ({ prop1, prop2 }) => {
  const [state, setState] = useState<Type>(initialValue);
  
  return <div>{/* JSX */}</div>;
};

// Implement proper TypeScript types
interface ComponentProps {
  title: string;
  optional?: boolean;
}
```

### State Management Patterns
- **Server State**: TanStack Query for API data
- **Global State**: React Context for authentication
- **Local State**: useState for component state
- **Form State**: Controlled components with validation

## 🚀 Deployment

### Build for Production
```bash
npm run build
```

### Deploy to Various Platforms

<details>
<summary><strong>Vercel Deployment</strong></summary>

```bash
npm install -g vercel
vercel --prod
```
</details>

<details>
<summary><strong>Netlify Deployment</strong></summary>

```bash
npm install -g netlify-cli
netlify deploy --prod --dir=build
```
</details>

<details>
<summary><strong>Docker Deployment</strong></summary>

```dockerfile
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

FROM nginx:alpine
COPY --from=builder /app/build /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```
</details>

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guidelines](CONTRIBUTING.md) for details.

<div align="center">

### Development Workflow

```mermaid
graph LR
    A[Fork] --> B[Clone]
    B --> C[Branch]
    C --> D[Code]
    D --> E[Test]
    E --> F[Commit]
    F --> G[Push]
    G --> H[PR]
```

</div>

## 📄 License

This project is licensed under the **MIT License** - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

<div align="center">

**Need help?**

[![Documentation](https://img.shields.io/badge/📚_Documentation-blue?style=for-the-badge)](./docs)
[![Issues](https://img.shields.io/badge/🐛_Report_Bug-red?style=for-the-badge)](../../issues)
[![Discussions](https://img.shields.io/badge/💬_Discussions-green?style=for-the-badge)](../../discussions)

</div>

---

## 📄 License

![MIT License](https://img.shields.io/badge/License-MIT-yellow.svg?style=for-the-badge)

This project is licensed under the MIT License - see the LICENSE file for details.

## 👤 Developer Contact

[![LinkedIn](https://img.shields.io/badge/LinkedIn-Abhrajyoti_Nath-0077B5?style=for-the-badge&logo=linkedin)](https://www.linkedin.com/in/abhrajyoti-nath)
[![GitHub](https://img.shields.io/badge/GitHub-abhrajyoti--01-181717?style=for-the-badge&logo=github)](https://github.com/abhrajyoti-01)

- **Name:** Abhrajyoti Nath
- **LinkedIn:** [https://www.linkedin.com/in/abhrajyoti-nath](https://www.linkedin.com/in/abhrajyoti-nath)
- **GitHub:** [https://github.com/abhrajyoti-01](https://github.com/abhrajyoti-01)
