import request from 'supertest';
import app from '../../src/app';
import { initializeDB, sequelize } from '../../src/database';
import { logger } from '../../src/utils/logger';

describe('Integration Tests - Server and Database', () => {
  let server: any;

  beforeAll(async () => {
    try {
      // Set test environment
      process.env.NODE_ENV = 'test';
      
      // Initialize database
      await initializeDB();
      
      logger.info('Integration test setup completed');
    } catch (error) {
      logger.error('Integration test setup failed:', error);
      throw error;
    }
  }, 30000);

  afterAll(async () => {
    try {
      // Close database connection
      await sequelize.close();
      logger.info('Integration test cleanup completed');
    } catch (error) {
      logger.error('Integration test cleanup failed:', error);
    }
  });

  describe('Health Check Endpoints', () => {
    test('GET /health should return server health status', async () => {
      const response = await request(app)
        .get('/health')
        .expect(200);

      expect(response.body).toMatchObject({
        status: 'healthy',
        timestamp: expect.any(String),
        version: expect.any(String),
      });
    });

    test('GET /api/health should return API health status', async () => {
      const response = await request(app)
        .get('/api/health')
        .expect(200);

      expect(response.body).toMatchObject({
        status: 'OK',
        message: 'Social Media API is running',
        version: '1.0.0',
        timestamp: expect.any(String),
        services: {
          auth: 'active',
          users: 'active',
          posts: 'active',
          comments: 'active',
          likes: 'active',
          tags: 'active',
        },
      });
    });
  });

  describe('Service Health Checks', () => {
    test('GET /api/auth/health should return auth service status', async () => {
      const response = await request(app)
        .get('/api/auth/health')
        .expect(200);

      expect(response.body).toMatchObject({
        status: 'OK',
        message: 'Auth service is running',
        timestamp: expect.any(String),
      });
    });

    test('GET /api/users/health should return user service status', async () => {
      const response = await request(app)
        .get('/api/users/health')
        .expect(200);

      expect(response.body).toMatchObject({
        status: 'OK',
        message: 'User service is running',
        timestamp: expect.any(String),
      });
    });

    test('GET /api/posts/health should return post service status', async () => {
      const response = await request(app)
        .get('/api/posts/health')
        .expect(200);

      expect(response.body).toMatchObject({
        status: 'OK',
        message: 'Post service is running',
        timestamp: expect.any(String),
      });
    });

    test('GET /api/comments/health should return comment service status', async () => {
      const response = await request(app)
        .get('/api/comments/health')
        .expect(200);

      expect(response.body).toMatchObject({
        status: 'OK',
        message: 'Comment service is running',
        timestamp: expect.any(String),
      });
    });

    test('GET /api/likes/health should return like service status', async () => {
      const response = await request(app)
        .get('/api/likes/health')
        .expect(200);

      expect(response.body).toMatchObject({
        status: 'OK',
        message: 'Like service is running',
        timestamp: expect.any(String),
      });
    });

    test('GET /api/tags/health should return tag service status', async () => {
      const response = await request(app)
        .get('/api/tags/health')
        .expect(200);

      expect(response.body).toMatchObject({
        status: 'OK',
        message: 'Tag service is running',
        timestamp: expect.any(String),
      });
    });
  });

  describe('API Error Handling', () => {
    test('GET /api/nonexistent should return 404', async () => {
      const response = await request(app)
        .get('/api/nonexistent')
        .expect(404);

      expect(response.body).toMatchObject({
        error: 'Not Found',
        message: expect.stringContaining('API endpoint GET /api/nonexistent not found'),
        code: 'ENDPOINT_NOT_FOUND',
        timestamp: expect.any(String),
      });
    });

    test('GET /nonexistent should return 404', async () => {
      const response = await request(app)
        .get('/nonexistent')
        .expect(404);

      expect(response.body).toMatchObject({
        error: 'Not Found',
        message: expect.stringContaining('Route GET /nonexistent not found'),
        code: 'NOT_FOUND',
        timestamp: expect.any(String),
      });
    });
  });

  describe('CORS and Security Headers', () => {
    test('Should include CORS headers in response', async () => {
      const response = await request(app)
        .get('/health')
        .expect(200);

      // Check for security headers (helmet)
      expect(response.headers['x-content-type-options']).toBe('nosniff');
      expect(response.headers['x-frame-options']).toBe('DENY');
    });
  });
});