import { Router } from 'express';
import { PostController } from '../controllers/postController';
import { authenticateToken, optionalAuth } from '../middleware/auth';
import { logger } from '../utils/logger';

const router = Router();

// Health check endpoint
router.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    message: 'Post service is running',
    timestamp: new Date().toISOString(),
  });
});

// Public routes (some may work with optional auth)
router.get('/', optionalAuth, async (req, res, next) => {
  try {
    await PostController.getPosts(req, res, next);
  } catch (error) {
    logger.error('Post route error - get posts', { error });
    next(error);
  }
});

router.get('/:postId', optionalAuth, async (req, res, next) => {
  try {
    await PostController.getPost(req, res, next);
  } catch (error) {
    logger.error('Post route error - get post', { error });
    next(error);
  }
});

router.get('/user/:userId', optionalAuth, async (req, res, next) => {
  try {
    await PostController.getUserPosts(req, res, next);
  } catch (error) {
    logger.error('Post route error - get user posts', { error });
    next(error);
  }
});

router.get('/trending/posts', optionalAuth, async (req, res, next) => {
  try {
    await PostController.getTrendingPosts(req, res, next);
  } catch (error) {
    logger.error('Post route error - get trending posts', { error });
    next(error);
  }
});

// Protected routes (authentication required)
router.post('/', authenticateToken, async (req, res, next) => {
  try {
    await PostController.createPost(req, res, next);
  } catch (error) {
    logger.error('Post route error - create post', { error });
    next(error);
  }
});

router.put('/:postId', authenticateToken, async (req, res, next) => {
  try {
    await PostController.updatePost(req, res, next);
  } catch (error) {
    logger.error('Post route error - update post', { error });
    next(error);
  }
});

router.delete('/:postId', authenticateToken, async (req, res, next) => {
  try {
    await PostController.deletePost(req, res, next);
  } catch (error) {
    logger.error('Post route error - delete post', { error });
    next(error);
  }
});

router.get('/feed/timeline', authenticateToken, async (req, res, next) => {
  try {
    await PostController.getUserFeed(req, res, next);
  } catch (error) {
    logger.error('Post route error - get feed', { error });
    next(error);
  }
});

router.get('/search/posts', optionalAuth, async (req, res, next) => {
  try {
    await PostController.searchPosts(req, res, next);
  } catch (error) {
    logger.error('Post route error - search posts', { error });
    next(error);
  }
});

router.get('/stats/:postId', optionalAuth, async (req, res, next) => {
  try {
    await PostController.getPostStats(req, res, next);
  } catch (error) {
    logger.error('Post route error - get post stats', { error });
    next(error);
  }
});

export default router;