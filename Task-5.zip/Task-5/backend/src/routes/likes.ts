import { Router } from 'express';
import { LikeController } from '../controllers/likeController';
import { authenticateToken, optionalAuth } from '../middleware/auth';
import { logger } from '../utils/logger';

const router = Router();

// Health check endpoint
router.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    message: 'Like service is running',
    timestamp: new Date().toISOString(),
  });
});

// Public routes (some may work with optional auth)
router.get('/post/:postId', optionalAuth, async (req, res, next) => {
  try {
    await LikeController.getPostLikes(req, res, next);
  } catch (error) {
    logger.error('Like route error - get post likes', { error });
    next(error);
  }
});

router.get('/comment/:commentId', optionalAuth, async (req, res, next) => {
  try {
    await LikeController.getCommentLikes(req, res, next);
  } catch (error) {
    logger.error('Like route error - get comment likes', { error });
    next(error);
  }
});

router.get('/user/:userId', optionalAuth, async (req, res, next) => {
  try {
    await LikeController.getUserLikes(req, res, next);
  } catch (error) {
    logger.error('Like route error - get user likes', { error });
    next(error);
  }
});

router.get('/trending/posts', optionalAuth, async (req, res, next) => {
  try {
    await LikeController.getMostLikedPosts(req, res, next);
  } catch (error) {
    logger.error('Like route error - get most liked posts', { error });
    next(error);
  }
});

// Protected routes (authentication required)
router.post('/post/:postId', authenticateToken, async (req, res, next) => {
  try {
    await LikeController.togglePostLike(req, res, next);
  } catch (error) {
    logger.error('Like route error - toggle post like', { error });
    next(error);
  }
});

router.post('/comment/:commentId', authenticateToken, async (req, res, next) => {
  try {
    await LikeController.toggleCommentLike(req, res, next);
  } catch (error) {
    logger.error('Like route error - toggle comment like', { error });
    next(error);
  }
});

router.delete('/post/:postId', authenticateToken, async (req, res, next) => {
  try {
    await LikeController.unlikePost(req, res, next);
  } catch (error) {
    logger.error('Like route error - unlike post', { error });
    next(error);
  }
});

router.delete('/comment/:commentId', authenticateToken, async (req, res, next) => {
  try {
    await LikeController.unlikeComment(req, res, next);
  } catch (error) {
    logger.error('Like route error - unlike comment', { error });
    next(error);
  }
});

router.get('/status/post/:postId', authenticateToken, async (req, res, next) => {
  try {
    await LikeController.getPostLikeStatus(req, res, next);
  } catch (error) {
    logger.error('Like route error - get post like status', { error });
    next(error);
  }
});

router.get('/status/comment/:commentId', authenticateToken, async (req, res, next) => {
  try {
    await LikeController.getCommentLikeStatus(req, res, next);
  } catch (error) {
    logger.error('Like route error - get comment like status', { error });
    next(error);
  }
});

router.get('/stats/user/:userId', optionalAuth, async (req, res, next) => {
  try {
    await LikeController.getUserLikeStats(req, res, next);
  } catch (error) {
    logger.error('Like route error - get user like stats', { error });
    next(error);
  }
});

router.post('/status/multiple', authenticateToken, async (req, res, next) => {
  try {
    await LikeController.checkMultipleLikeStatus(req, res, next);
  } catch (error) {
    logger.error('Like route error - check multiple like status', { error });
    next(error);
  }
});

export default router;