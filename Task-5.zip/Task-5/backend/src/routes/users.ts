import { Router } from 'express';
import { UserController } from '../controllers/userController';
import { authenticateToken, optionalAuth } from '../middleware/auth';
import { logger } from '../utils/logger';

const router = Router();

// Health check endpoint
router.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    message: 'User service is running',
    timestamp: new Date().toISOString(),
  });
});

// Public routes (some may work with optional auth)
router.get('/profile/:userId', optionalAuth, async (req, res, next) => {
  try {
    await UserController.getUserProfile(req, res, next);
  } catch (error) {
    logger.error('User route error - get profile', { error });
    next(error);
  }
});

router.get('/search', optionalAuth, async (req, res, next) => {
  try {
    await UserController.searchUsers(req, res, next);
  } catch (error) {
    logger.error('User route error - search users', { error });
    next(error);
  }
});

router.get('/:userId/stats', optionalAuth, async (req, res, next) => {
  try {
    await UserController.getUserStats(req, res, next);
  } catch (error) {
    logger.error('User route error - get user stats', { error });
    next(error);
  }
});

router.get('/:userId/followers', optionalAuth, async (req, res, next) => {
  try {
    await UserController.getFollowers(req, res, next);
  } catch (error) {
    logger.error('User route error - get followers', { error });
    next(error);
  }
});

router.get('/:userId/following', optionalAuth, async (req, res, next) => {
  try {
    await UserController.getFollowing(req, res, next);
  } catch (error) {
    logger.error('User route error - get following', { error });
    next(error);
  }
});

router.get('/suggestions', authenticateToken, async (req, res, next) => {
  try {
    await UserController.getUserSuggestions(req, res, next);
  } catch (error) {
    logger.error('User route error - get user suggestions', { error });
    next(error);
  }
});

// Protected routes (authentication required)
router.put('/profile', authenticateToken, async (req, res, next) => {
  try {
    await UserController.updateProfile(req, res, next);
  } catch (error) {
    logger.error('User route error - update profile', { error });
    next(error);
  }
});

router.post('/:userId/follow', authenticateToken, async (req, res, next) => {
  try {
    await UserController.followUser(req, res, next);
  } catch (error) {
    logger.error('User route error - follow user', { error });
    next(error);
  }
});

router.delete('/:userId/follow', authenticateToken, async (req, res, next) => {
  try {
    await UserController.unfollowUser(req, res, next);
  } catch (error) {
    logger.error('User route error - unfollow user', { error });
    next(error);
  }
});

router.delete('/account', authenticateToken, async (req, res, next) => {
  try {
    await UserController.deleteAccount(req, res, next);
  } catch (error) {
    logger.error('User route error - delete account', { error });
    next(error);
  }
});

export default router;