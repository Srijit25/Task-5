import { Router } from 'express';
import authRoutes from './auth';
import userRoutes from './users';
import postRoutes from './posts';
import commentRoutes from './comments';
import likeRoutes from './likes';
import tagRoutes from './tags';

const router = Router();

// API Health Check
router.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    message: 'Social Media API is running',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    services: {
      auth: 'active',
      users: 'active',
      posts: 'active',
      comments: 'active',
      likes: 'active',
      tags: 'active',
    },
  });
});

// Mount routes
router.use('/auth', authRoutes);
router.use('/users', userRoutes);
router.use('/posts', postRoutes);
router.use('/comments', commentRoutes);
router.use('/likes', likeRoutes);
router.use('/tags', tagRoutes);

// 404 handler for API routes
router.use('*', (req, res) => {
  res.status(404).json({
    error: 'Not Found',
    message: `API endpoint ${req.method} ${req.originalUrl} not found`,
    code: 'ENDPOINT_NOT_FOUND',
    timestamp: new Date().toISOString(),
  });
});

export default router;