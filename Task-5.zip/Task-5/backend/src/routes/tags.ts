import { Router } from 'express';
import { TagController } from '../controllers/tagController';
import { authenticateToken, optionalAuth } from '../middleware/auth';
import { logger } from '../utils/logger';

const router = Router();

// Health check endpoint
router.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    message: 'Tag service is running',
    timestamp: new Date().toISOString(),
  });
});

// Public routes
router.get('/', optionalAuth, async (req, res, next) => {
  try {
    await TagController.getAllTags(req, res, next);
  } catch (error) {
    logger.error('Tag route error - get all tags', { error });
    next(error);
  }
});

router.get('/:tagId', optionalAuth, async (req, res, next) => {
  try {
    await TagController.getTagById(req, res, next);
  } catch (error) {
    logger.error('Tag route error - get tag', { error });
    next(error);
  }
});

router.get('/search/tags', optionalAuth, async (req, res, next) => {
  try {
    await TagController.searchTags(req, res, next);
  } catch (error) {
    logger.error('Tag route error - search tags', { error });
    next(error);
  }
});

router.get('/trending/tags', optionalAuth, async (req, res, next) => {
  try {
    await TagController.getTrendingTags(req, res, next);
  } catch (error) {
    logger.error('Tag route error - get trending tags', { error });
    next(error);
  }
});

router.get('/:tagId/posts', optionalAuth, async (req, res, next) => {
  try {
    await TagController.getPostsByTag(req, res, next);
  } catch (error) {
    logger.error('Tag route error - get tag posts', { error });
    next(error);
  }
});

router.get('/related/:tagId', optionalAuth, async (req, res, next) => {
  try {
    await TagController.getRelatedTags(req, res, next);
  } catch (error) {
    logger.error('Tag route error - get related tags', { error });
    next(error);
  }
});

router.get('/analytics/stats', optionalAuth, async (req, res, next) => {
  try {
    await TagController.getTagAnalytics(req, res, next);
  } catch (error) {
    logger.error('Tag route error - get tag analytics', { error });
    next(error);
  }
});

router.get('/popular/recent', optionalAuth, async (req, res, next) => {
  try {
    await TagController.getPopularTags(req, res, next);
  } catch (error) {
    logger.error('Tag route error - get popular tags', { error });
    next(error);
  }
});

// Protected routes (authentication required)
router.post('/', authenticateToken, async (req, res, next) => {
  try {
    await TagController.createTag(req, res, next);
  } catch (error) {
    logger.error('Tag route error - create tag', { error });
    next(error);
  }
});

router.put('/:tagId', authenticateToken, async (req, res, next) => {
  try {
    await TagController.updateTag(req, res, next);
  } catch (error) {
    logger.error('Tag route error - update tag', { error });
    next(error);
  }
});

router.delete('/:tagId', authenticateToken, async (req, res, next) => {
  try {
    await TagController.deactivateTag(req, res, next);
  } catch (error) {
    logger.error('Tag route error - deactivate tag', { error });
    next(error);
  }
});

router.post('/:tagId/create-batch', authenticateToken, async (req, res, next) => {
  try {
    await TagController.findOrCreateTags(req, res, next);
  } catch (error) {
    logger.error('Tag route error - find or create tags', { error });
    next(error);
  }
});

router.post('/:tagId/reactivate', authenticateToken, async (req, res, next) => {
  try {
    await TagController.reactivateTag(req, res, next);
  } catch (error) {
    logger.error('Tag route error - reactivate tag', { error });
    next(error);
  }
});

router.get('/:tagId/stats', optionalAuth, async (req, res, next) => {
  try {
    await TagController.getTagStats(req, res, next);
  } catch (error) {
    logger.error('Tag route error - get tag stats', { error });
    next(error);
  }
});

export default router;