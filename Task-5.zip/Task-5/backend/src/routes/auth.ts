import { Router } from 'express';
import { AuthController } from '../controllers/authController';
import { authenticateToken, optionalAuth, verifyRefreshToken } from '../middleware/auth';
import { logger } from '../utils/logger';

const router = Router();

// Health check endpoint (no auth required)
router.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    message: 'Auth service is running',
    timestamp: new Date().toISOString(),
  });
});

// Public routes (no authentication required)
router.post('/register', async (req, res, next) => {
  try {
    await AuthController.register(req, res, next);
  } catch (error) {
    logger.error('Auth route error - register', { error });
    next(error);
  }
});

router.post('/login', async (req, res, next) => {
  try {
    await AuthController.login(req, res, next);
  } catch (error) {
    logger.error('Auth route error - login', { error });
    next(error);
  }
});

router.post('/request-password-reset', async (req, res, next) => {
  try {
    // This would typically send a password reset email
    // For now, we'll just return a success message
    res.json({
      data: null,
      message: 'Password reset email sent successfully',
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    logger.error('Auth route error - request password reset', { error });
    next(error);
  }
});

router.post('/reset-password', async (req, res, next) => {
  try {
    await AuthController.resetPassword(req, res, next);
  } catch (error) {
    logger.error('Auth route error - reset password', { error });
    next(error);
  }
});

// Token refresh (uses special refresh token middleware)
router.post('/refresh', verifyRefreshToken, async (req, res, next) => {
  try {
    await AuthController.refreshToken(req, res, next);
  } catch (error) {
    logger.error('Auth route error - refresh token', { error });
    next(error);
  }
});

// Protected routes (authentication required)
router.post('/logout', authenticateToken, async (req, res, next) => {
  try {
    await AuthController.logout(req, res, next);
  } catch (error) {
    logger.error('Auth route error - logout', { error });
    next(error);
  }
});

router.post('/change-password', authenticateToken, async (req, res, next) => {
  try {
    await AuthController.changePassword(req, res, next);
  } catch (error) {
    logger.error('Auth route error - change password', { error });
    next(error);
  }
});

router.get('/me', authenticateToken, async (req, res, next) => {
  try {
    await AuthController.getCurrentUser(req, res, next);
  } catch (error) {
    logger.error('Auth route error - get current user', { error });
    next(error);
  }
});

export default router;