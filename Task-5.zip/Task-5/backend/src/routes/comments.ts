import { Router } from 'express';
import { CommentController } from '../controllers/commentController';
import { authenticateToken, optionalAuth } from '../middleware/auth';
import { logger } from '../utils/logger';

const router = Router();

// Health check endpoint
router.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    message: 'Comment service is running',
    timestamp: new Date().toISOString(),
  });
});

// Public routes (some may work with optional auth)
router.get('/post/:postId', optionalAuth, async (req, res, next) => {
  try {
    await CommentController.getPostComments(req, res, next);
  } catch (error) {
    logger.error('Comment route error - get post comments', { error });
    next(error);
  }
});

router.get('/:commentId', optionalAuth, async (req, res, next) => {
  try {
    await CommentController.getComment(req, res, next);
  } catch (error) {
    logger.error('Comment route error - get comment', { error });
    next(error);
  }
});

router.get('/:commentId/replies', optionalAuth, async (req, res, next) => {
  try {
    await CommentController.getCommentReplies(req, res, next);
  } catch (error) {
    logger.error('Comment route error - get comment replies', { error });
    next(error);
  }
});

// Protected routes (authentication required)
router.post('/post/:postId', authenticateToken, async (req, res, next) => {
  try {
    await CommentController.createComment(req, res, next);
  } catch (error) {
    logger.error('Comment route error - create comment', { error });
    next(error);
  }
});

router.get('/:commentId/thread', optionalAuth, async (req, res, next) => {
  try {
    await CommentController.getCommentThread(req, res, next);
  } catch (error) {
    logger.error('Comment route error - get comment thread', { error });
    next(error);
  }
});

router.put('/:commentId', authenticateToken, async (req, res, next) => {
  try {
    await CommentController.updateComment(req, res, next);
  } catch (error) {
    logger.error('Comment route error - update comment', { error });
    next(error);
  }
});

router.delete('/:commentId', authenticateToken, async (req, res, next) => {
  try {
    await CommentController.deleteComment(req, res, next);
  } catch (error) {
    logger.error('Comment route error - delete comment', { error });
    next(error);
  }
});

router.post('/:commentId/like', authenticateToken, async (req, res, next) => {
  try {
    await CommentController.toggleCommentLike(req, res, next);
  } catch (error) {
    logger.error('Comment route error - toggle comment like', { error });
    next(error);
  }
});

router.get('/:commentId/likes', optionalAuth, async (req, res, next) => {
  try {
    await CommentController.getCommentLikes(req, res, next);
  } catch (error) {
    logger.error('Comment route error - get comment likes', { error });
    next(error);
  }
});

router.get('/user/:userId', optionalAuth, async (req, res, next) => {
  try {
    await CommentController.getUserComments(req, res, next);
  } catch (error) {
    logger.error('Comment route error - get user comments', { error });
    next(error);
  }
});

export default router;