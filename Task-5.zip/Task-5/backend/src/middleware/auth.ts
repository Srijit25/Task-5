import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { User } from '../models/User';
import { logger } from '../utils/logger';

// JWT secret from environment
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

/**
 * Authentication middleware to verify JWT tokens
 */
export const authenticateToken = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

    if (!token) {
      res.status(401).json({
        error: 'Access token required',
        message: 'No access token provided',
        code: 'MISSING_TOKEN',
        timestamp: new Date().toISOString(),
      });
      return;
    }

    // Verify the token
    const decoded = jwt.verify(token, JWT_SECRET) as {
      userId: string;
      email: string;
      username: string;
      iat: number;
      exp: number;
    };

    // Fetch user details from database
    const user = await User.findByPk(decoded.userId);
    if (!user || user.isDeleted) {
      res.status(401).json({
        error: 'Invalid token',
        message: 'User not found or account deactivated',
        code: 'INVALID_TOKEN',
        timestamp: new Date().toISOString(),
      });
      return;
    }

    // Add user info to request object
    req.user = {
      id: user.id,
      email: user.email,
      username: user.username,
      ...(user.firstName && { firstName: user.firstName }),
      ...(user.lastName && { lastName: user.lastName }),
      ...(user.profileImageUrl && { profileImageUrl: user.profileImageUrl }),
    };

    logger.debug('User authenticated successfully', {
      userId: user.id,
      username: user.username,
      path: req.path,
      method: req.method,
    });

    next();
  } catch (error) {
    logger.error('Authentication failed', {
      error: error instanceof Error ? error.message : 'Unknown error',
      path: req.path,
      method: req.method,
      timestamp: new Date().toISOString(),
    });

    if (error instanceof jwt.TokenExpiredError) {
      res.status(401).json({
        error: 'Token expired',
        message: 'Access token has expired',
        code: 'TOKEN_EXPIRED',
        timestamp: new Date().toISOString(),
      });
      return;
    }

    if (error instanceof jwt.JsonWebTokenError) {
      res.status(401).json({
        error: 'Invalid token',
        message: 'Access token is invalid',
        code: 'INVALID_TOKEN',
        timestamp: new Date().toISOString(),
      });
      return;
    }

    res.status(500).json({
      error: 'Authentication error',
      message: 'An error occurred during authentication',
      code: 'AUTH_ERROR',
      timestamp: new Date().toISOString(),
    });
  }
};

/**
 * Optional authentication middleware - doesn't fail if no token provided
 * Useful for endpoints that work both with and without authentication
 */
export const optionalAuth = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
      // No token provided, continue without authentication
      next();
      return;
    }

    // Try to authenticate if token is provided
    const decoded = jwt.verify(token, JWT_SECRET) as {
      userId: string;
      email: string;
      username: string;
      iat: number;
      exp: number;
    };

    const user = await User.findByPk(decoded.userId);
    if (user && !user.isDeleted) {
      req.user = {
        id: user.id,
        email: user.email,
        username: user.username,
        ...(user.firstName && { firstName: user.firstName }),
        ...(user.lastName && { lastName: user.lastName }),
        ...(user.profileImageUrl && { profileImageUrl: user.profileImageUrl }),
      };
    }

    next();
  } catch (error) {
    // If token is invalid, continue without authentication
    logger.debug('Optional authentication failed, continuing without auth', {
      error: error instanceof Error ? error.message : 'Unknown error',
      path: req.path,
    });
    next();
  }
};

/**
 * Middleware to verify refresh tokens
 */
export const verifyRefreshToken = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      res.status(401).json({
        error: 'Refresh token required',
        message: 'No refresh token provided',
        code: 'MISSING_REFRESH_TOKEN',
        timestamp: new Date().toISOString(),
      });
      return;
    }

    // Verify the refresh token
    const decoded = jwt.verify(refreshToken, JWT_SECRET) as {
      userId: string;
      type: string;
      iat: number;
      exp: number;
    };

    if (decoded.type !== 'refresh') {
      res.status(401).json({
        error: 'Invalid token type',
        message: 'Expected refresh token',
        code: 'INVALID_TOKEN_TYPE',
        timestamp: new Date().toISOString(),
      });
      return;
    }

    // Verify user exists
    const user = await User.findByPk(decoded.userId);
    if (!user || user.isDeleted) {
      res.status(401).json({
        error: 'Invalid refresh token',
        message: 'User not found or account deactivated',
        code: 'INVALID_REFRESH_TOKEN',
        timestamp: new Date().toISOString(),
      });
      return;
    }

    req.user = {
      id: user.id,
      email: user.email,
      username: user.username,
      ...(user.firstName && { firstName: user.firstName }),
      ...(user.lastName && { lastName: user.lastName }),
      ...(user.profileImageUrl && { profileImageUrl: user.profileImageUrl }),
    };

    next();
  } catch (error) {
    logger.error('Refresh token verification failed', {
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString(),
    });

    if (error instanceof jwt.TokenExpiredError) {
      res.status(401).json({
        error: 'Refresh token expired',
        message: 'Refresh token has expired',
        code: 'REFRESH_TOKEN_EXPIRED',
        timestamp: new Date().toISOString(),
      });
      return;
    }

    res.status(401).json({
      error: 'Invalid refresh token',
      message: 'Refresh token is invalid',
      code: 'INVALID_REFRESH_TOKEN',
      timestamp: new Date().toISOString(),
    });
  }
};

export default {
  authenticateToken,
  optionalAuth,
  verifyRefreshToken,
};