// Base interfaces for Supabase database types
export interface BaseEntity {
  id: string;
  created_at: string;
  updated_at?: string;
}

export interface UserEntity extends BaseEntity {
  auth_user_id: string;
  username: string;
  email: string;
  first_name?: string;
  last_name?: string;
  bio?: string;
  profile_picture_url?: string;
  is_verified: boolean;
  is_active: boolean;
  is_deleted: boolean;
}

export interface PostEntity extends BaseEntity {
  user_id: string;
  content?: string | null;
  media_urls?: string[] | null;
  location?: string | null;
  visibility: 'public' | 'private' | 'friends';
  allow_comments: boolean;
  allow_likes: boolean;
  likes_count: number;
  comments_count: number;
  views_count: number;
  shares_count: number;
  is_deleted: boolean;
}

export interface CommentEntity extends BaseEntity {
  post_id: string;
  user_id: string;
  parent_comment_id?: string | null;
  content: string;
  like_count: number;
  reply_count: number;
  is_deleted: boolean;
}

export interface LikeEntity {
  id: string;
  user_id: string;
  target_id: string;
  target_type: 'post' | 'comment';
  post_id?: string | null;
  comment_id?: string | null;
  created_at: string;
  updated_at: string;
}

export interface TagEntity {
  id: string;
  name: string;
  description?: string | null;
  color?: string | null;
  is_official: boolean;
  post_count: number;
  created_at: string;
  updated_at: string;
}

export interface PostTagEntity {
  post_id: string;
  tag_id: string;
  created_at: string;
}

export interface FollowEntity {
  id: string;
  follower_id: string;
  followed_id: string;
  created_at: string;
  updated_at: string;
}

export interface NotificationEntity extends BaseEntity {
  user_id: string;
  actor_id: string;
  type: 'like' | 'comment' | 'follow' | 'mention';
  post_id?: string;
  comment_id?: string;
  message?: string;
  is_read: boolean;
}

// DTO types for API interactions
export interface CreateUserData {
  auth_user_id: string;
  username: string;
  email: string;
  first_name?: string;
  last_name?: string;
  bio?: string;
  profile_picture_url?: string;
}

export interface UpdateUserData {
  username?: string;
  first_name?: string;
  last_name?: string;
  bio?: string;
  profile_picture_url?: string;
  is_verified?: boolean;
  is_active?: boolean;
}

export interface CreatePostData {
  user_id: string;
  content?: string | null;
  media_urls?: string[] | null;
  location?: string | null;
  visibility?: 'public' | 'private' | 'friends';
  allow_comments?: boolean;
  allow_likes?: boolean;
}

export interface UpdatePostData {
  content?: string | null;
  media_urls?: string[] | null;
  location?: string | null;
  visibility?: 'public' | 'private' | 'friends';
  allow_comments?: boolean;
  allow_likes?: boolean;
}

export interface CreateCommentData {
  post_id: string;
  user_id: string;
  parent_comment_id?: string | null;
  content: string;
}

export interface UpdateCommentData {
  content: string;
}

export interface CreateLikeData {
  user_id: string;
  target_id: string;
  target_type: 'post' | 'comment';
  post_id?: string | null;
  comment_id?: string | null;
}

export interface CreateTagData {
  name: string;
  description?: string | null;
  color?: string | null;
  is_official?: boolean;
}

export interface UpdateTagData {
  name?: string;
  description?: string | null;
  color?: string | null;
  is_official?: boolean;
}

export interface CreateFollowData {
  follower_id: string;
  followed_id: string;
}

export interface CreateNotificationData {
  user_id: string;
  actor_id: string;
  type: 'like' | 'comment' | 'follow' | 'mention';
  post_id?: string;
  comment_id?: string;
  message?: string;
}

// Query filter types
export interface PaginationOptions {
  page?: number;
  limit?: number;
  offset?: number;
}

export interface SortOptions {
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface PostFilters extends PaginationOptions, SortOptions {
  userId?: string;
  tagName?: string;
  includeUser?: boolean;
  includeTags?: boolean;
  visibility?: 'public' | 'private' | 'friends';
  content?: string;
  location?: string;
  includeDeleted?: boolean;
}

export interface LikeFilters extends PaginationOptions, SortOptions {
  userId?: string;
  postId?: string;
  commentId?: string;
  includeUser?: boolean;
}

export interface TagFilters extends PaginationOptions, SortOptions {
  name?: string;
  description?: string;
  minPostCount?: number;
}

export interface FollowFilters extends PaginationOptions, SortOptions {
  followerId?: string;
  followingId?: string;
  includeUser?: boolean;
}

export interface UserFilters extends PaginationOptions, SortOptions {
  username?: string;
  email?: string;
  isVerified?: boolean;
  isActive?: boolean;
  search?: string;
}

export interface CommentFilters extends PaginationOptions, SortOptions {
  postId?: string;
  userId?: string;
  parentId?: string;
  content?: string;
}

// Response types
export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

export interface PostWithUser extends PostEntity {
  user: Pick<UserEntity, 'id' | 'username' | 'first_name' | 'last_name' | 'profile_picture_url'>;
}

export interface PostWithUserAndTags extends PostWithUser {
  tags: TagEntity[];
}

export interface CommentWithUser extends CommentEntity {
  user: Pick<UserEntity, 'id' | 'username' | 'first_name' | 'last_name' | 'profile_picture_url'>;
}

export interface CommentWithReplies extends CommentWithUser {
  replies: CommentWithUser[];
}