// Type declarations for Express.js extensions

declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        email: string;
        username: string;
        firstName?: string;
        lastName?: string;
        profileImageUrl?: string;
      };
    }
  }
}

export {}; // Make this file a module