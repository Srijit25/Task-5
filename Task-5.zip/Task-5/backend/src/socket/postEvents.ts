import { Server } from 'socket.io';
import { AuthenticatedSocket } from './socketAuth';
import { emitToUser, emitToRoom } from './connectionHandler';
import { Post } from '../models/Post';
import { Like } from '../models/Like';
import { Comment } from '../models/Comment';
import { User } from '../models/User';

export const postEventHandler = (io: Server) => {
  return (socket: AuthenticatedSocket) => {
    const userId = socket.userId!;

    // Handle post liked
    socket.on('post_liked', async (data: { postId: string }) => {
      try {
        const { postId } = data;
        
        // Get the post with author info
        const post = await Post.findByPk(postId, {
          include: [{ model: User, as: 'author', attributes: ['id', 'username'] }]
        });

        if (!post) {
          socket.emit('error', { message: 'Post not found' });
          return;
        }

        // Get updated like count
        const likeCount = await Like.count({ where: { postId } });

        // Emit to all users in the post room
        const eventData = {
          postId,
          userId,
          username: socket.user?.username,
          likeCount,
          timestamp: new Date().toISOString()
        };

        // Emit to post room (users viewing the post)
        emitToRoom(io, `post:${postId}`, 'post_liked', eventData);

        // Notify post author if different from liker
        if (post.userId !== userId) {
          emitToUser(io, post.userId, 'new_notification', {
            type: 'like',
            message: `${socket.user?.username} liked your post`,
            postId,
            fromUserId: userId,
            timestamp: new Date().toISOString()
          });
        }

        console.log(`Post ${postId} liked by user ${userId}`);
      } catch (error) {
        console.error('Error handling post like:', error);
        socket.emit('error', { message: 'Failed to process like' });
      }
    });

    // Handle post unliked
    socket.on('post_unliked', async (data: { postId: string }) => {
      try {
        const { postId } = data;

        // Get updated like count
        const likeCount = await Like.count({ where: { postId } });

        // Emit to all users in the post room
        const eventData = {
          postId,
          userId,
          username: socket.user?.username,
          likeCount,
          timestamp: new Date().toISOString()
        };

        emitToRoom(io, `post:${postId}`, 'post_unliked', eventData);

        console.log(`Post ${postId} unliked by user ${userId}`);
      } catch (error) {
        console.error('Error handling post unlike:', error);
        socket.emit('error', { message: 'Failed to process unlike' });
      }
    });

    // Handle post commented
    socket.on('post_commented', async (data: { postId: string; commentId: string }) => {
      try {
        const { postId, commentId } = data;

        // Get the comment with user info
        const comment = await Comment.findByPk(commentId, {
          include: [{ model: User, as: 'user', attributes: ['id', 'username', 'profileImageUrl'] }]
        });

        if (!comment) {
          socket.emit('error', { message: 'Comment not found' });
          return;
        }

        // Get the post with author info
        const post = await Post.findByPk(postId, {
          include: [{ model: User, as: 'user', attributes: ['id', 'username'] }]
        });

        if (!post) {
          socket.emit('error', { message: 'Post not found' });
          return;
        }

        // Emit to all users in the post room
        const eventData = {
          postId,
          comment: {
            id: comment.id,
            content: comment.content,
            userId: comment.userId,
            user: comment.user,
            createdAt: comment.createdAt,
            updatedAt: comment.updatedAt
          },
          timestamp: new Date().toISOString()
        };

        emitToRoom(io, `post:${postId}`, 'post_commented', eventData);

        // Notify post author if different from commenter
        if (post.userId !== userId) {
          emitToUser(io, post.userId, 'new_notification', {
            type: 'comment',
            message: `${socket.user?.username} commented on your post`,
            postId,
            commentId,
            fromUserId: userId,
            timestamp: new Date().toISOString()
          });
        }

        console.log(`Post ${postId} commented by user ${userId}`);
      } catch (error) {
        console.error('Error handling post comment:', error);
        socket.emit('error', { message: 'Failed to process comment' });
      }
    });

    // Handle joining post room (for real-time updates)
    socket.on('join_post', (data: { postId: string }) => {
      const { postId } = data;
      socket.join(`post:${postId}`);
      console.log(`User ${userId} joined post room: ${postId}`);
    });

    // Handle leaving post room
    socket.on('leave_post', (data: { postId: string }) => {
      const { postId } = data;
      socket.leave(`post:${postId}`);
      console.log(`User ${userId} left post room: ${postId}`);
    });
  };
};