import { Server } from 'socket.io';
import { AuthenticatedSocket } from './socketAuth';

// Store user sessions
const userSessions = new Map<string, Set<string>>(); // userId -> Set of socketIds
const socketUsers = new Map<string, string>(); // socketId -> userId

export const connectionHandler = (io: Server) => {
  return (socket: AuthenticatedSocket) => {
    const userId = socket.userId!;
    const socketId = socket.id;

    console.log(`User connected: ${socket.user?.username} (${userId}) - Socket: ${socketId}`);

    // Store user session
    if (!userSessions.has(userId)) {
      userSessions.set(userId, new Set());
    }
    userSessions.get(userId)!.add(socketId);
    socketUsers.set(socketId, userId);

    // Join user's personal room
    socket.join(`user:${userId}`);

    // Notify others that user is online
    socket.broadcast.emit('user_status_changed', {
      userId,
      isOnline: true,
      timestamp: new Date().toISOString()
    });

    // Send current online users to the newly connected user
    const onlineUsers = Array.from(userSessions.keys());
    socket.emit('online_users', { users: onlineUsers });

    // Handle user going offline
    socket.on('disconnect', (reason) => {
      console.log(`User disconnected: ${socket.user?.username} (${userId}) - Reason: ${reason}`);

      // Remove from sessions
      const userSocketSet = userSessions.get(userId);
      if (userSocketSet) {
        userSocketSet.delete(socketId);
        if (userSocketSet.size === 0) {
          userSessions.delete(userId);
          
          // User is completely offline
          socket.broadcast.emit('user_status_changed', {
            userId,
            isOnline: false,
            timestamp: new Date().toISOString()
          });
        }
      }
      socketUsers.delete(socketId);
    });

    // Handle manual user offline
    socket.on('user_offline', () => {
      socket.broadcast.emit('user_status_changed', {
        userId,
        isOnline: false,
        timestamp: new Date().toISOString()
      });
    });

    // Handle user online
    socket.on('user_online', () => {
      socket.broadcast.emit('user_status_changed', {
        userId,
        isOnline: true,
        timestamp: new Date().toISOString()
      });
    });
  };
};

// Utility functions
export const getUserSockets = (userId: string): Set<string> | undefined => {
  return userSessions.get(userId);
};

export const isUserOnline = (userId: string): boolean => {
  return userSessions.has(userId);
};

export const getOnlineUsers = (): string[] => {
  return Array.from(userSessions.keys());
};

export const emitToUser = (io: Server, userId: string, event: string, data: any) => {
  const socketIds = getUserSockets(userId);
  if (socketIds) {
    socketIds.forEach(socketId => {
      io.to(socketId).emit(event, data);
    });
  }
};

export const emitToRoom = (io: Server, room: string, event: string, data: any) => {
  io.to(room).emit(event, data);
};