import { Server } from 'socket.io';
import { AuthenticatedSocket } from './socketAuth';
import { emitToUser } from './connectionHandler';

export const notificationEventHandler = (io: Server) => {
  return (socket: AuthenticatedSocket) => {
    const userId = socket.userId!;

    // Handle notification read
    socket.on('notification_read', async (data: { notificationId: string }) => {
      try {
        const { notificationId } = data;
        
        // Here you would typically update the notification in the database
        // For now, we'll just emit the event back to confirm
        socket.emit('notification_read_confirmed', {
          notificationId,
          timestamp: new Date().toISOString()
        });

        console.log(`Notification ${notificationId} marked as read by user ${userId}`);
      } catch (error) {
        console.error('Error marking notification as read:', error);
        socket.emit('error', { message: 'Failed to mark notification as read' });
      }
    });

    // Handle notification dismissed
    socket.on('notification_dismissed', async (data: { notificationId: string }) => {
      try {
        const { notificationId } = data;
        
        socket.emit('notification_dismissed_confirmed', {
          notificationId,
          timestamp: new Date().toISOString()
        });

        console.log(`Notification ${notificationId} dismissed by user ${userId}`);
      } catch (error) {
        console.error('Error dismissing notification:', error);
        socket.emit('error', { message: 'Failed to dismiss notification' });
      }
    });

    // Handle bulk notification read
    socket.on('notifications_read_all', async () => {
      try {
        // Here you would typically update all unread notifications for the user
        socket.emit('notifications_read_all_confirmed', {
          timestamp: new Date().toISOString()
        });

        console.log(`All notifications marked as read for user ${userId}`);
      } catch (error) {
        console.error('Error marking all notifications as read:', error);
        socket.emit('error', { message: 'Failed to mark all notifications as read' });
      }
    });
  };
};

// Utility function to send notification to user
export const sendNotification = (io: Server, userId: string, notification: {
  type: 'like' | 'comment' | 'follow' | 'mention' | 'system';
  title: string;
  message: string;
  data?: any;
}) => {
  const notificationData = {
    id: `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    ...notification,
    timestamp: new Date().toISOString(),
    isRead: false
  };

  emitToUser(io, userId, 'new_notification', notificationData);
  
  console.log(`Notification sent to user ${userId}: ${notification.message}`);
  return notificationData;
};