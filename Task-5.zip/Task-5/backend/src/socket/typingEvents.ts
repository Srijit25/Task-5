import { Server } from 'socket.io';
import { AuthenticatedSocket } from './socketAuth';

export const typingEventHandler = (io: Server) => {
  return (socket: AuthenticatedSocket) => {
    const userId = socket.userId!;

    // Handle typing start
    socket.on('typing_start', (data: { roomId: string; postId?: string }) => {
      try {
        const { roomId, postId } = data;
        
        // Broadcast to others in the room that user is typing
        socket.to(roomId).emit('typing_start', {
          userId,
          username: socket.user?.username,
          roomId,
          postId,
          timestamp: new Date().toISOString()
        });

        console.log(`User ${userId} started typing in room ${roomId}`);
      } catch (error) {
        console.error('Error handling typing start:', error);
      }
    });

    // Handle typing stop
    socket.on('typing_stop', (data: { roomId: string; postId?: string }) => {
      try {
        const { roomId, postId } = data;
        
        // Broadcast to others in the room that user stopped typing
        socket.to(roomId).emit('typing_stop', {
          userId,
          username: socket.user?.username,
          roomId,
          postId,
          timestamp: new Date().toISOString()
        });

        console.log(`User ${userId} stopped typing in room ${roomId}`);
      } catch (error) {
        console.error('Error handling typing stop:', error);
      }
    });

    // Handle joining room for typing events
    socket.on('join_room', (data: { roomId: string }) => {
      try {
        const { roomId } = data;
        socket.join(roomId);
        
        console.log(`User ${userId} joined room ${roomId}`);
      } catch (error) {
        console.error('Error joining room:', error);
      }
    });

    // Handle leaving room
    socket.on('leave_room', (data: { roomId: string }) => {
      try {
        const { roomId } = data;
        socket.leave(roomId);
        
        console.log(`User ${userId} left room ${roomId}`);
      } catch (error) {
        console.error('Error leaving room:', error);
      }
    });
  };
};