import { Server } from 'socket.io';
import { createServer } from 'http';
import { Express } from 'express';
import { authenticateSocket } from './socketAuth';
import { connectionHandler } from './connectionHandler';
import { postEventHandler } from './postEvents';
import { notificationEventHandler } from './notificationEvents';
import { typingEventHandler } from './typingEvents';

export const setupSocket = (app: Express): Server => {
  // Create HTTP server
  const server = createServer(app);

  // Create Socket.IO server
  const io = new Server(server, {
    cors: {
      origin: process.env.FRONTEND_URL || "http://localhost:3000",
      methods: ["GET", "POST"],
      allowedHeaders: ["authorization"],
      credentials: true
    },
    allowEIO3: true
  });

  // Apply authentication middleware
  io.use(authenticateSocket);

  // Handle connections
  io.on('connection', (socket) => {
    // Connection handler
    connectionHandler(io)(socket);

    // Event handlers
    postEventHandler(io)(socket);
    notificationEventHandler(io)(socket);
    typingEventHandler(io)(socket);
  });

  console.log('Socket.IO server configured');

  return io;
};

export { Server } from 'socket.io';