import { Like } from '../models/Like';
import { User } from '../models/User';
import { Post } from '../models/Post';
import { Comment } from '../models/Comment';
import { logger } from '../utils/logger';

export interface LikeOptions {
  limit?: number;
  offset?: number;
  includeUser?: boolean;
  type?: 'post' | 'comment' | 'all';
}

export class LikeService {
  /**
   * Like a post
   */
  public static async likePost(postId: string, userId: string): Promise<{ liked: boolean; like?: Like }> {
    try {
      logger.info('LikeService: Liking post', { postId, userId });

      // Verify post exists and is active
      const post = await Post.findActiveById(postId);
      if (!post) {
        throw new Error('Post not found');
      }

      // Verify user exists and is active
      const user = await User.findByPk(userId);
      if (!user || user.isDeleted) {
        throw new Error('User not found or deactivated');
      }

      // Check if already liked
      const existingLike = await Like.findByUserAndPost(userId, postId);
      if (existingLike) {
        throw new Error('Post already liked');
      }

      // Create like
      const like = await Like.create({ userId, postId });

      // Update post's likes count
      await post.incrementLikesCount();

      logger.info('LikeService: Post liked successfully', { postId, userId, likeId: like.id });
      return { liked: true, like };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('LikeService: Like post failed', { error: errorMessage, postId, userId });
      throw error;
    }
  }

  /**
   * Unlike a post
   */
  public static async unlikePost(postId: string, userId: string): Promise<{ liked: boolean }> {
    try {
      logger.info('LikeService: Unliking post', { postId, userId });

      // Find existing like
      const existingLike = await Like.findByUserAndPost(userId, postId);
      if (!existingLike) {
        throw new Error('Post not liked');
      }

      // Remove like
      await existingLike.destroy();

      // Update post's likes count
      const post = await Post.findByPk(postId);
      if (post) {
        await post.decrementLikesCount();
      }

      logger.info('LikeService: Post unliked successfully', { postId, userId });
      return { liked: false };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('LikeService: Unlike post failed', { error: errorMessage, postId, userId });
      throw error;
    }
  }

  /**
   * Toggle post like (like if not liked, unlike if liked)
   */
  public static async togglePostLike(postId: string, userId: string): Promise<{ liked: boolean; like?: Like }> {
    try {
      logger.info('LikeService: Toggling post like', { postId, userId });

      const result = await Like.togglePostLike(userId, postId);

      // Update post's likes count
      const post = await Post.findByPk(postId);
      if (post) {
        if (result.liked) {
          await post.incrementLikesCount();
        } else {
          await post.decrementLikesCount();
        }
      }

      logger.info('LikeService: Post like toggled successfully', { postId, userId, liked: result.liked });
      return result;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('LikeService: Toggle post like failed', { error: errorMessage, postId, userId });
      throw error;
    }
  }

  /**
   * Like a comment
   */
  public static async likeComment(commentId: string, userId: string): Promise<{ liked: boolean; like?: Like }> {
    try {
      logger.info('LikeService: Liking comment', { commentId, userId });

      // Verify comment exists and is active
      const comment = await Comment.findActiveById(commentId);
      if (!comment) {
        throw new Error('Comment not found');
      }

      // Verify user exists and is active
      const user = await User.findByPk(userId);
      if (!user || user.isDeleted) {
        throw new Error('User not found or deactivated');
      }

      // Check if already liked
      const existingLike = await Like.findByUserAndComment(userId, commentId);
      if (existingLike) {
        throw new Error('Comment already liked');
      }

      // Create like
      const like = await Like.create({ userId, commentId });

      // Update comment's likes count
      await comment.incrementLikesCount();

      logger.info('LikeService: Comment liked successfully', { commentId, userId, likeId: like.id });
      return { liked: true, like };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('LikeService: Like comment failed', { error: errorMessage, commentId, userId });
      throw error;
    }
  }

  /**
   * Unlike a comment
   */
  public static async unlikeComment(commentId: string, userId: string): Promise<{ liked: boolean }> {
    try {
      logger.info('LikeService: Unliking comment', { commentId, userId });

      // Find existing like
      const existingLike = await Like.findByUserAndComment(userId, commentId);
      if (!existingLike) {
        throw new Error('Comment not liked');
      }

      // Remove like
      await existingLike.destroy();

      // Update comment's likes count
      const comment = await Comment.findByPk(commentId);
      if (comment) {
        await comment.decrementLikesCount();
      }

      logger.info('LikeService: Comment unliked successfully', { commentId, userId });
      return { liked: false };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('LikeService: Unlike comment failed', { error: errorMessage, commentId, userId });
      throw error;
    }
  }

  /**
   * Toggle comment like
   */
  public static async toggleCommentLike(commentId: string, userId: string): Promise<{ liked: boolean; like?: Like }> {
    try {
      logger.info('LikeService: Toggling comment like', { commentId, userId });

      const result = await Like.toggleCommentLike(userId, commentId);

      // Update comment's likes count
      const comment = await Comment.findByPk(commentId);
      if (comment) {
        if (result.liked) {
          await comment.incrementLikesCount();
        } else {
          await comment.decrementLikesCount();
        }
      }

      logger.info('LikeService: Comment like toggled successfully', { commentId, userId, liked: result.liked });
      return result;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('LikeService: Toggle comment like failed', { error: errorMessage, commentId, userId });
      throw error;
    }
  }

  /**
   * Check if user has liked a post
   */
  public static async hasUserLikedPost(userId: string, postId: string): Promise<boolean> {
    try {
      logger.info('LikeService: Checking if user liked post', { userId, postId });

      const hasLiked = await Like.hasUserLikedPost(userId, postId);

      logger.info('LikeService: User like status checked', { userId, postId, hasLiked });
      return hasLiked;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('LikeService: Check user liked post failed', { error: errorMessage, userId, postId });
      throw error;
    }
  }

  /**
   * Check if user has liked a comment
   */
  public static async hasUserLikedComment(userId: string, commentId: string): Promise<boolean> {
    try {
      logger.info('LikeService: Checking if user liked comment', { userId, commentId });

      const hasLiked = await Like.hasUserLikedComment(userId, commentId);

      logger.info('LikeService: User comment like status checked', { userId, commentId, hasLiked });
      return hasLiked;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('LikeService: Check user liked comment failed', { error: errorMessage, userId, commentId });
      throw error;
    }
  }

  /**
   * Get post likes
   */
  public static async getPostLikes(
    postId: string,
    options: LikeOptions = {}
  ): Promise<{ likes: Like[]; total: number }> {
    try {
      const { limit = 20, offset = 0, includeUser = true } = options;
      logger.info('LikeService: Getting post likes', { postId, limit, offset });

      const { likes, total } = await Like.getPostLikes(postId, {
        limit,
        offset,
        includeUser,
      });

      logger.info('LikeService: Post likes retrieved successfully', { postId, count: likes.length, total });
      return { likes, total };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('LikeService: Get post likes failed', { error: errorMessage, postId });
      throw error;
    }
  }

  /**
   * Get comment likes
   */
  public static async getCommentLikes(
    commentId: string,
    options: LikeOptions = {}
  ): Promise<{ likes: Like[]; total: number }> {
    try {
      const { limit = 20, offset = 0, includeUser = true } = options;
      logger.info('LikeService: Getting comment likes', { commentId, limit, offset });

      const { likes, total } = await Like.getCommentLikes(commentId, {
        limit,
        offset,
        includeUser,
      });

      logger.info('LikeService: Comment likes retrieved successfully', { commentId, count: likes.length, total });
      return { likes, total };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('LikeService: Get comment likes failed', { error: errorMessage, commentId });
      throw error;
    }
  }

  /**
   * Get user's likes
   */
  public static async getUserLikes(
    userId: string,
    options: LikeOptions = {}
  ): Promise<{ likes: Like[]; total: number }> {
    try {
      const { limit = 20, offset = 0, type = 'all' } = options;
      logger.info('LikeService: Getting user likes', { userId, limit, offset, type });

      const { likes, total } = await Like.getUserLikes(userId, {
        limit,
        offset,
        type,
      });

      logger.info('LikeService: User likes retrieved successfully', { userId, count: likes.length, total, type });
      return { likes, total };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('LikeService: Get user likes failed', { error: errorMessage, userId });
      throw error;
    }
  }

  /**
   * Get most liked posts
   */
  public static async getMostLikedPosts(options: {
    limit?: number;
    timeframe?: 'day' | 'week' | 'month' | 'all';
  } = {}): Promise<any[]> {
    try {
      const { limit = 10, timeframe = 'week' } = options;
      logger.info('LikeService: Getting most liked posts', { limit, timeframe });

      const mostLikedPosts = await Like.getMostLikedPosts({ limit, timeframe });

      logger.info('LikeService: Most liked posts retrieved successfully', { count: mostLikedPosts.length, timeframe });
      return mostLikedPosts;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('LikeService: Get most liked posts failed', { error: errorMessage });
      throw error;
    }
  }

  /**
   * Get like statistics for a user
   */
  public static async getUserLikeStats(userId: string): Promise<{
    totalLikesGiven: number;
    totalLikesReceived: number;
    postLikesGiven: number;
    commentLikesGiven: number;
    postLikesReceived: number;
    commentLikesReceived: number;
  }> {
    try {
      logger.info('LikeService: Getting user like statistics', { userId });

      // Get likes given by user
      const { total: totalLikesGiven } = await Like.getUserLikes(userId, { limit: 1 });
      const { total: postLikesGiven } = await Like.getUserLikes(userId, { limit: 1, type: 'post' });
      const { total: commentLikesGiven } = await Like.getUserLikes(userId, { limit: 1, type: 'comment' });

      // Get likes received by user (on their posts and comments)
      // This would require joins with posts and comments tables
      const postLikesReceived = await Like.count({
        include: [
          {
            model: Post,
            as: 'post',
            where: { userId },
            required: true,
          },
        ],
      });

      const commentLikesReceived = await Like.count({
        include: [
          {
            model: Comment,
            as: 'comment',
            where: { userId },
            required: true,
          },
        ],
      });

      const totalLikesReceived = postLikesReceived + commentLikesReceived;

      const stats = {
        totalLikesGiven,
        totalLikesReceived,
        postLikesGiven,
        commentLikesGiven,
        postLikesReceived,
        commentLikesReceived,
      };

      logger.info('LikeService: User like statistics retrieved successfully', { userId, stats });
      return stats;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('LikeService: Get user like stats failed', { error: errorMessage, userId });
      throw error;
    }
  }

  /**
   * Bulk check like status for multiple items
   */
  public static async checkMultipleLikeStatus(
    userId: string,
    items: Array<{ type: 'post' | 'comment'; id: string }>
  ): Promise<Record<string, boolean>> {
    try {
      logger.info('LikeService: Checking multiple like statuses', { userId, itemCount: items.length });

      const result: Record<string, boolean> = {};

      // Group items by type
      const postIds = items.filter(item => item.type === 'post').map(item => item.id);
      const commentIds = items.filter(item => item.type === 'comment').map(item => item.id);

      // Check posts
      if (postIds.length > 0) {
        const postLikes = await Like.findAll({
          where: {
            userId,
            postId: postIds,
          },
          attributes: ['postId'],
        });
        
        const likedPostIds = postLikes.map(like => like.postId!).filter(Boolean);
        postIds.forEach(postId => {
          result[`post-${postId}`] = likedPostIds.includes(postId);
        });
      }

      // Check comments
      if (commentIds.length > 0) {
        const commentLikes = await Like.findAll({
          where: {
            userId,
            commentId: commentIds,
          },
          attributes: ['commentId'],
        });
        
        const likedCommentIds = commentLikes.map(like => like.commentId!).filter(Boolean);
        commentIds.forEach(commentId => {
          result[`comment-${commentId}`] = likedCommentIds.includes(commentId);
        });
      }

      logger.info('LikeService: Multiple like statuses checked successfully', { userId, resultCount: Object.keys(result).length });
      return result;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('LikeService: Check multiple like status failed', { error: errorMessage, userId });
      throw error;
    }
  }
}

export default LikeService;