import { Comment } from '../models/Comment';
import { User } from '../models/User';
import { Post } from '../models/Post';
import { Like } from '../models/Like';
import { logger } from '../utils/logger';

export interface CreateCommentData {
  content: string;
  parentId?: string;
}

export interface UpdateCommentData {
  content: string;
}

export interface CommentListOptions {
  limit?: number;
  offset?: number;
  includeUser?: boolean;
  includeReplies?: boolean;
  sortBy?: 'createdAt' | 'likesCount';
  sortOrder?: 'ASC' | 'DESC';
}

export class CommentService {
  /**
   * Create a new comment
   */
  public static async createComment(
    postId: string,
    userId: string,
    commentData: CreateCommentData
  ): Promise<Comment> {
    try {
      logger.info('CommentService: Creating new comment', {
        postId,
        userId,
        parentId: commentData.parentId,
      });

      // Verify post exists and is active
      const post = await Post.findActiveById(postId);
      if (!post) {
        throw new Error('Post not found');
      }

      // Verify user exists and is active
      const user = await User.findByPk(userId);
      if (!user || user.isDeleted) {
        throw new Error('User not found or deactivated');
      }

      // If this is a reply, verify parent comment exists
      if (commentData.parentId) {
        const parentComment = await Comment.findActiveById(
          commentData.parentId
        );
        if (!parentComment) {
          throw new Error('Parent comment not found');
        }
        if (parentComment.postId !== postId) {
          throw new Error('Parent comment does not belong to this post');
        }
      }

      // Create the comment
      const createData: any = {
        postId,
        userId,
        content: commentData.content,
      };
      
      if (commentData.parentId) {
        createData.parentId = commentData.parentId;
      }
      
      const comment = await Comment.create(createData);

      // Update post's comments count
      await post.incrementCommentsCount();

      // If this is a reply, update parent comment's replies count
      if (commentData.parentId) {
        const parentComment = await Comment.findByPk(commentData.parentId);
        if (parentComment) {
          await parentComment.incrementRepliesCount();
        }
      }

      // Load the complete comment with associations
      const completeComment = await Comment.findActiveById(comment.id);

      logger.info('CommentService: Comment created successfully', {
        commentId: comment.id,
        postId,
        userId,
      });
      return completeComment!;
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : 'Unknown error';
      logger.error('CommentService: Comment creation failed', {
        error: errorMessage,
        postId,
        userId,
      });
      throw error;
    }
  }

  /**
   * Get comment by ID
   */
  public static async getCommentById(
    commentId: string,
    viewerId?: string
  ): Promise<Comment | null> {
    try {
      logger.info('CommentService: Getting comment by ID', {
        commentId,
        viewerId,
      });

      const comment = await Comment.findActiveById(commentId);
      if (!comment) {
        return null;
      }

      // Add viewer-specific context if needed
      if (viewerId) {
        // Check if viewer has liked this comment
        const hasLiked = await Like.hasUserLikedComment(viewerId, commentId);
        // You could extend the comment object with this information
      }

      logger.info('CommentService: Comment retrieved successfully', {
        commentId,
      });
      return comment;
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : 'Unknown error';
      logger.error('CommentService: Get comment failed', {
        error: errorMessage,
        commentId,
      });
      throw error;
    }
  }

  /**
   * Update a comment
   */
  public static async updateComment(
    commentId: string,
    userId: string,
    updateData: UpdateCommentData
  ): Promise<Comment> {
    try {
      logger.info('CommentService: Updating comment', { commentId, userId });

      const comment = await Comment.findActiveById(commentId);
      if (!comment) {
        throw new Error('Comment not found');
      }

      // Verify ownership
      if (comment.userId !== userId) {
        throw new Error('Unauthorized: You can only edit your own comments');
      }

      // Update comment
      await comment.update({ content: updateData.content });

      // Load updated comment with associations
      const updatedComment = await Comment.findActiveById(commentId);

      logger.info('CommentService: Comment updated successfully', {
        commentId,
        userId,
      });
      return updatedComment!;
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : 'Unknown error';
      logger.error('CommentService: Comment update failed', {
        error: errorMessage,
        commentId,
        userId,
      });
      throw error;
    }
  }

  /**
   * Delete a comment
   */
  public static async deleteComment(
    commentId: string,
    userId: string
  ): Promise<void> {
    try {
      logger.info('CommentService: Deleting comment', { commentId, userId });

      const comment = await Comment.findActiveById(commentId);
      if (!comment) {
        throw new Error('Comment not found');
      }

      // Verify ownership
      if (comment.userId !== userId) {
        throw new Error('Unauthorized: You can only delete your own comments');
      }

      // Soft delete the comment
      await comment.softDelete();

      // Update post's comments count
      const post = await Post.findByPk(comment.postId);
      if (post) {
        await post.decrementCommentsCount();
      }

      // If this is a reply, update parent comment's replies count
      if (comment.parentId) {
        const parentComment = await Comment.findByPk(comment.parentId);
        if (parentComment) {
          await parentComment.decrementRepliesCount();
        }
      }

      logger.info('CommentService: Comment deleted successfully', {
        commentId,
        userId,
      });
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : 'Unknown error';
      logger.error('CommentService: Comment deletion failed', {
        error: errorMessage,
        commentId,
        userId,
      });
      throw error;
    }
  }

  /**
   * Get comments for a post
   */
  public static async getPostComments(
    postId: string,
    options: CommentListOptions = {}
  ): Promise<{ comments: Comment[]; total: number }> {
    try {
      const { limit = 20, offset = 0, includeReplies = false } = options;
      logger.info('CommentService: Getting post comments', {
        postId,
        limit,
        offset,
        includeReplies,
      });

      const findOptions = {
        limit,
        offset,
        includeReplies,
      };
      
      if (!includeReplies) {
        (findOptions as any).parentId = null;
      }
      
      const { comments, total } = await Comment.findByPostId(postId, findOptions);

      logger.info('CommentService: Post comments retrieved successfully', {
        postId,
        count: comments.length,
        total,
      });
      return { comments, total };
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : 'Unknown error';
      logger.error('CommentService: Get post comments failed', {
        error: errorMessage,
        postId,
      });
      throw error;
    }
  }

  /**
   * Get replies to a comment
   */
  public static async getCommentReplies(
    commentId: string,
    options: CommentListOptions = {}
  ): Promise<{ comments: Comment[]; total: number }> {
    try {
      const { limit = 10, offset = 0 } = options;
      logger.info('CommentService: Getting comment replies', {
        commentId,
        limit,
        offset,
      });

      const { comments, total } = await Comment.findReplies(commentId, {
        limit,
        offset,
      });

      logger.info('CommentService: Comment replies retrieved successfully', {
        commentId,
        count: comments.length,
        total,
      });
      return { comments, total };
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : 'Unknown error';
      logger.error('CommentService: Get comment replies failed', {
        error: errorMessage,
        commentId,
      });
      throw error;
    }
  }

  /**
   * Get comment thread (comment and its replies)
   */
  public static async getCommentThread(
    commentId: string,
    options: { maxDepth?: number } = {}
  ): Promise<Comment[]> {
    try {
      const { maxDepth = 3 } = options;
      logger.info('CommentService: Getting comment thread', {
        commentId,
        maxDepth,
      });

      const thread = await Comment.getCommentThread(commentId, { maxDepth });

      logger.info('CommentService: Comment thread retrieved successfully', {
        commentId,
        threadLength: thread.length,
      });
      return thread;
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : 'Unknown error';
      logger.error('CommentService: Get comment thread failed', {
        error: errorMessage,
        commentId,
      });
      throw error;
    }
  }

  /**
   * Like or unlike a comment
   */
  public static async toggleCommentLike(
    commentId: string,
    userId: string
  ): Promise<{ liked: boolean }> {
    try {
      logger.info('CommentService: Toggling comment like', {
        commentId,
        userId,
      });

      // Verify comment exists and is active
      const comment = await Comment.findActiveById(commentId);
      if (!comment) {
        throw new Error('Comment not found');
      }

      // Toggle like
      const { liked } = await Like.toggleCommentLike(userId, commentId);

      // Update comment's likes count
      if (liked) {
        await comment.incrementLikesCount();
      } else {
        await comment.decrementLikesCount();
      }

      logger.info('CommentService: Comment like toggled successfully', {
        commentId,
        userId,
        liked,
      });
      return { liked };
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : 'Unknown error';
      logger.error('CommentService: Toggle comment like failed', {
        error: errorMessage,
        commentId,
        userId,
      });
      throw error;
    }
  }

  /**
   * Get comment likes
   */
  public static async getCommentLikes(
    commentId: string,
    options: { limit?: number; offset?: number } = {}
  ): Promise<{ likes: any[]; total: number }> {
    try {
      const { limit = 20, offset = 0 } = options;
      logger.info('CommentService: Getting comment likes', {
        commentId,
        limit,
        offset,
      });

      const { likes, total } = await Like.getCommentLikes(commentId, {
        limit,
        offset,
        includeUser: true,
      });

      logger.info('CommentService: Comment likes retrieved successfully', {
        commentId,
        count: likes.length,
        total,
      });
      return { likes, total };
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : 'Unknown error';
      logger.error('CommentService: Get comment likes failed', {
        error: errorMessage,
        commentId,
      });
      throw error;
    }
  }

  /**
   * Get user's comments
   */
  public static async getUserComments(
    userId: string,
    options: CommentListOptions = {}
  ): Promise<{ comments: Comment[]; total: number }> {
    try {
      const { limit = 20, offset = 0 } = options;
      logger.info('CommentService: Getting user comments', {
        userId,
        limit,
        offset,
      });

      // This would need a method on Comment model to find by user ID
      // For now, simplified implementation
      const comments = await Comment.findAll({
        where: {
          userId,
          isDeleted: false,
        },
        include: [
          {
            model: User,
            as: 'user',
            attributes: [
              'id',
              'username',
              'firstName',
              'lastName',
              'profileImageUrl',
            ],
          },
          {
            model: Post,
            as: 'post',
            attributes: ['id', 'content'],
            where: { isDeleted: false },
          },
        ],
        order: [['createdAt', 'DESC']],
        limit,
        offset,
      });

      const total = await Comment.count({
        where: {
          userId,
          isDeleted: false,
        },
      });

      logger.info('CommentService: User comments retrieved successfully', {
        userId,
        count: comments.length,
        total,
      });
      return { comments, total };
    } catch (error) {
      const errorMessage =
        error instanceof Error ? error.message : 'Unknown error';
      logger.error('CommentService: Get user comments failed', {
        error: errorMessage,
        userId,
      });
      throw error;
    }
  }
}

export default CommentService;
