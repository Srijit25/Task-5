import { Post } from '../models/Post';
import { User } from '../models/User';
import { Tag } from '../models/Tag';
import { Like } from '../models/Like';
import { Comment } from '../models/Comment';
import { logger } from '../utils/logger';

export interface CreatePostData {
  content: string;
  mediaUrls?: string[];
  tagNames?: string[];
  visibility?: 'public' | 'private' | 'friends';
  allowComments?: boolean;
  allowLikes?: boolean;
}

export interface UpdatePostData {
  content?: string;
  mediaUrls?: string[];
  tagNames?: string[];
  visibility?: 'public' | 'private' | 'friends';
  allowComments?: boolean;
  allowLikes?: boolean;
}

export interface PostListOptions {
  limit?: number;
  offset?: number;
  sortBy?: 'createdAt' | 'likes' | 'comments' | 'views';
  sortOrder?: 'ASC' | 'DESC';
  userId?: string;
  tagName?: string;
  includeUser?: boolean;
  includeTags?: boolean;
  includeComments?: boolean;
  visibility?: 'public' | 'private' | 'friends';
}

export interface PostSearchOptions {
  query: string;
  limit?: number;
  offset?: number;
  sortBy?: 'relevance' | 'createdAt' | 'likes';
  tagNames?: string[];
  userId?: string;
}

export class PostService {
  /**
   * Create a new post
   */
  public static async createPost(userId: string, postData: CreatePostData): Promise<Post> {
    try {
      logger.info('PostService: Creating new post', { userId, contentLength: postData.content.length });

      // Verify user exists
      const user = await User.findByPk(userId);
      if (!user || user.isDeleted) {
        throw new Error('User not found');
      }

      // Create the post
      const post = await Post.create({
        userId,
        content: postData.content,
        mediaUrls: postData.mediaUrls || [],
        visibility: postData.visibility || 'public',
      });

      // Handle tags
      if (postData.tagNames && postData.tagNames.length > 0) {
        const tags = await Tag.findOrCreateTags(postData.tagNames);
        await post.setTags(tags);
        
        // Update tag usage counts
        await Promise.all(tags.map(tag => tag.incrementUsageCount()));
      }

      // Update user's post count
      await user.incrementPostsCount();

      // Load associations for return
      await post.reload({
        include: [
          { model: User, as: 'user' },
          { model: Tag, as: 'tags' },
        ],
      });

      logger.info('PostService: Post created successfully', { postId: post.id, userId });
      return post;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('PostService: Create post failed', { error: errorMessage, userId });
      throw error;
    }
  }

  /**
   * Get post by ID
   */
  public static async getPostById(postId: string, viewerId?: string): Promise<Post | null> {
    try {
      logger.info('PostService: Getting post by ID', { postId, viewerId });

      const post = await Post.findByPk(postId, {
        include: [
          { model: User, as: 'user' },
          { model: Tag, as: 'tags' },
        ],
      });

      if (!post || post.isDeleted) {
        return null;
      }

      // Check visibility permissions
      if (post.visibility === 'private' && (!viewerId || post.userId !== viewerId)) {
        return null;
      }

      // Increment view count if viewer is different from author
      if (viewerId && viewerId !== post.userId) {
        await post.incrementViewCount();
      }

      logger.info('PostService: Post retrieved successfully', { postId });
      return post;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('PostService: Get post by ID failed', { error: errorMessage, postId });
      throw error;
    }
  }

  /**
   * Update post
   */
  public static async updatePost(postId: string, userId: string, postData: UpdatePostData): Promise<Post> {
    try {
      logger.info('PostService: Updating post', { postId, userId });

      const post = await Post.findByPk(postId);
      if (!post || post.isDeleted) {
        throw new Error('Post not found');
      }

      // Check ownership
      if (post.userId !== userId) {
        throw new Error('Unauthorized to edit this post');
      }

      // Update basic fields
      const updateData: any = {};
      const allowedFields = ['content', 'mediaUrls', 'visibility', 'allowComments', 'allowLikes'];
      
      allowedFields.forEach(field => {
        if (postData[field as keyof UpdatePostData] !== undefined) {
          updateData[field] = postData[field as keyof UpdatePostData];
        }
      });

      await post.update(updateData);

      // Handle tags update
      if (postData.tagNames !== undefined) {
        // Get current tags
        const currentTags = await post.getTags();
        
        // Remove old tags and decrement their usage
        if (currentTags.length > 0) {
          await Promise.all(currentTags.map(tag => tag.decrementUsageCount()));
          await post.setTags([]);
        }

        // Add new tags
        if (postData.tagNames.length > 0) {
          const newTags = await Tag.findOrCreateTags(postData.tagNames);
          await post.setTags(newTags);
          
          // Update tag usage counts
          await Promise.all(newTags.map(tag => tag.incrementUsageCount()));
        }
      }

      // Reload with associations
      await post.reload({
        include: [
          { model: User, as: 'user' },
          { model: Tag, as: 'tags' },
        ],
      });

      logger.info('PostService: Post updated successfully', { postId });
      return post;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('PostService: Update post failed', { error: errorMessage, postId, userId });
      throw error;
    }
  }

  /**
   * Delete post
   */
  public static async deletePost(postId: string, userId: string): Promise<void> {
    try {
      logger.info('PostService: Deleting post', { postId, userId });

      const post = await Post.findByPk(postId);
      if (!post || post.isDeleted) {
        throw new Error('Post not found');
      }

      // Check ownership
      if (post.userId !== userId) {
        throw new Error('Unauthorized to delete this post');
      }

      // Get tags before deletion
      const tags = await post.getTags();

      // Soft delete the post
      await post.softDelete();

      // Decrement tag usage counts
      if (tags.length > 0) {
        await Promise.all(tags.map(tag => tag.decrementUsageCount()));
      }

      // Update user's post count
      const user = await User.findByPk(userId);
      if (user) {
        await user.decrementPostsCount();
      }

      logger.info('PostService: Post deleted successfully', { postId });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('PostService: Delete post failed', { error: errorMessage, postId, userId });
      throw error;
    }
  }

  /**
   * Get posts with pagination and filtering
   */
  public static async getPosts(options: PostListOptions = {}): Promise<{ posts: Post[]; total: number }> {
    try {
      const {
        limit = 20,
        offset = 0,
        sortBy = 'createdAt',
        sortOrder = 'DESC',
        userId,
        tagName,
        includeUser = true,
        includeTags = true,
        visibility = 'public',
      } = options;

      logger.info('PostService: Getting posts', { limit, offset, sortBy, userId, tagName });

      const posts = await Post.findAll({
        where: {
          isDeleted: false,
          ...(userId && { userId }),
          ...(visibility && { visibility }),
        },
        include: [
          ...(includeUser ? [{
            model: User,
            as: 'user',
            attributes: ['id', 'username', 'firstName', 'lastName', 'profileImageUrl'],
          }] : []),
        ],
        order: [[sortBy || 'createdAt', sortOrder || 'DESC']],
        limit,
        offset,
      });
      
      // For consistency with other methods, we'll return a simplified total
      const total = posts.length;

      logger.info('PostService: Posts retrieved successfully', { count: posts.length, total });
      return { posts, total };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('PostService: Get posts failed', { error: errorMessage, options });
      throw error;
    }
  }

  /**
   * Search posts
   */
  public static async searchPosts(options: PostSearchOptions): Promise<{ posts: Post[]; total: number }> {
    try {
      const {
        query,
        limit = 20,
        offset = 0,
        sortBy = 'relevance',
        tagNames,
        userId,
      } = options;

      logger.info('PostService: Searching posts', { query, limit, offset, sortBy });

      const { posts, total } = await Post.searchPosts(query, {
        limit,
        offset,
      });

      logger.info('PostService: Post search completed', { query, resultsCount: posts.length, total });
      return { posts, total };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('PostService: Post search failed', { error: errorMessage, query: options.query });
      throw error;
    }
  }

  /**
   * Get trending posts
   */
  public static async getTrendingPosts(options: {
    timeframe?: 'day' | 'week' | 'month' | 'all';
    limit?: number;
    offset?: number;
  } = {}): Promise<{ posts: Post[]; total: number }> {
    try {
      const { timeframe = 'week', limit = 20, offset = 0 } = options;
      logger.info('PostService: Getting trending posts', { timeframe, limit, offset });

      const { posts, total } = await Post.getTrendingPosts({
        timeframe: timeframe === 'all' ? 'week' : timeframe as 'day' | 'week' | 'month',
        limit,
        offset,
      });

      logger.info('PostService: Trending posts retrieved successfully', { count: posts.length, total });
      return { posts, total };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('PostService: Get trending posts failed', { error: errorMessage, options });
      throw error;
    }
  }

  /**
   * Get user feed (posts from followed users)
   */
  public static async getUserFeed(userId: string, options: {
    limit?: number;
    offset?: number;
  } = {}): Promise<{ posts: Post[]; total: number }> {
    try {
      const { limit = 20, offset = 0 } = options;
      logger.info('PostService: Getting user feed', { userId, limit, offset });

      const { posts, total } = await Post.getFeedPosts({
        limit,
        offset,
        userIds: [userId], // Simplified - in real implementation would get following user IDs
      });

      logger.info('PostService: User feed retrieved successfully', { userId, count: posts.length, total });
      return { posts, total };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('PostService: Get user feed failed', { error: errorMessage, userId });
      throw error;
    }
  }

  /**
   * Get posts by user
   */
  public static async getUserPosts(userId: string, viewerId?: string, options: {
    limit?: number;
    offset?: number;
    includePrivate?: boolean;
  } = {}): Promise<{ posts: Post[]; total: number }> {
    try {
      const { limit = 20, offset = 0, includePrivate = false } = options;
      logger.info('PostService: Getting user posts', { userId, viewerId, limit, offset });

      // Determine visibility
      let visibility: string[] = ['public'];
      if (includePrivate && viewerId === userId) {
        visibility = ['public', 'private', 'friends'];
      }

      const posts = await Post.findByUserId(userId, {
        limit,
        offset,
        includeDeleted: false, // Always exclude deleted posts
      });
      
      // For consistency, return total as posts length (simplified)
      const total = posts.length;

      logger.info('PostService: User posts retrieved successfully', { userId, count: posts.length, total });
      return { posts, total };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('PostService: Get user posts failed', { error: errorMessage, userId });
      throw error;
    }
  }

  /**
   * Like or unlike a post
   */
  public static async toggleLike(postId: string, userId: string): Promise<{ liked: boolean; likesCount: number }> {
    try {
      logger.info('PostService: Toggling post like', { postId, userId });

      const post = await Post.findByPk(postId);
      if (!post || post.isDeleted) {
        throw new Error('Post not found');
      }

      // Posts allow likes by default in this implementation

      // Toggle like
      const { liked } = await Like.toggleLike(userId, 'post', postId);

      // Update post likes count
      if (liked) {
        await post.incrementLikesCount();
      } else {
        await post.decrementLikesCount();
      }

      // Get updated likes count
      await post.reload();

      logger.info('PostService: Post like toggled successfully', { postId, userId, liked });
      return { liked, likesCount: post.likesCount };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('PostService: Toggle post like failed', { error: errorMessage, postId, userId });
      throw error;
    }
  }

  /**
   * Get post statistics
   */
  public static async getPostStats(postId: string): Promise<{
    likesCount: number;
    commentsCount: number;
    viewsCount: number;
    sharesCount: number;
  }> {
    try {
      logger.info('PostService: Getting post stats', { postId });

      const post = await Post.findByPk(postId);
      if (!post || post.isDeleted) {
        throw new Error('Post not found');
      }

      const stats = {
        likesCount: post.likesCount,
        commentsCount: post.commentsCount,
        viewsCount: post.viewsCount,
        sharesCount: post.sharesCount || 0,
      };

      logger.info('PostService: Post stats retrieved successfully', { postId, stats });
      return stats;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('PostService: Get post stats failed', { error: errorMessage, postId });
      throw error;
    }
  }
}

export default PostService;