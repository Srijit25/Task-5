import { User } from '../models/User';
import { Follow } from '../models/Follow';
import { Post } from '../models/Post';
import { logger } from '../utils/logger';

export interface UserProfileData {
  firstName?: string;
  lastName?: string;
  bio?: string;
  profileImageUrl?: string;
  coverImageUrl?: string;
  location?: string;
  website?: string;
  dateOfBirth?: Date;
}

export interface UserSearchOptions {
  query: string;
  limit?: number;
  offset?: number;
  excludeIds?: string[];
}

export interface UserListOptions {
  limit?: number;
  offset?: number;
  sortBy?: 'createdAt' | 'username' | 'followersCount' | 'postsCount';
  sortOrder?: 'ASC' | 'DESC';
}

export class UserService {
  /**
   * Get user profile by ID
   */
  public static async getUserProfile(userId: string, viewerId?: string): Promise<User | null> {
    try {
      logger.info('UserService: Getting user profile', { userId, viewerId });

      const user = await User.findByPk(userId);
      if (!user || user.isDeleted) {
        return null;
      }

      // If there's a viewer, we might want to add additional context like follow status
      if (viewerId && viewerId !== userId) {
        // Check if viewer follows this user
        const isFollowing = await Follow.isFollowing(viewerId, userId);
        // Add this information to the user object (extend if needed)
      }

      logger.info('UserService: User profile retrieved successfully', { userId });
      return user;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('UserService: Get user profile failed', { error: errorMessage, userId });
      throw error;
    }
  }

  /**
   * Get user by username
   */
  public static async getUserByUsername(username: string, viewerId?: string): Promise<User | null> {
    try {
      logger.info('UserService: Getting user by username', { username, viewerId });

      const user = await User.findByUsername(username);
      if (!user) {
        return null;
      }

      logger.info('UserService: User found by username', { userId: user.id, username });
      return user;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('UserService: Get user by username failed', { error: errorMessage, username });
      throw error;
    }
  }

  /**
   * Update user profile
   */
  public static async updateProfile(userId: string, profileData: UserProfileData): Promise<User> {
    try {
      logger.info('UserService: Updating user profile', { userId });

      const user = await User.findByPk(userId);
      if (!user || user.isDeleted) {
        throw new Error('User not found');
      }

      // Update allowed fields
      const allowedFields = [
        'firstName',
        'lastName',
        'bio',
        'profileImageUrl',
        'coverImageUrl',
        'location',
        'website',
        'dateOfBirth',
      ];

      const updateData: any = {};
      allowedFields.forEach(field => {
        if (profileData[field as keyof UserProfileData] !== undefined) {
          updateData[field] = profileData[field as keyof UserProfileData];
        }
      });

      await user.update(updateData);

      logger.info('UserService: Profile updated successfully', { userId });
      return user;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('UserService: Profile update failed', { error: errorMessage, userId });
      throw error;
    }
  }

  /**
   * Search users
   */
  public static async searchUsers(options: UserSearchOptions): Promise<{ users: User[]; total: number }> {
    try {
      const { query, limit = 20, offset = 0, excludeIds = [] } = options;
      logger.info('UserService: Searching users', { query, limit, offset });

      const { users, total } = await User.searchUsers(query, {
        limit,
        offset,
        excludeIds,
      });

      logger.info('UserService: User search completed', { query, resultsCount: users.length, total });
      return { users, total };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('UserService: User search failed', { error: errorMessage, query: options.query });
      throw error;
    }
  }

  /**
   * Get user followers
   */
  public static async getUserFollowers(userId: string, options: UserListOptions = {}): Promise<{ followers: User[]; total: number }> {
    try {
      const { limit = 20, offset = 0 } = options;
      logger.info('UserService: Getting user followers', { userId, limit, offset });

      const { follows, total } = await Follow.getFollowers(userId, {
        limit,
        offset,
        includeUser: true,
      });

      const followers = follows.map(follow => follow.follower!).filter(Boolean);

      logger.info('UserService: Followers retrieved successfully', { userId, count: followers.length, total });
      return { followers, total };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('UserService: Get followers failed', { error: errorMessage, userId });
      throw error;
    }
  }

  /**
   * Get users that a user is following
   */
  public static async getUserFollowing(userId: string, options: UserListOptions = {}): Promise<{ following: User[]; total: number }> {
    try {
      const { limit = 20, offset = 0 } = options;
      logger.info('UserService: Getting user following', { userId, limit, offset });

      const { follows, total } = await Follow.getFollowing(userId, {
        limit,
        offset,
        includeUser: true,
      });

      const following = follows.map(follow => follow.following!).filter(Boolean);

      logger.info('UserService: Following retrieved successfully', { userId, count: following.length, total });
      return { following, total };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('UserService: Get following failed', { error: errorMessage, userId });
      throw error;
    }
  }

  /**
   * Follow or unfollow a user
   */
  public static async toggleFollow(followerId: string, followingId: string): Promise<{ following: boolean }> {
    try {
      logger.info('UserService: Toggling follow', { followerId, followingId });

      if (followerId === followingId) {
        throw new Error('Users cannot follow themselves');
      }

      // Check if both users exist and are not deleted
      const [follower, following] = await Promise.all([
        User.findByPk(followerId),
        User.findByPk(followingId),
      ]);

      if (!follower || follower.isDeleted) {
        throw new Error('Follower user not found');
      }

      if (!following || following.isDeleted) {
        throw new Error('Following user not found');
      }

      // Toggle follow relationship
      const { following: isFollowing } = await Follow.toggleFollow(followerId, followingId);

      // Update counters
      if (isFollowing) {
        await Promise.all([
          follower.incrementFollowingCount(),
          following.incrementFollowersCount(),
        ]);
      } else {
        await Promise.all([
          follower.decrementFollowingCount(),
          following.decrementFollowersCount(),
        ]);
      }

      logger.info('UserService: Follow toggled successfully', { followerId, followingId, isFollowing });
      return { following: isFollowing };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('UserService: Toggle follow failed', { error: errorMessage, followerId, followingId });
      throw error;
    }
  }

  /**
   * Get user statistics
   */
  public static async getUserStats(userId: string): Promise<{
    postsCount: number;
    followersCount: number;
    followingCount: number;
    joinedAt: Date;
  }> {
    try {
      logger.info('UserService: Getting user stats', { userId });

      const user = await User.findByPk(userId);
      if (!user || user.isDeleted) {
        throw new Error('User not found');
      }

      const stats = {
        postsCount: user.postsCount,
        followersCount: user.followersCount,
        followingCount: user.followingCount,
        joinedAt: user.createdAt,
      };

      logger.info('UserService: User stats retrieved successfully', { userId, stats });
      return stats;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('UserService: Get user stats failed', { error: errorMessage, userId });
      throw error;
    }
  }

  /**
   * Get suggested users to follow
   */
  public static async getSuggestedUsers(userId: string, options: { limit?: number } = {}): Promise<User[]> {
    try {
      const { limit = 10 } = options;
      logger.info('UserService: Getting suggested users', { userId, limit });

      const suggestedUsers = await Follow.getSuggestedUsers(userId, {
        limit,
        excludeFollowing: true,
      });

      logger.info('UserService: Suggested users retrieved successfully', { userId, count: suggestedUsers.length });
      return suggestedUsers;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('UserService: Get suggested users failed', { error: errorMessage, userId });
      throw error;
    }
  }

  /**
   * Get user posts
   */
  public static async getUserPosts(userId: string, options: {
    limit?: number;
    offset?: number;
    viewerId?: string;
  } = {}): Promise<{ posts: Post[]; total: number }> {
    try {
      const { limit = 20, offset = 0, viewerId } = options;
      logger.info('UserService: Getting user posts', { userId, limit, offset, viewerId });

      const posts = await Post.findByUserId(userId, {
        limit,
        offset,
        includeDeleted: false,
      });

      // Get total count for pagination
      const total = await Post.count({
        where: {
          userId,
          isDeleted: false,
        },
      });

      logger.info('UserService: User posts retrieved successfully', { userId, count: posts.length, total });
      return { posts, total };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('UserService: Get user posts failed', { error: errorMessage, userId });
      throw error;
    }
  }

  /**
   * Deactivate user account
   */
  public static async deactivateAccount(userId: string): Promise<void> {
    try {
      logger.info('UserService: Deactivating user account', { userId });

      const user = await User.findByPk(userId);
      if (!user) {
        throw new Error('User not found');
      }

      if (user.isDeleted) {
        throw new Error('Account is already deactivated');
      }

      await user.softDelete();

      logger.info('UserService: Account deactivated successfully', { userId });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('UserService: Account deactivation failed', { error: errorMessage, userId });
      throw error;
    }
  }

  /**
   * Reactivate user account
   */
  public static async reactivateAccount(userId: string): Promise<void> {
    try {
      logger.info('UserService: Reactivating user account', { userId });

      const user = await User.findByPk(userId);
      if (!user) {
        throw new Error('User not found');
      }

      if (!user.isDeleted) {
        throw new Error('Account is already active');
      }

      await user.restore();

      logger.info('UserService: Account reactivated successfully', { userId });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('UserService: Account reactivation failed', { error: errorMessage, userId });
      throw error;
    }
  }

  /**
   * Check if username is available
   */
  public static async checkUsernameAvailability(username: string, excludeUserId?: string): Promise<boolean> {
    try {
      logger.info('UserService: Checking username availability', { username, excludeUserId });

      const isAvailable = await User.isUsernameAvailable(username, excludeUserId);

      logger.info('UserService: Username availability checked', { username, isAvailable });
      return isAvailable;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('UserService: Username availability check failed', { error: errorMessage, username });
      throw error;
    }
  }

  /**
   * Check if email is available
   */
  public static async checkEmailAvailability(email: string, excludeUserId?: string): Promise<boolean> {
    try {
      logger.info('UserService: Checking email availability', { email, excludeUserId });

      const isAvailable = await User.isEmailAvailable(email, excludeUserId);

      logger.info('UserService: Email availability checked', { email, isAvailable });
      return isAvailable;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('UserService: Email availability check failed', { error: errorMessage, email });
      throw error;
    }
  }

  /**
   * Get multiple users by IDs
   */
  public static async getUsersByIds(userIds: string[]): Promise<User[]> {
    try {
      logger.info('UserService: Getting users by IDs', { userIds, count: userIds.length });

      const users = await User.findByIds(userIds);

      logger.info('UserService: Users retrieved by IDs successfully', { requestedCount: userIds.length, foundCount: users.length });
      return users;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('UserService: Get users by IDs failed', { error: errorMessage, userIds });
      throw error;
    }
  }
}

export default UserService;