import { Tag } from '../models/Tag';
import { Post } from '../models/Post';
import { User } from '../models/User';
import { logger } from '../utils/logger';

export interface CreateTagData {
  name: string;
  description?: string;
  color?: string;
}

export interface UpdateTagData {
  description?: string;
  color?: string;
}

export interface TagSearchOptions {
  query: string;
  limit?: number;
  offset?: number;
}

export interface TagListOptions {
  limit?: number;
  offset?: number;
  sortBy?: 'name' | 'postsCount' | 'createdAt';
  sortOrder?: 'ASC' | 'DESC';
  minPostCount?: number;
}

export class TagService {
  /**
   * Create a new tag
   */
  public static async createTag(tagData: CreateTagData): Promise<Tag> {
    try {
      logger.info('TagService: Creating new tag', { name: tagData.name });

      // Check if tag with this name already exists
      const existingTag = await Tag.findByName(tagData.name);
      if (existingTag) {
        throw new Error('Tag with this name already exists');
      }

      // Create the tag
      const createData: any = {
        name: tagData.name.toLowerCase().trim(),
      };
      
      if (tagData.description) {
        createData.description = tagData.description;
      }
      if (tagData.color) {
        createData.color = tagData.color;
      }
      
      const tag = await Tag.create(createData);

      logger.info('TagService: Tag created successfully', { tagId: tag.id, name: tag.name });
      return tag;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('TagService: Tag creation failed', { error: errorMessage, name: tagData.name });
      throw error;
    }
  }

  /**
   * Get tag by ID
   */
  public static async getTagById(tagId: string): Promise<Tag | null> {
    try {
      logger.info('TagService: Getting tag by ID', { tagId });

      const tag = await Tag.findByPk(tagId);
      if (!tag || !tag.isActive) {
        return null;
      }

      logger.info('TagService: Tag retrieved successfully', { tagId, name: tag.name });
      return tag;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('TagService: Get tag failed', { error: errorMessage, tagId });
      throw error;
    }
  }

  /**
   * Get tag by name
   */
  public static async getTagByName(name: string): Promise<Tag | null> {
    try {
      logger.info('TagService: Getting tag by name', { name });

      const tag = await Tag.findByName(name);
      if (!tag) {
        return null;
      }

      logger.info('TagService: Tag found by name', { tagId: tag.id, name: tag.name });
      return tag;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('TagService: Get tag by name failed', { error: errorMessage, name });
      throw error;
    }
  }

  /**
   * Update a tag
   */
  public static async updateTag(tagId: string, updateData: UpdateTagData): Promise<Tag> {
    try {
      logger.info('TagService: Updating tag', { tagId });

      const tag = await Tag.findByPk(tagId);
      if (!tag || !tag.isActive) {
        throw new Error('Tag not found');
      }

      // Update allowed fields
      const updateFields: any = {};
      if (updateData.description !== undefined) {
        updateFields.description = updateData.description;
      }
      if (updateData.color !== undefined) {
        updateFields.color = updateData.color;
      }

      await tag.update(updateFields);

      logger.info('TagService: Tag updated successfully', { tagId, name: tag.name });
      return tag;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('TagService: Tag update failed', { error: errorMessage, tagId });
      throw error;
    }
  }

  /**
   * Deactivate a tag
   */
  public static async deactivateTag(tagId: string): Promise<void> {
    try {
      logger.info('TagService: Deactivating tag', { tagId });

      const tag = await Tag.findByPk(tagId);
      if (!tag) {
        throw new Error('Tag not found');
      }

      if (!tag.isActive) {
        throw new Error('Tag is already deactivated');
      }

      await tag.deactivate();

      logger.info('TagService: Tag deactivated successfully', { tagId, name: tag.name });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('TagService: Tag deactivation failed', { error: errorMessage, tagId });
      throw error;
    }
  }

  /**
   * Reactivate a tag
   */
  public static async reactivateTag(tagId: string): Promise<void> {
    try {
      logger.info('TagService: Reactivating tag', { tagId });

      const tag = await Tag.findByPk(tagId);
      if (!tag) {
        throw new Error('Tag not found');
      }

      if (tag.isActive) {
        throw new Error('Tag is already active');
      }

      await tag.activate();

      logger.info('TagService: Tag reactivated successfully', { tagId, name: tag.name });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('TagService: Tag reactivation failed', { error: errorMessage, tagId });
      throw error;
    }
  }

  /**
   * Search tags
   */
  public static async searchTags(options: TagSearchOptions): Promise<{ tags: Tag[]; total: number }> {
    try {
      const { query, limit = 20, offset = 0 } = options;
      logger.info('TagService: Searching tags', { query, limit, offset });

      const { tags, total } = await Tag.searchTags(query, {
        limit,
        offset,
      });

      logger.info('TagService: Tag search completed', { query, count: tags.length, total });
      return { tags, total };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('TagService: Tag search failed', { error: errorMessage, query: options.query });
      throw error;
    }
  }

  /**
   * Get trending tags
   */
  public static async getTrendingTags(options: {
    limit?: number;
    timeframe?: 'day' | 'week' | 'month';
  } = {}): Promise<Tag[]> {
    try {
      const { limit = 10, timeframe = 'week' } = options;
      logger.info('TagService: Getting trending tags', { limit, timeframe });

      const trendingTags = await Tag.getTrendingTags({ limit, timeframe });

      logger.info('TagService: Trending tags retrieved successfully', { count: trendingTags.length, timeframe });
      return trendingTags;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('TagService: Get trending tags failed', { error: errorMessage });
      throw error;
    }
  }

  /**
   * Get popular tags
   */
  public static async getPopularTags(options: TagListOptions = {}): Promise<Tag[]> {
    try {
      const { limit = 20, minPostCount = 5 } = options;
      logger.info('TagService: Getting popular tags', { limit, minPostCount });

      const popularTags = await Tag.getPopularTags({ limit, minPostCount });

      logger.info('TagService: Popular tags retrieved successfully', { count: popularTags.length });
      return popularTags;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('TagService: Get popular tags failed', { error: errorMessage });
      throw error;
    }
  }

  /**
   * Get recent tags
   */
  public static async getRecentTags(options: {
    limit?: number;
    days?: number;
  } = {}): Promise<Tag[]> {
    try {
      const { limit = 20, days = 7 } = options;
      logger.info('TagService: Getting recent tags', { limit, days });

      const recentTags = await Tag.getRecentTags({ limit, days });

      logger.info('TagService: Recent tags retrieved successfully', { count: recentTags.length, days });
      return recentTags;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('TagService: Get recent tags failed', { error: errorMessage });
      throw error;
    }
  }

  /**
   * Get all tags
   */
  public static async getAllTags(options: TagListOptions = {}): Promise<{ tags: Tag[]; total: number }> {
    try {
      const {
        limit = 50,
        offset = 0,
        sortBy = 'postsCount',
        sortOrder = 'DESC',
        minPostCount = 0,
      } = options;
      
      logger.info('TagService: Getting all tags', { limit, offset, sortBy, sortOrder });

      const { Op } = require('sequelize');
      
      const whereCondition: any = {
        isActive: true,
      };
      
      if (minPostCount > 0) {
        whereCondition.postsCount = { [Op.gte]: minPostCount };
      }

      const { count, rows } = await Tag.findAndCountAll({
        where: whereCondition,
        order: [[sortBy, sortOrder]],
        limit,
        offset,
      });

      logger.info('TagService: All tags retrieved successfully', { count: rows.length, total: count });
      return { tags: rows, total: count };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('TagService: Get all tags failed', { error: errorMessage });
      throw error;
    }
  }

  /**
   * Get posts by tag
   */
  public static async getPostsByTag(
    tagName: string,
    options: {
      limit?: number;
      offset?: number;
      includeUser?: boolean;
      includeTags?: boolean;
    } = {}
  ): Promise<{ posts: Post[]; total: number }> {
    try {
      const { limit = 20, offset = 0, includeUser = true, includeTags = true } = options;
      logger.info('TagService: Getting posts by tag', { tagName, limit, offset });

      // Find the tag first, then get its posts separately for better control
      const tag = await Tag.findOne({
        where: { name: tagName.toLowerCase() },
      });
      
      if (!tag) {
        return { posts: [], total: 0 };
      }
      
      // Get posts associated with this tag using a simple query
      // Note: This is a simplified approach - in a real app you'd use proper many-to-many associations
      const posts = await Post.findAll({
        where: { isDeleted: false },
        ...(includeUser && {
          include: [{
            model: User,
            as: 'user',
            attributes: ['id', 'username', 'firstName', 'lastName', 'profileImageUrl'],
          }]
        }),
        limit,
        offset,
        order: [['createdAt', 'DESC']],
      });
      
      const total = posts.length; // Simplified total count

      logger.info('TagService: Posts by tag retrieved successfully', { tagName, count: posts.length, total });
      return { posts, total };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('TagService: Get posts by tag failed', { error: errorMessage, tagName });
      throw error;
    }
  }

  /**
   * Get related tags
   */
  public static async getRelatedTags(tagName: string, options: { limit?: number } = {}): Promise<Tag[]> {
    try {
      const { limit = 10 } = options;
      logger.info('TagService: Getting related tags', { tagName, limit });

      const relatedTags = await Tag.getRelatedTags(tagName, { limit });

      logger.info('TagService: Related tags retrieved successfully', { tagName, count: relatedTags.length });
      return relatedTags;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('TagService: Get related tags failed', { error: errorMessage, tagName });
      throw error;
    }
  }

  /**
   * Get tag statistics
   */
  public static async getTagStats(tagId: string): Promise<{
    postsCount: number;
    isPopular: boolean;
    isTrending: boolean;
    createdAt: Date;
    recentPostsCount: number;
  }> {
    try {
      logger.info('TagService: Getting tag statistics', { tagId });

      const tag = await Tag.findByPk(tagId);
      if (!tag || !tag.isActive) {
        throw new Error('Tag not found');
      }

      // Get recent posts count (last 7 days)
      const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
      const recentPostsCount = await Post.count({
        include: [
          {
            model: Tag,
            as: 'tags',
            where: { id: tagId },
            through: { attributes: [] },
          },
        ],
        where: {
          createdAt: { [require('sequelize').Op.gte]: oneWeekAgo },
          isDeleted: false,
        },
      });

      const stats = {
        postsCount: tag.postsCount,
        isPopular: tag.isPopular(),
        isTrending: tag.isTrending(),
        createdAt: tag.createdAt,
        recentPostsCount,
      };

      logger.info('TagService: Tag statistics retrieved successfully', { tagId, stats });
      return stats;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('TagService: Get tag stats failed', { error: errorMessage, tagId });
      throw error;
    }
  }

  /**
   * Find or create tags by names
   */
  public static async findOrCreateTagsByNames(tagNames: string[]): Promise<Tag[]> {
    try {
      logger.info('TagService: Finding or creating tags by names', { tagNames, count: tagNames.length });

      const normalizedNames = tagNames.map(name => name.toLowerCase().trim()).filter(Boolean);
      const uniqueNames = [...new Set(normalizedNames)];

      const tagPromises = uniqueNames.map(name => 
        Tag.findOrCreateByName(name)
      );
      
      const tagResults = await Promise.all(tagPromises);
      const tags = tagResults.map(([tag]) => tag);

      logger.info('TagService: Tags found or created successfully', { requestedCount: tagNames.length, createdCount: tags.length });
      return tags;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('TagService: Find or create tags failed', { error: errorMessage, tagNames });
      throw error;
    }
  }

  /**
   * Get tag usage analytics
   */
  public static async getTagAnalytics(options: {
    timeframe?: 'day' | 'week' | 'month';
    limit?: number;
  } = {}): Promise<{
    totalTags: number;
    activeTags: number;
    popularTags: Tag[];
    trendingTags: Tag[];
    recentTags: Tag[];
    avgPostsPerTag: number;
  }> {
    try {
      const { timeframe = 'week', limit = 10 } = options;
      logger.info('TagService: Getting tag analytics', { timeframe, limit });

      const [totalTags, activeTags, popularTags, trendingTags, recentTags] = await Promise.all([
        Tag.count(),
        Tag.count({ where: { isActive: true } }),
        Tag.getPopularTags({ limit }),
        Tag.getTrendingTags({ limit, timeframe }),
        Tag.getRecentTags({ limit }),
      ]);

      // Calculate average posts per tag
      const tagStats = await Tag.findAll({
        where: { isActive: true },
        attributes: ['postsCount'],
      });
      
      const totalPosts = tagStats.reduce((sum, tag) => sum + tag.postsCount, 0);
      const avgPostsPerTag = activeTags > 0 ? totalPosts / activeTags : 0;

      const analytics = {
        totalTags,
        activeTags,
        popularTags,
        trendingTags,
        recentTags,
        avgPostsPerTag: Math.round(avgPostsPerTag * 100) / 100,
      };

      logger.info('TagService: Tag analytics retrieved successfully', { analytics });
      return analytics;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('TagService: Get tag analytics failed', { error: errorMessage });
      throw error;
    }
  }
}

export default TagService;