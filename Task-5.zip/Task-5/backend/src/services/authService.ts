import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { User } from '../models/User';
import { logger } from '../utils/logger';

// JWT configuration
const JWT_SECRET = process.env.JWT_SECRET || 'fallback-secret-key-for-development';
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'fallback-refresh-secret-key-for-development';
const JWT_EXPIRY = process.env.JWT_EXPIRY || '15m';
const JWT_REFRESH_EXPIRY = process.env.JWT_REFRESH_EXPIRY || '7d';

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterData {
  email: string;
  username: string;
  password: string;
  firstName: string;
  lastName: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  user: {
    id: string;
    email: string;
    username: string;
    firstName: string;
    lastName: string;
    profileImageUrl?: string;
  };
}

export interface RefreshTokenData {
  userId: string;
  email: string;
  type: 'refresh';
}

export interface AccessTokenData {
  userId: string;
  email: string;
  username: string;
  type: 'access';
}

export class AuthService {
  private static saltRounds = 12;

  /**
   * Register a new user
   */
  public static async register(userData: RegisterData): Promise<AuthTokens> {
    try {
      logger.info('AuthService: Registering new user', { email: userData.email, username: userData.username });

      // Check if user with email already exists
      const existingUserByEmail = await User.findByEmail(userData.email);
      if (existingUserByEmail) {
        throw new Error('User with this email already exists');
      }

      // Check if username is available
      const isUsernameAvailable = await User.isUsernameAvailable(userData.username);
      if (!isUsernameAvailable) {
        throw new Error('Username is already taken');
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, this.saltRounds);

      // Create user
      const user = await User.create({
        email: userData.email.toLowerCase().trim(),
        username: userData.username.toLowerCase().trim(),
        passwordHash: hashedPassword,
        firstName: userData.firstName.trim(),
        lastName: userData.lastName.trim(),
      });

      logger.info('AuthService: User registered successfully', { userId: user.id, email: user.email });

      // Generate tokens
      const tokens = await this.generateAuthTokens(user);
      return tokens;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('AuthService: Registration failed', { error: errorMessage, email: userData.email });
      throw error;
    }
  }

  /**
   * Login user with email and password
   */
  public static async login(credentials: LoginCredentials): Promise<AuthTokens> {
    try {
      logger.info('AuthService: User login attempt', { email: credentials.email });

      // Find user by email
      const user = await User.findByEmail(credentials.email);
      if (!user) {
        throw new Error('Invalid email or password');
      }

      // Check if user is not deleted
      if (user.isDeleted) {
        throw new Error('Account has been deactivated');
      }

      // Verify password
      const isPasswordValid = await this.verifyPassword(credentials.password, user.passwordHash);
      if (!isPasswordValid) {
        throw new Error('Invalid email or password');
      }

      // Update last login
      await user.updateLastLogin();

      logger.info('AuthService: User logged in successfully', { userId: user.id, email: user.email });

      // Generate tokens
      const tokens = await this.generateAuthTokens(user);
      return tokens;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('AuthService: Login failed', { error: errorMessage, email: credentials.email });
      throw error;
    }
  }

  /**
   * Refresh access token using refresh token
   */
  public static async refreshToken(refreshToken: string): Promise<{ accessToken: string }> {
    try {
      logger.info('AuthService: Refreshing access token');

      // Verify refresh token
      const decoded = jwt.verify(refreshToken, JWT_REFRESH_SECRET) as RefreshTokenData;
      
      if (decoded.type !== 'refresh') {
        throw new Error('Invalid token type');
      }

      // Find user
      const user = await User.findByPk(decoded.userId);
      if (!user || user.isDeleted) {
        throw new Error('User not found or deactivated');
      }

      // Generate new access token
      const accessToken = this.generateAccessToken(user);

      logger.info('AuthService: Access token refreshed successfully', { userId: user.id });

      return { accessToken };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('AuthService: Token refresh failed', { error: errorMessage });
      throw new Error('Invalid or expired refresh token');
    }
  }

  /**
   * Validate access token and return user data
   */
  public static async validateToken(token: string): Promise<User> {
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as AccessTokenData;
      
      if (decoded.type !== 'access') {
        throw new Error('Invalid token type');
      }

      // Find user
      const user = await User.findByPk(decoded.userId);
      if (!user || user.isDeleted) {
        throw new Error('User not found or deactivated');
      }

      return user;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('AuthService: Token validation failed', { error: errorMessage });
      throw new Error('Invalid or expired token');
    }
  }

  /**
   * Change user password
   */
  public static async changePassword(
    userId: string,
    currentPassword: string,
    newPassword: string
  ): Promise<void> {
    try {
      logger.info('AuthService: Changing password', { userId });

      // Find user
      const user = await User.findByPk(userId);
      if (!user || user.isDeleted) {
        throw new Error('User not found');
      }

      // Verify current password
      const isCurrentPasswordValid = await this.verifyPassword(currentPassword, user.passwordHash);
      if (!isCurrentPasswordValid) {
        throw new Error('Current password is incorrect');
      }

      // Validate new password strength
      this.validatePasswordStrength(newPassword);

      // Hash new password
      const hashedNewPassword = await bcrypt.hash(newPassword, this.saltRounds);

      // Update password
      await user.update({ passwordHash: hashedNewPassword });

      logger.info('AuthService: Password changed successfully', { userId });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('AuthService: Password change failed', { error: errorMessage, userId });
      throw error;
    }
  }

  /**
   * Reset password with token (simplified - in production would use email verification)
   */
  public static async resetPassword(email: string, newPassword: string): Promise<void> {
    try {
      logger.info('AuthService: Resetting password', { email });

      // Find user by email
      const user = await User.findByEmail(email);
      if (!user || user.isDeleted) {
        throw new Error('User not found');
      }

      // Validate new password strength
      this.validatePasswordStrength(newPassword);

      // Hash new password
      const hashedNewPassword = await bcrypt.hash(newPassword, this.saltRounds);

      // Update password
      await user.update({ passwordHash: hashedNewPassword });

      logger.info('AuthService: Password reset successfully', { userId: user.id, email });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('AuthService: Password reset failed', { error: errorMessage, email });
      throw error;
    }
  }

  /**
   * Logout user (in a real app, this would invalidate tokens)
   */
  public static async logout(userId: string): Promise<void> {
    try {
      logger.info('AuthService: User logout', { userId });
      
      // In a production app, you would:
      // 1. Add tokens to a blacklist
      // 2. Update user's token version
      // 3. Clear refresh tokens from database
      
      // For now, we'll just log the logout
      logger.info('AuthService: User logged out successfully', { userId });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('AuthService: Logout failed', { error: errorMessage, userId });
      throw error;
    }
  }

  /**
   * Generate both access and refresh tokens
   */
  private static async generateAuthTokens(user: User): Promise<AuthTokens> {
    const accessToken = this.generateAccessToken(user);
    const refreshToken = this.generateRefreshToken(user);

    return {
      accessToken,
      refreshToken,
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        firstName: user.firstName || '',
        lastName: user.lastName || '',
        ...(user.profileImageUrl && { profileImageUrl: user.profileImageUrl }),
      },
    };
  }

  /**
   * Generate access token
   */
  private static generateAccessToken(user: User): string {
    const payload: AccessTokenData = {
      userId: user.id,
      email: user.email,
      username: user.username,
      type: 'access',
    };

    return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRY } as jwt.SignOptions);
  }

  /**
   * Generate refresh token
   */
  private static generateRefreshToken(user: User): string {
    const payload: RefreshTokenData = {
      userId: user.id,
      email: user.email,
      type: 'refresh',
    };

    return jwt.sign(payload, JWT_REFRESH_SECRET, { expiresIn: JWT_REFRESH_EXPIRY } as jwt.SignOptions);
  }

  /**
   * Verify password against hash
   */
  private static async verifyPassword(password: string, hash: string): Promise<boolean> {
    return bcrypt.compare(password, hash);
  }

  /**
   * Validate password strength
   */
  private static validatePasswordStrength(password: string): void {
    if (password.length < 8) {
      throw new Error('Password must be at least 8 characters long');
    }

    if (!/(?=.*[a-z])/.test(password)) {
      throw new Error('Password must contain at least one lowercase letter');
    }

    if (!/(?=.*[A-Z])/.test(password)) {
      throw new Error('Password must contain at least one uppercase letter');
    }

    if (!/(?=.*\d)/.test(password)) {
      throw new Error('Password must contain at least one number');
    }

    if (!/(?=.*[@$!%*?&])/.test(password)) {
      throw new Error('Password must contain at least one special character (@$!%*?&)');
    }
  }

  /**
   * Generate secure random token for password reset, email verification, etc.
   */
  public static generateSecureToken(): string {
    return require('crypto').randomBytes(32).toString('hex');
  }

  /**
   * Verify if user has permission to access resource
   */
  public static async verifyUserPermission(userId: string, resourceUserId: string): Promise<boolean> {
    // Users can access their own resources
    if (userId === resourceUserId) {
      return true;
    }

    // In a more complex system, you might check for admin roles, friendship status, etc.
    return false;
  }

  /**
   * Check if user account is in good standing
   */
  public static async checkAccountStatus(userId: string): Promise<{
    isActive: boolean;
    isSuspended: boolean;
    canPost: boolean;
    canComment: boolean;
    canLike: boolean;
  }> {
    try {
      const user = await User.findByPk(userId);
      if (!user) {
        throw new Error('User not found');
      }

      // In a real application, you would check various flags and rules
      const isActive = !user.isDeleted;
      const isSuspended = false; // Would be a field in User model
      
      return {
        isActive,
        isSuspended,
        canPost: isActive && !isSuspended,
        canComment: isActive && !isSuspended,
        canLike: isActive && !isSuspended,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      logger.error('AuthService: Account status check failed', { error: errorMessage, userId });
      throw error;
    }
  }
}

export default AuthService;