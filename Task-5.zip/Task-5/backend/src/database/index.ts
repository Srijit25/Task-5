import { testConnection, initializeDatabase } from './connection';
import { logger } from '../utils/logger';

/**
 * Initialize the complete database setup
 */
export const initializeDB = async (): Promise<void> => {
  try {
    logger.info('Starting Supabase initialization...');

    // Initialize Supabase client
    await initializeDatabase();

    // Test database connection
    await testConnection();

    logger.info('Supabase initialization completed successfully');
  } catch (error) {
    logger.error('Supabase initialization failed:', error);
    throw error;
  }
};

/**
 * Test database connection
 */
export const testDB = async (): Promise<void> => {
  try {
    await testConnection();
    logger.info('Supabase connection test successful');
  } catch (error) {
    logger.error('Supabase connection test failed:', error);
    throw error;
  }
};

export { testConnection, initializeDatabase };
export default initializeDB;