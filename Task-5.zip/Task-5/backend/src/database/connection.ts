import { initializeSupabase, testSupabaseConnection, getSupabaseClient, getSupabaseAdmin } from '../config/supabase';
import { logger } from '../utils/logger';

// Initialize Supabase connection
export const initializeDatabase = async (): Promise<void> => {
  try {
    initializeSupabase();
    logger.info('Supabase initialized successfully');
  } catch (error) {
    logger.error('Supabase initialization failed:', error);
    throw error;
  }
};

// Test database connection
export const testConnection = async (): Promise<void> => {
  try {
    await testSupabaseConnection();
    logger.info('Supabase connection test successful');
  } catch (error) {
    logger.error('Supabase connection test failed:', error);
    throw error;
  }
};

// Close database connection (Supabase handles this automatically)
export const closeConnection = async (): Promise<void> => {
  try {
    // Supabase client handles connection cleanup automatically
    logger.info('Supabase connection cleanup completed');
  } catch (error) {
    logger.error('Error during Supabase cleanup:', error);
    throw error;
  }
};

// Export Supabase clients for backward compatibility
export const supabaseClient = getSupabaseClient;
export const supabaseAdmin = getSupabaseAdmin;

export default {
  initializeDatabase,
  testConnection,
  closeConnection,
  supabaseClient,
  supabaseAdmin,
};