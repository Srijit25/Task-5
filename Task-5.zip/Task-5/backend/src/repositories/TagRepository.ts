import { BaseRepository } from './BaseRepository';
import { TagEntity, CreateTagData, UpdateTagData } from '../types/database';
import { getSupabaseAdmin } from '../config/supabase';
import { logger } from '../utils/logger';

const supabase = getSupabaseAdmin();

export class TagRepository extends BaseRepository<TagEntity> {
  protected override tableName = 'tags';

  constructor() {
    super('tags');
  }

  /**
   * Create a new tag
   */
  async createTag(data: CreateTagData): Promise<TagEntity> {
    try {
      const { data: tag, error } = await (supabase as any)
        .from(this.tableName)
        .insert(data)
        .select()
        .single();

      if (error) throw error;
      return tag;
    } catch (error) {
      logger.error('Error creating tag:', error);
      throw error;
    }
  }

  /**
   * Get tag by ID
   */
  async getTagById(id: string): Promise<TagEntity | null> {
    try {
      const { data, error } = await supabase
        .from(this.tableName)
        .select('*')
        .eq('id', id)
        .single();

      if (error) {
        if (error.code === 'PGRST116') return null;
        throw error;
      }

      return data;
    } catch (error) {
      logger.error(`Error getting tag by ID ${id}:`, error);
      throw error;
    }
  }

  /**
   * Get tag by name
   */
  async getTagByName(name: string): Promise<TagEntity | null> {
    try {
      const { data, error } = await supabase
        .from(this.tableName)
        .select('*')
        .eq('name', name)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      return data || null;
    } catch (error) {
      logger.error(`Error getting tag by name ${name}:`, error);
      throw error;
    }
  }

  /**
   * Get all tags with pagination
   */
  async getTags(options: {
    limit?: number;
    offset?: number;
    sortBy?: 'name' | 'post_count' | 'created_at';
    sortOrder?: 'asc' | 'desc';
    search?: string;
  } = {}): Promise<{ data: TagEntity[]; total: number }> {
    try {
      const { limit = 20, offset = 0, sortBy = 'post_count', sortOrder = 'desc', search } = options;

      let query = supabase
        .from(this.tableName)
        .select('*', { count: 'exact' });

      if (search) {
        query = query.ilike('name', `%${search}%`);
      }

      query = query
        .order(sortBy, { ascending: sortOrder === 'asc' })
        .range(offset, offset + limit - 1);

      const { data, error, count } = await query;

      if (error) throw error;

      return {
        data: data || [],
        total: count || 0,
      };
    } catch (error) {
      logger.error('Error getting tags:', error);
      throw error;
    }
  }

  /**
   * Update tag
   */
  async updateTag(id: string, data: UpdateTagData): Promise<TagEntity> {
    try {
      const { data: tag, error } = await (supabase as any)
        .from(this.tableName)
        .update(data)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return tag;
    } catch (error) {
      logger.error(`Error updating tag ${id}:`, error);
      throw error;
    }
  }

  /**
   * Delete tag
   */
  async deleteTag(id: string): Promise<void> {
    try {
      const { error } = await supabase
        .from(this.tableName)
        .delete()
        .eq('id', id);

      if (error) throw error;
    } catch (error) {
      logger.error(`Error deleting tag ${id}:`, error);
      throw error;
    }
  }

  /**
   * Search tags
   */
  async searchTags(query: string, limit = 10): Promise<TagEntity[]> {
    try {
      const { data, error } = await supabase
        .from(this.tableName)
        .select('*')
        .ilike('name', `%${query}%`)
        .order('post_count', { ascending: false })
        .limit(limit);

      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error(`Error searching tags with query "${query}":`, error);
      throw error;
    }
  }

  /**
   * Get popular tags
   */
  async getPopularTags(limit = 20): Promise<TagEntity[]> {
    try {
      const { data, error } = await supabase
        .from(this.tableName)
        .select('*')
        .gt('post_count', 0)
        .order('post_count', { ascending: false })
        .limit(limit);

      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error('Error getting popular tags:', error);
      throw error;
    }
  }

  /**
   * Increment post count
   */
  async incrementPostCount(id: string): Promise<void> {
    try {
      const { error } = await (supabase as any).rpc('increment_tag_posts', {
        tag_id: id,
      });

      if (error) throw error;
    } catch (error) {
      logger.error(`Error incrementing post count for tag ${id}:`, error);
      throw error;
    }
  }

  /**
   * Decrement post count
   */
  async decrementPostCount(id: string): Promise<void> {
    try {
      const { error } = await (supabase as any).rpc('decrement_tag_posts', {
        tag_id: id,
      });

      if (error) throw error;
    } catch (error) {
      logger.error(`Error decrementing post count for tag ${id}:`, error);
      throw error;
    }
  }

  /**
   * Check if tag name exists
   */
  async tagNameExists(name: string, excludeTagId?: string): Promise<boolean> {
    try {
      let query = supabase
        .from(this.tableName)
        .select('id')
        .eq('name', name);

      if (excludeTagId) {
        query = query.neq('id', excludeTagId);
      }

      const { data, error } = await query.single();

      if (error && error.code !== 'PGRST116') throw error;
      return !!data;
    } catch (error) {
      logger.error(`Error checking tag name existence for "${name}":`, error);
      throw error;
    }
  }
}