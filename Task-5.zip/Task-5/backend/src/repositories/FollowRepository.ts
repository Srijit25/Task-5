import { BaseRepository } from './BaseRepository';
import { FollowEntity, CreateFollowData } from '../types/database';
import { getSupabaseAdmin } from '../config/supabase';
import { logger } from '../utils/logger';

const supabase = getSupabaseAdmin();

export class FollowRepository extends BaseRepository<FollowEntity> {
  protected override tableName = 'follows';

  constructor() {
    super('follows');
  }

  /**
   * Follow a user
   */
  async followUser(followerId: string, followedId: string): Promise<FollowEntity> {
    try {
      if (followerId === followedId) {
        throw new Error('Cannot follow yourself');
      }

      // Check if already following
      const existingFollow = await this.getFollow(followerId, followedId);
      if (existingFollow) {
        return existingFollow;
      }

      const data: CreateFollowData = {
        follower_id: followerId,
        followed_id: followedId,
      };

      const { data: follow, error } = await (supabase as any)
        .from(this.tableName)
        .insert(data)
        .select()
        .single();

      if (error) throw error;
      return follow;
    } catch (error) {
      logger.error(`Error following user ${followedId} by ${followerId}:`, error);
      throw error;
    }
  }

  /**
   * Unfollow a user
   */
  async unfollowUser(followerId: string, followedId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from(this.tableName)
        .delete()
        .eq('follower_id', followerId)
        .eq('followed_id', followedId);

      if (error) throw error;
    } catch (error) {
      logger.error(`Error unfollowing user ${followedId} by ${followerId}:`, error);
      throw error;
    }
  }

  /**
   * Get follow relationship
   */
  async getFollow(followerId: string, followedId: string): Promise<FollowEntity | null> {
    try {
      const { data, error } = await supabase
        .from(this.tableName)
        .select('*')
        .eq('follower_id', followerId)
        .eq('followed_id', followedId)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      return data || null;
    } catch (error) {
      logger.error(`Error getting follow relationship ${followerId} -> ${followedId}:`, error);
      throw error;
    }
  }

  /**
   * Check if user is following another user
   */
  async isFollowing(followerId: string, followedId: string): Promise<boolean> {
    try {
      const follow = await this.getFollow(followerId, followedId);
      return !!follow;
    } catch (error) {
      logger.error(`Error checking if ${followerId} is following ${followedId}:`, error);
      throw error;
    }
  }

  /**
   * Get followers of a user
   */
  async getFollowers(
    userId: string,
    options: { limit?: number; offset?: number } = {}
  ): Promise<{ data: FollowEntity[]; total: number }> {
    try {
      const { limit = 20, offset = 0 } = options;

      const { data, error, count } = await supabase
        .from(this.tableName)
        .select(`
          *,
          follower:follower_id(
            id,
            username,
            display_name,
            profile_picture,
            verified,
            bio
          )
        `, { count: 'exact' })
        .eq('followed_id', userId)
        .order('created_at', { ascending: false })
        .range(offset, offset + limit - 1);

      if (error) throw error;

      return {
        data: data || [],
        total: count || 0,
      };
    } catch (error) {
      logger.error(`Error getting followers for user ${userId}:`, error);
      throw error;
    }
  }

  /**
   * Get users being followed by a user
   */
  async getFollowing(
    userId: string,
    options: { limit?: number; offset?: number } = {}
  ): Promise<{ data: FollowEntity[]; total: number }> {
    try {
      const { limit = 20, offset = 0 } = options;

      const { data, error, count } = await supabase
        .from(this.tableName)
        .select(`
          *,
          followed:followed_id(
            id,
            username,
            display_name,
            profile_picture,
            verified,
            bio
          )
        `, { count: 'exact' })
        .eq('follower_id', userId)
        .order('created_at', { ascending: false })
        .range(offset, offset + limit - 1);

      if (error) throw error;

      return {
        data: data || [],
        total: count || 0,
      };
    } catch (error) {
      logger.error(`Error getting following for user ${userId}:`, error);
      throw error;
    }
  }

  /**
   * Get follower count for a user
   */
  async getFollowerCount(userId: string): Promise<number> {
    try {
      const { count, error } = await supabase
        .from(this.tableName)
        .select('*', { count: 'exact', head: true })
        .eq('followed_id', userId);

      if (error) throw error;
      return count || 0;
    } catch (error) {
      logger.error(`Error getting follower count for user ${userId}:`, error);
      throw error;
    }
  }

  /**
   * Get following count for a user
   */
  async getFollowingCount(userId: string): Promise<number> {
    try {
      const { count, error } = await supabase
        .from(this.tableName)
        .select('*', { count: 'exact', head: true })
        .eq('follower_id', userId);

      if (error) throw error;
      return count || 0;
    } catch (error) {
      logger.error(`Error getting following count for user ${userId}:`, error);
      throw error;
    }
  }

  /**
   * Get follow statistics for a user
   */
  async getFollowStats(userId: string): Promise<{
    followerCount: number;
    followingCount: number;
  }> {
    try {
      const [followerCount, followingCount] = await Promise.all([
        this.getFollowerCount(userId),
        this.getFollowingCount(userId),
      ]);

      return {
        followerCount,
        followingCount,
      };
    } catch (error) {
      logger.error(`Error getting follow stats for user ${userId}:`, error);
      throw error;
    }
  }

  /**
   * Get mutual followers between two users
   */
  async getMutualFollowing(userId1: string, userId2: string): Promise<string[]> {
    try {
      // First get users that userId2 follows
      const { data: user2Following, error: error1 } = await (supabase as any)
        .from(this.tableName)
        .select('followed_id')
        .eq('follower_id', userId2);

      if (error1) throw error1;

      const user2FollowingIds = user2Following?.map((item: any) => item.followed_id) || [];

      if (user2FollowingIds.length === 0) return [];

      // Then get users that userId1 follows and are in the above list
      const { data, error } = await (supabase as any)
        .from(this.tableName)
        .select('followed_id')
        .eq('follower_id', userId1)
        .in('followed_id', user2FollowingIds);

      if (error) throw error;
      return data?.map((item: any) => item.followed_id) || [];
    } catch (error) {
      logger.error(`Error getting mutual following for users ${userId1} and ${userId2}:`, error);
      throw error;
    }
  }

  /**
   * Toggle follow status
   */
  async toggleFollow(followerId: string, followedId: string): Promise<{
    isFollowing: boolean;
    follow?: FollowEntity;
  }> {
    try {
      const existingFollow = await this.getFollow(followerId, followedId);

      if (existingFollow) {
        await this.unfollowUser(followerId, followedId);
        return { isFollowing: false };
      } else {
        const follow = await this.followUser(followerId, followedId);
        return { isFollowing: true, follow };
      }
    } catch (error) {
      logger.error(`Error toggling follow status ${followerId} -> ${followedId}:`, error);
      throw error;
    }
  }

  /**
   * Get follow suggestions for a user
   */
  async getFollowSuggestions(
    userId: string,
    limit = 10
  ): Promise<string[]> {
    try {
      // Get users followed by people this user follows
      const { data, error } = await (supabase as any).rpc('get_follow_suggestions', {
        user_id: userId,
        suggestion_limit: limit,
      });

      if (error) throw error;
      return data || [];
    } catch (error) {
      logger.error(`Error getting follow suggestions for user ${userId}:`, error);
      throw error;
    }
  }

  /**
   * Bulk follow check
   */
  async bulkFollowCheck(
    followerId: string,
    userIds: string[]
  ): Promise<Record<string, boolean>> {
    try {
      const { data, error } = await supabase
        .from(this.tableName)
        .select('followed_id')
        .eq('follower_id', followerId)
        .in('followed_id', userIds);

      if (error) throw error;

      const followingSet = new Set(data?.map((item: any) => item.followed_id) || []);
      
      return userIds.reduce((acc, userId) => {
        acc[userId] = followingSet.has(userId);
        return acc;
      }, {} as Record<string, boolean>);
    } catch (error) {
      logger.error(`Error performing bulk follow check for user ${followerId}:`, error);
      throw error;
    }
  }

  /**
   * Remove follower (block)
   */
  async removeFollower(userId: string, followerId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from(this.tableName)
        .delete()
        .eq('follower_id', followerId)
        .eq('followed_id', userId);

      if (error) throw error;
    } catch (error) {
      logger.error(`Error removing follower ${followerId} from user ${userId}:`, error);
      throw error;
    }
  }

  /**
   * Find all follows with pagination (for model compatibility)
   */
  async findAll(options: { limit?: number; offset?: number } = {}): Promise<{ data: FollowEntity[]; total: number }> {
    try {
      const { limit = 20, offset = 0 } = options;

      const { data, error, count } = await supabase
        .from(this.tableName)
        .select('*', { count: 'exact' })
        .order('created_at', { ascending: false })
        .range(offset, offset + limit - 1);

      if (error) throw error;

      return {
        data: data || [],
        total: count || 0,
      };
    } catch (error) {
      logger.error('Error finding all follows:', error);
      throw error;
    }
  }
}