import { BaseRepository } from './BaseRepository';
import { CommentEntity, CreateCommentData, UpdateCommentData, CommentFilters } from '../types/database';
import { getSupabaseAdmin } from '../config/supabase';
import { logger } from '../utils/logger';

const supabase = getSupabaseAdmin();

export class CommentRepository extends BaseRepository<CommentEntity> {
  protected override tableName = 'comments';

  constructor() {
    super('comments');
  }

  /**
   * Create a new comment
   */
  async createComment(data: CreateCommentData): Promise<CommentEntity> {
    try {
      const { data: comment, error } = await (supabase as any)
        .from(this.tableName)
        .insert(data)
        .select()
        .single();

      if (error) throw error;
      return comment;
    } catch (error) {
      logger.error('Error creating comment:', error);
      throw error;
    }
  }

  /**
   * Get comment by ID
   */
  async getCommentById(id: string): Promise<CommentEntity | null> {
    try {
      const { data, error } = await supabase
        .from(this.tableName)
        .select('*')
        .eq('id', id)
        .eq('is_deleted', false)
        .single();

      if (error) {
        if (error.code === 'PGRST116') return null;
        throw error;
      }

      return data;
    } catch (error) {
      logger.error(`Error getting comment ${id}:`, error);
      throw error;
    }
  }

  /**
   * Update comment
   */
  async updateComment(id: string, data: UpdateCommentData, useAdmin = false): Promise<CommentEntity> {
    try {
      const client = useAdmin ? this.adminClient : this.supabase;
      
      const { data: updated, error } = await (client as any)
        .from(this.tableName)
        .update({
          ...data,
          updated_at: new Date().toISOString(),
        })
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return updated;
    } catch (error) {
      logger.error(`Error updating comment ${id}:`, error);
      throw error;
    }
  }

  /**
   * Get comments for a post
   */
  async getCommentsByPost(
    postId: string,
    options: {
      limit?: number;
      offset?: number;
      includeUser?: boolean;
    } = {}
  ): Promise<{ data: CommentEntity[]; total: number }> {
    try {
      const {
        limit = 20,
        offset = 0,
        includeUser = true
      } = options;

      let query = supabase
        .from(this.tableName)
        .select(includeUser ? `
          *,
          user:user_id (
            id,
            username,
            first_name,
            last_name,
            profile_picture_url
          )
        ` : '*', { count: 'exact' })
        .eq('post_id', postId)
        .eq('is_deleted', false)
        .order('created_at', { ascending: true })
        .range(offset, offset + limit - 1);

      const { data, error, count } = await query;

      if (error) throw error;

      return {
        data: data || [],
        total: count || 0
      };
    } catch (error) {
      logger.error(`Error getting comments for post ${postId}:`, error);
      throw error;
    }
  }

  /**
   * Increment comment like count
   */
  async incrementLikeCount(commentId: string): Promise<void> {
    try {
      const { error } = await (supabase as any)
        .rpc('increment_comment_like_count', { comment_id: commentId });

      if (error) throw error;
    } catch (error) {
      logger.error(`Error incrementing like count for comment ${commentId}:`, error);
      throw error;
    }
  }

  /**
   * Decrement comment like count
   */
  async decrementLikeCount(commentId: string): Promise<void> {
    try {
      const { error } = await (supabase as any)
        .rpc('decrement_comment_like_count', { comment_id: commentId });

      if (error) throw error;
    } catch (error) {
      logger.error(`Error decrementing like count for comment ${commentId}:`, error);
      throw error;
    }
  }
}