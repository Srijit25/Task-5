import { BaseRepository } from './BaseRepository';
import { 
  UserEntity, 
  CreateUserData, 
  UpdateUserData, 
  UserFilters,
  PaginatedResponse
} from '../types/database';
import { logger } from '../utils/logger';

export class UserRepository extends BaseRepository<UserEntity> {
  constructor() {
    super('users');
  }

  /**
   * Create a new user
   */
  async createUser(userData: CreateUserData): Promise<UserEntity> {
    try {
      const user = await this.create(userData, true); // Use admin client for user creation
      return user;
    } catch (error) {
      logger.error('Error creating user:', error);
      throw error;
    }
  }

  /**
   * Get user by ID
   */
  async getUserById(id: string): Promise<UserEntity | null> {
    try {
      return await this.findById(id);
    } catch (error) {
      logger.error(`Error getting user by ID ${id}:`, error);
      throw error;
    }
  }

  /**
   * Get user by auth user ID
   */
  async getUserByAuthId(authUserId: string): Promise<UserEntity | null> {
    try {
      const { data, error } = await this.supabase
        .from(this.tableName)
        .select('*')
        .eq('auth_user_id', authUserId)
        .eq('is_deleted', false)
        .single();

      if (error) {
        if (error.code === 'PGRST116') {
          return null; // Not found
        }
        throw error;
      }

      return data;
    } catch (error) {
      logger.error(`Error getting user by auth ID ${authUserId}:`, error);
      throw error;
    }
  }

  /**
   * Get user by username
   */
  async getUserByUsername(username: string): Promise<UserEntity | null> {
    try {
      const { data, error } = await this.supabase
        .from(this.tableName)
        .select('*')
        .eq('username', username)
        .eq('is_deleted', false)
        .single();

      if (error) {
        if (error.code === 'PGRST116') {
          return null; // Not found
        }
        throw error;
      }

      return data;
    } catch (error) {
      logger.error(`Error getting user by username ${username}:`, error);
      throw error;
    }
  }

  /**
   * Get user by email
   */
  async getUserByEmail(email: string): Promise<UserEntity | null> {
    try {
      const { data, error } = await this.supabase
        .from(this.tableName)
        .select('*')
        .eq('email', email)
        .eq('is_deleted', false)
        .single();

      if (error) {
        if (error.code === 'PGRST116') {
          return null; // Not found
        }
        throw error;
      }

      return data;
    } catch (error) {
      logger.error(`Error getting user by email ${email}:`, error);
      throw error;
    }
  }

  /**
   * Update user
   */
  async updateUser(id: string, updateData: UpdateUserData): Promise<UserEntity> {
    try {
      return await this.update(id, updateData);
    } catch (error) {
      logger.error(`Error updating user ${id}:`, error);
      throw error;
    }
  }

  /**
   * Soft delete user
   */
  async deleteUser(id: string): Promise<void> {
    try {
      await this.softDelete(id);
    } catch (error) {
      logger.error(`Error deleting user ${id}:`, error);
      throw error;
    }
  }

  /**
   * Get users with pagination and filters
   */
  async getUsers(filters: UserFilters = {}): Promise<PaginatedResponse<UserEntity>> {
    try {
      const { 
        page = 1, 
        limit = 20, 
        username, 
        email, 
        isActive, 
        isVerified,
        ...sortOptions 
      } = filters;

      const offset = (page - 1) * limit;

      // Build filters
      const queryFilters: Record<string, any> = {
        is_deleted: false,
      };

      if (username) {
        queryFilters.username = username;
      }
      if (email) {
        queryFilters.email = email;
      }
      if (isActive !== undefined) {
        queryFilters.is_active = isActive;
      }
      if (isVerified !== undefined) {
        queryFilters.is_verified = isVerified;
      }

      // Get users
      const users = await this.findWithFilters(
        queryFilters,
        '*',
        { ...sortOptions, limit, offset }
      );

      // Get total count
      const total = await this.getTotalCount(this.tableName, queryFilters);

      return this.buildPaginatedResponse(users, total, page, limit);
    } catch (error) {
      logger.error('Error getting users:', error);
      throw error;
    }
  }

  /**
   * Search users by username or name
   */
  async searchUsers(query: string, options: { limit?: number; offset?: number } = {}): Promise<UserEntity[]> {
    try {
      const { limit = 20, offset = 0 } = options;

      const { data, error } = await this.supabase
        .from(this.tableName)
        .select('*')
        .or(`username.ilike.%${query}%,first_name.ilike.%${query}%,last_name.ilike.%${query}%`)
        .eq('is_deleted', false)
        .eq('is_active', true)
        .order('username')
        .range(offset, offset + limit - 1);

      if (error) {
        throw error;
      }

      return data || [];
    } catch (error) {
      logger.error(`Error searching users with query "${query}":`, error);
      throw error;
    }
  }

  /**
   * Check if username exists
   */
  async usernameExists(username: string, excludeUserId?: string): Promise<boolean> {
    try {
      let query = this.supabase
        .from(this.tableName)
        .select('id', { head: true, count: 'exact' })
        .eq('username', username)
        .eq('is_deleted', false);

      if (excludeUserId) {
        query = query.neq('id', excludeUserId);
      }

      const { count, error } = await query;

      if (error) {
        throw error;
      }

      return (count || 0) > 0;
    } catch (error) {
      logger.error(`Error checking username existence for "${username}":`, error);
      throw error;
    }
  }

  /**
   * Check if email exists
   */
  async emailExists(email: string, excludeUserId?: string): Promise<boolean> {
    try {
      let query = this.supabase
        .from(this.tableName)
        .select('id', { head: true, count: 'exact' })
        .eq('email', email)
        .eq('is_deleted', false);

      if (excludeUserId) {
        query = query.neq('id', excludeUserId);
      }

      const { count, error } = await query;

      if (error) {
        throw error;
      }

      return (count || 0) > 0;
    } catch (error) {
      logger.error(`Error checking email existence for "${email}":`, error);
      throw error;
    }
  }

  /**
   * Get user stats
   */
  async getUserStats(userId: string): Promise<{
    postsCount: number;
    followersCount: number;
    followingCount: number;
  }> {
    try {
      // Get posts count
      const { count: postsCount, error: postsError } = await this.supabase
        .from('posts')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId)
        .eq('is_deleted', false);

      if (postsError) throw postsError;

      // Get followers count
      const { count: followersCount, error: followersError } = await this.supabase
        .from('follows')
        .select('*', { count: 'exact', head: true })
        .eq('following_id', userId);

      if (followersError) throw followersError;

      // Get following count
      const { count: followingCount, error: followingError } = await this.supabase
        .from('follows')
        .select('*', { count: 'exact', head: true })
        .eq('follower_id', userId);

      if (followingError) throw followingError;

      return {
        postsCount: postsCount || 0,
        followersCount: followersCount || 0,
        followingCount: followingCount || 0,
      };
    } catch (error) {
      logger.error(`Error getting user stats for ${userId}:`, error);
      throw error;
    }
  }

  /**
   * Update user last active
   */
  async updateLastActive(userId: string): Promise<void> {
    try {
      const { error } = await (this.supabase as any)
        .from(this.tableName)
        .update({ updated_at: new Date().toISOString() })
        .eq('id', userId);

      if (error) {
        throw error;
      }
    } catch (error) {
      logger.error(`Error updating last active for user ${userId}:`, error);
      // Don't throw error for this operation as it's not critical
    }
  }
}