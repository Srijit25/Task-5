import { BaseRepository } from './BaseRepository';
import { LikeEntity, CreateLikeData } from '../types/database';
import { getSupabaseAdmin } from '../config/supabase';
import { logger } from '../utils/logger';

const supabase = getSupabaseAdmin();

export class LikeRepository extends BaseRepository<LikeEntity> {
  protected override tableName = 'likes';

  constructor() {
    super('likes');
  }

  /**
   * Create a new like
   */
  async createLike(data: CreateLikeData): Promise<LikeEntity> {
    try {
      const { data: like, error } = await (supabase as any)
        .from(this.tableName)
        .insert(data)
        .select()
        .single();

      if (error) throw error;
      return like;
    } catch (error) {
      logger.error('Error creating like:', error);
      throw error;
    }
  }

  /**
   * Get like by ID
   */
  async getLikeById(id: string): Promise<LikeEntity | null> {
    try {
      const { data, error } = await supabase
        .from(this.tableName)
        .select('*')
        .eq('id', id)
        .single();

      if (error) {
        if (error.code === 'PGRST116') return null; // Not found
        throw error;
      }

      return data;
    } catch (error) {
      logger.error(`Error getting like by ID ${id}:`, error);
      throw error;
    }
  }

  /**
   * Check if user liked a post
   */
  async getUserPostLike(userId: string, postId: string): Promise<LikeEntity | null> {
    try {
      const { data, error } = await supabase
        .from(this.tableName)
        .select('*')
        .eq('user_id', userId)
        .eq('post_id', postId)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      return data || null;
    } catch (error) {
      logger.error(`Error getting user post like for user ${userId}, post ${postId}:`, error);
      throw error;
    }
  }

  /**
   * Check if user liked a comment
   */
  async getUserCommentLike(userId: string, commentId: string): Promise<LikeEntity | null> {
    try {
      const { data, error } = await supabase
        .from(this.tableName)
        .select('*')
        .eq('user_id', userId)
        .eq('comment_id', commentId)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      return data || null;
    } catch (error) {
      logger.error(`Error getting user comment like for user ${userId}, comment ${commentId}:`, error);
      throw error;
    }
  }

  /**
   * Get likes for a post
   */
  async getPostLikes(
    postId: string,
    options: {
      limit?: number;
      offset?: number;
      includeUser?: boolean;
    } = {}
  ): Promise<{ data: LikeEntity[]; total: number }> {
    try {
      const { limit = 20, offset = 0, includeUser = false } = options;

      let query = supabase
        .from(this.tableName)
        .select(
          includeUser ? `
            *,
            user:user_id (
              id,
              username,
              first_name,
              last_name,
              profile_picture_url,
              is_verified
            )
          ` : '*',
          { count: 'exact' }
        )
        .eq('post_id', postId);

      query = query
        .order('created_at', { ascending: false })
        .range(offset, offset + limit - 1);

      const { data, error, count } = await query;

      if (error) throw error;

      return {
        data: data || [],
        total: count || 0,
      };
    } catch (error) {
      logger.error(`Error getting likes for post ${postId}:`, error);
      throw error;
    }
  }

  /**
   * Get likes for a comment
   */
  async getCommentLikes(
    commentId: string,
    options: {
      limit?: number;
      offset?: number;
      includeUser?: boolean;
    } = {}
  ): Promise<{ data: LikeEntity[]; total: number }> {
    try {
      const { limit = 20, offset = 0, includeUser = false } = options;

      let query = supabase
        .from(this.tableName)
        .select(
          includeUser ? `
            *,
            user:user_id (
              id,
              username,
              first_name,
              last_name,
              profile_picture_url,
              is_verified
            )
          ` : '*',
          { count: 'exact' }
        )
        .eq('comment_id', commentId);

      query = query
        .order('created_at', { ascending: false })
        .range(offset, offset + limit - 1);

      const { data, error, count } = await query;

      if (error) throw error;

      return {
        data: data || [],
        total: count || 0,
      };
    } catch (error) {
      logger.error(`Error getting likes for comment ${commentId}:`, error);
      throw error;
    }
  }

  /**
   * Get likes by user
   */
  async getUserLikes(
    userId: string,
    options: {
      limit?: number;
      offset?: number;
      type?: 'posts' | 'comments' | 'all';
      includeTarget?: boolean;
    } = {}
  ): Promise<{ data: LikeEntity[]; total: number }> {
    try {
      const { limit = 20, offset = 0, type = 'all', includeTarget = false } = options;

      let query = supabase
        .from(this.tableName)
        .select(
          includeTarget ? `
            *,
            post:post_id (
              id,
              content,
              user_id,
              created_at
            ),
            comment:comment_id (
              id,
              content,
              user_id,
              post_id,
              created_at
            )
          ` : '*',
          { count: 'exact' }
        )
        .eq('user_id', userId);

      if (type === 'posts') {
        query = query.not('post_id', 'is', null);
      } else if (type === 'comments') {
        query = query.not('comment_id', 'is', null);
      }

      query = query
        .order('created_at', { ascending: false })
        .range(offset, offset + limit - 1);

      const { data, error, count } = await query;

      if (error) throw error;

      return {
        data: data || [],
        total: count || 0,
      };
    } catch (error) {
      logger.error(`Error getting likes for user ${userId}:`, error);
      throw error;
    }
  }

  /**
   * Delete like
   */
  async deleteLike(id: string): Promise<void> {
    try {
      const { error } = await supabase
        .from(this.tableName)
        .delete()
        .eq('id', id);

      if (error) throw error;
    } catch (error) {
      logger.error(`Error deleting like ${id}:`, error);
      throw error;
    }
  }

  /**
   * Delete like by user and target
   */
  async deleteLikeByTarget(userId: string, postId?: string, commentId?: string): Promise<void> {
    try {
      let query = supabase
        .from(this.tableName)
        .delete()
        .eq('user_id', userId);

      if (postId) {
        query = query.eq('post_id', postId);
      } else if (commentId) {
        query = query.eq('comment_id', commentId);
      } else {
        throw new Error('Either postId or commentId must be provided');
      }

      const { error } = await query;

      if (error) throw error;
    } catch (error) {
      logger.error(`Error deleting like by target for user ${userId}:`, error);
      throw error;
    }
  }

  /**
   * Toggle like (create if doesn't exist, delete if exists)
   */
  async toggleLike(userId: string, postId?: string, commentId?: string): Promise<{ liked: boolean; like?: LikeEntity }> {
    try {
      if (!postId && !commentId) {
        throw new Error('Either postId or commentId must be provided');
      }

      // Check if like exists
      let existingLike;
      if (postId) {
        existingLike = await this.getUserPostLike(userId, postId);
      } else if (commentId) {
        existingLike = await this.getUserCommentLike(userId, commentId);
      }

      if (existingLike) {
        // Unlike - remove the like
        await this.deleteLike(existingLike.id);
        return { liked: false };
      } else {
        // Like - create new like
        const like = await this.createLike({
          user_id: userId,
          target_id: postId || commentId || '',
          target_type: postId ? 'post' : 'comment',
          post_id: postId || null,
          comment_id: commentId || null,
        });
        return { liked: true, like };
      }
    } catch (error) {
      logger.error(`Error toggling like for user ${userId}:`, error);
      throw error;
    }
  }

  /**
   * Get user like stats
   */
  async getUserLikeStats(userId: string): Promise<{
    totalLikesGiven: number;
    totalPostLikes: number;
    totalCommentLikes: number;
  }> {
    try {
      const { data, error } = await supabase
        .from(this.tableName)
        .select('post_id, comment_id')
        .eq('user_id', userId);

      if (error) throw error;

      const stats = (data || []).reduce(
        (acc, like: any) => ({
          totalLikesGiven: acc.totalLikesGiven + 1,
          totalPostLikes: acc.totalPostLikes + (like.target_type === 'post' ? 1 : 0),
          totalCommentLikes: acc.totalCommentLikes + (like.target_type === 'comment' ? 1 : 0),
        }),
        {
          totalLikesGiven: 0,
          totalPostLikes: 0,
          totalCommentLikes: 0,
        }
      );

      return stats;
    } catch (error) {
      logger.error(`Error getting like stats for user ${userId}:`, error);
      throw error;
    }
  }

  /**
   * Check if user can like target
   */
  async canUserLike(userId: string, postId?: string, commentId?: string): Promise<boolean> {
    try {
      if (!postId && !commentId) return false;

      // Check if user already liked
      let existingLike;
      if (postId) {
        existingLike = await this.getUserPostLike(userId, postId);
      } else if (commentId) {
        existingLike = await this.getUserCommentLike(userId, commentId!);
      }

      return !existingLike;
    } catch (error) {
      logger.error(`Error checking if user can like for user ${userId}:`, error);
      return false;
    }
  }

  /**
   * Get a specific like
   */
  async getLike(userId: string, targetId: string, targetType: 'post' | 'comment'): Promise<LikeEntity | null> {
    try {
      const { data, error } = await (supabase as any)
        .from(this.tableName)
        .select('*')
        .eq('user_id', userId)
        .eq('target_id', targetId)
        .eq('target_type', targetType)
        .single();

      if (error) {
        if (error.code === 'PGRST116') return null;
        throw error;
      }

      return data;
    } catch (error) {
      logger.error(`Error getting like:`, error);
      throw error;
    }
  }

  /**
   * Get likes with filters
   */
  async getLikes(filters: any = {}): Promise<{ data: LikeEntity[]; total: number }> {
    try {
      const { limit = 20, offset = 0, userId, targetType } = filters;

      let query = (supabase as any)
        .from(this.tableName)
        .select('*', { count: 'exact' });

      if (userId) {
        query = query.eq('user_id', userId);
      }

      if (targetType) {
        query = query.eq('target_type', targetType);
      }

      query = query
        .order('created_at', { ascending: false })
        .range(offset, offset + limit - 1);

      const { data, error, count } = await query;

      if (error) throw error;

      return {
        data: data || [],
        total: count || 0
      };
    } catch (error) {
      logger.error('Error getting likes:', error);
      throw error;
    }
  }

  /**
   * Get like count for target
   */
  async getLikeCount(targetId: string, targetType: 'post' | 'comment'): Promise<number> {
    try {
      const { data, error } = await (supabase as any)
        .from(this.tableName)
        .select('id', { count: 'exact' })
        .eq('target_id', targetId)
        .eq('target_type', targetType);

      if (error) throw error;

      return data?.length || 0;
    } catch (error) {
      logger.error(`Error getting like count:`, error);
      return 0;
    }
  }

  /**
   * Unlike (remove like)
   */
  async unlike(userId: string, targetId: string, targetType: 'post' | 'comment'): Promise<void> {
    try {
      const { error } = await (supabase as any)
        .from(this.tableName)
        .delete()
        .eq('user_id', userId)
        .eq('target_id', targetId)
        .eq('target_type', targetType);

      if (error) throw error;
    } catch (error) {
      logger.error(`Error unliking:`, error);
      throw error;
    }
  }

  /**
   * Check if user has liked
   */
  async hasUserLiked(userId: string, targetId: string, targetType: 'post' | 'comment'): Promise<boolean> {
    try {
      const like = await this.getLike(userId, targetId, targetType);
      return !!like;
    } catch (error) {
      logger.error(`Error checking if user liked:`, error);
      return false;
    }
  }
}