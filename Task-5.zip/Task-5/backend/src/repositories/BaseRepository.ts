import { SupabaseClient } from '@supabase/supabase-js';
import { getSupabaseAdmin, getSupabaseClient, createUserClient, Database } from '../config/supabase';
import { logger } from '../utils/logger';
import { PaginationOptions, SortOptions, PaginatedResponse } from '../types/database';

export abstract class BaseRepository<T = any> {
  protected supabase: SupabaseClient<Database>;
  protected adminClient: SupabaseClient<Database>;
  protected tableName: string;

  constructor(tableName: string) {
    this.tableName = tableName;
    this.supabase = getSupabaseClient();
    this.adminClient = getSupabaseAdmin();
  }

  /**
   * Get a user-specific client with authentication context
   */
  protected getUserClient(accessToken: string): SupabaseClient<Database> {
    return createUserClient(accessToken);
  }

  /**
   * Build pagination query
   */
  protected buildPaginationQuery(
    query: any,
    options: PaginationOptions & SortOptions = {}
  ) {
    const { limit = 20, offset = 0, sortBy = 'created_at', sortOrder = 'desc' } = options;

    // Apply sorting
    query = query.order(sortBy, { ascending: sortOrder === 'asc' });

    // Apply pagination
    if (limit > 0) {
      const startRange = offset;
      const endRange = offset + limit - 1;
      query = query.range(startRange, endRange);
    }

    return query;
  }

  /**
   * Get total count for pagination
   */
  protected async getTotalCount(
    tableName: string,
    filters: Record<string, any> = {}
  ): Promise<number> {
    try {
      let query = this.supabase
        .from(tableName)
        .select('*', { count: 'exact', head: true });

      // Apply filters
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          query = query.eq(key, value);
        }
      });

      const { count, error } = await query;

      if (error) {
        throw error;
      }

      return count || 0;
    } catch (error) {
      logger.error(`Error getting count for ${tableName}:`, error);
      throw error;
    }
  }

  /**
   * Build paginated response
   */
  protected buildPaginatedResponse<K>(
    data: K[],
    total: number,
    page: number = 1,
    limit: number = 20
  ): PaginatedResponse<K> {
    const totalPages = Math.ceil(total / limit);
    
    return {
      data,
      total,
      page,
      limit,
      totalPages,
      hasNextPage: page < totalPages,
      hasPreviousPage: page > 1,
    };
  }

  /**
   * Generic find by ID
   */
  protected async findById(
    id: string,
    selectColumns: string = '*',
    useAdmin: boolean = false
  ): Promise<T | null> {
    try {
      const client = useAdmin ? this.adminClient : this.supabase;
      
      const { data, error } = await client
        .from(this.tableName)
        .select(selectColumns)
        .eq('id', id)
        .single();

      if (error) {
        if (error.code === 'PGRST116') {
          return null; // Not found
        }
        throw error;
      }

      return data as T;
    } catch (error) {
      logger.error(`Error finding ${this.tableName} by ID ${id}:`, error);
      throw error;
    }
  }

  /**
   * Generic create
   */
  protected async create(
    data: Partial<T>,
    useAdmin: boolean = false
  ): Promise<T> {
    try {
      const client = useAdmin ? this.adminClient : this.supabase;
      
      const { data: created, error } = await (client as any)
        .from(this.tableName)
        .insert(data)
        .select()
        .single();

      if (error) {
        throw error;
      }

      logger.info(`Created ${this.tableName} with ID: ${(created as any).id}`);
      return created as T;
    } catch (error) {
      logger.error(`Error creating ${this.tableName}:`, error);
      throw error;
    }
  }

  /**
   * Generic update
   */
  protected async update(
    id: string,
    data: Partial<T>,
    useAdmin: boolean = false
  ): Promise<T> {
    try {
      const client = useAdmin ? this.adminClient : this.supabase;
      
      const updateData = {
        ...data,
        updated_at: new Date().toISOString(),
      };

      const { data: updated, error } = await (client as any)
        .from(this.tableName)
        .update(updateData)
        .eq('id', id)
        .select()
        .single();

      if (error) {
        throw error;
      }

      if (!updated) {
        throw new Error(`${this.tableName} with ID ${id} not found`);
      }

      logger.info(`Updated ${this.tableName} with ID: ${id}`);
      return updated as T;
    } catch (error) {
      logger.error(`Error updating ${this.tableName} with ID ${id}:`, error);
      throw error;
    }
  }

  /**
   * Generic soft delete
   */
  protected async softDelete(
    id: string,
    useAdmin: boolean = false
  ): Promise<void> {
    try {
      const client = useAdmin ? this.adminClient : this.supabase;
      
      const { error } = await (client as any)
        .from(this.tableName)
        .update({ 
          is_deleted: true,
          updated_at: new Date().toISOString()
        })
        .eq('id', id);

      if (error) {
        throw error;
      }

      logger.info(`Soft deleted ${this.tableName} with ID: ${id}`);
    } catch (error) {
      logger.error(`Error soft deleting ${this.tableName} with ID ${id}:`, error);
      throw error;
    }
  }

  /**
   * Generic hard delete
   */
  protected async hardDelete(
    id: string,
    useAdmin: boolean = false
  ): Promise<void> {
    try {
      const client = useAdmin ? this.adminClient : this.supabase;
      
      const { error } = await client
        .from(this.tableName)
        .delete()
        .eq('id', id);

      if (error) {
        throw error;
      }

      logger.info(`Hard deleted ${this.tableName} with ID: ${id}`);
    } catch (error) {
      logger.error(`Error hard deleting ${this.tableName} with ID ${id}:`, error);
      throw error;
    }
  }

  /**
   * Generic find with filters
   */
  protected async findWithFilters(
    filters: Record<string, any> = {},
    selectColumns: string = '*',
    options: PaginationOptions & SortOptions = {},
    useAdmin: boolean = false
  ): Promise<T[]> {
    try {
      const client = useAdmin ? this.adminClient : this.supabase;
      
      let query = client
        .from(this.tableName)
        .select(selectColumns);

      // Apply filters
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          if (Array.isArray(value)) {
            query = query.in(key, value);
          } else {
            query = query.eq(key, value);
          }
        }
      });

      // Apply pagination and sorting
      query = this.buildPaginationQuery(query, options);

      const { data, error } = await query;

      if (error) {
        throw error;
      }

      return data as T[] || [];
    } catch (error) {
      logger.error(`Error finding ${this.tableName} with filters:`, error);
      throw error;
    }
  }

  /**
   * Check if record exists
   */
  protected async exists(
    filters: Record<string, any>,
    useAdmin: boolean = false
  ): Promise<boolean> {
    try {
      const client = useAdmin ? this.adminClient : this.supabase;
      
      let query = client
        .from(this.tableName)
        .select('id', { head: true, count: 'exact' });

      Object.entries(filters).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          query = query.eq(key, value);
        }
      });

      const { count, error } = await query;

      if (error) {
        throw error;
      }

      return (count || 0) > 0;
    } catch (error) {
      logger.error(`Error checking existence in ${this.tableName}:`, error);
      throw error;
    }
  }
}