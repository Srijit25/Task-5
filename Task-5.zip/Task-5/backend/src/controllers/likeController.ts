import { Request, Response, NextFunction } from 'express';
import { LikeService } from '../services/likeService';
import { logger } from '../utils/logger';

export class LikeController {
  /**
   * Like a post
   * POST /api/posts/:postId/like
   */
  public static async likePost(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { postId } = req.params;
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (!postId) {
        res.status(400).json({
          error: 'Missing post ID',
          message: 'Post ID is required',
          code: 'MISSING_POST_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const result = await LikeService.likePost(postId, userId);

      logger.info('LikeController: Post liked successfully', {
        postId,
        userId,
        liked: result.liked,
      });

      res.status(result.liked ? 201 : 200).json({
        data: result,
        message: result.liked ? 'Post liked successfully' : 'Post already liked',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('LikeController: Like post failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        postId: req.params.postId,
        userId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Unlike a post
   * DELETE /api/posts/:postId/like
   */
  public static async unlikePost(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { postId } = req.params;
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (!postId) {
        res.status(400).json({
          error: 'Missing post ID',
          message: 'Post ID is required',
          code: 'MISSING_POST_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const result = await LikeService.unlikePost(postId, userId);

      logger.info('LikeController: Post unliked successfully', {
        postId,
        userId,
        liked: result.liked,
      });

      res.status(200).json({
        data: result,
        message: 'Post unliked successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('LikeController: Unlike post failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        postId: req.params.postId,
        userId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Toggle like on a post (like if not liked, unlike if liked)
   * POST /api/posts/:postId/toggle-like
   */
  public static async togglePostLike(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { postId } = req.params;
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (!postId) {
        res.status(400).json({
          error: 'Missing post ID',
          message: 'Post ID is required',
          code: 'MISSING_POST_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const result = await LikeService.togglePostLike(postId, userId);

      logger.info('LikeController: Post like toggled successfully', {
        postId,
        userId,
        liked: result.liked,
      });

      res.status(200).json({
        data: result,
        message: result.liked ? 'Post liked successfully' : 'Post unliked successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('LikeController: Toggle post like failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        postId: req.params.postId,
        userId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Like a comment
   * POST /api/comments/:commentId/like
   */
  public static async likeComment(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { commentId } = req.params;
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (!commentId) {
        res.status(400).json({
          error: 'Missing comment ID',
          message: 'Comment ID is required',
          code: 'MISSING_COMMENT_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const result = await LikeService.likeComment(commentId, userId);

      logger.info('LikeController: Comment liked successfully', {
        commentId,
        userId,
        liked: result.liked,
      });

      res.status(result.liked ? 201 : 200).json({
        data: result,
        message: result.liked ? 'Comment liked successfully' : 'Comment already liked',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('LikeController: Like comment failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        commentId: req.params.commentId,
        userId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Unlike a comment
   * DELETE /api/comments/:commentId/like
   */
  public static async unlikeComment(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { commentId } = req.params;
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (!commentId) {
        res.status(400).json({
          error: 'Missing comment ID',
          message: 'Comment ID is required',
          code: 'MISSING_COMMENT_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const result = await LikeService.unlikeComment(commentId, userId);

      logger.info('LikeController: Comment unliked successfully', {
        commentId,
        userId,
        liked: result.liked,
      });

      res.status(200).json({
        data: result,
        message: 'Comment unliked successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('LikeController: Unlike comment failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        commentId: req.params.commentId,
        userId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Toggle like on a comment (like if not liked, unlike if liked)
   * POST /api/comments/:commentId/toggle-like
   */
  public static async toggleCommentLike(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { commentId } = req.params;
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (!commentId) {
        res.status(400).json({
          error: 'Missing comment ID',
          message: 'Comment ID is required',
          code: 'MISSING_COMMENT_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const result = await LikeService.toggleCommentLike(commentId, userId);

      logger.info('LikeController: Comment like toggled successfully', {
        commentId,
        userId,
        liked: result.liked,
      });

      res.status(200).json({
        data: result,
        message: result.liked ? 'Comment liked successfully' : 'Comment unliked successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('LikeController: Toggle comment like failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        commentId: req.params.commentId,
        userId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Check if user has liked a post
   * GET /api/posts/:postId/like-status
   */
  public static async getPostLikeStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { postId } = req.params;
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (!postId) {
        res.status(400).json({
          error: 'Missing post ID',
          message: 'Post ID is required',
          code: 'MISSING_POST_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const liked = await LikeService.hasUserLikedPost(userId, postId);

      logger.info('LikeController: Post like status retrieved successfully', {
        postId,
        userId,
        liked,
      });

      res.status(200).json({
        data: { liked },
        message: 'Like status retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('LikeController: Get post like status failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        postId: req.params.postId,
        userId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Check if user has liked a comment
   * GET /api/comments/:commentId/like-status
   */
  public static async getCommentLikeStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { commentId } = req.params;
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (!commentId) {
        res.status(400).json({
          error: 'Missing comment ID',
          message: 'Comment ID is required',
          code: 'MISSING_COMMENT_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const liked = await LikeService.hasUserLikedComment(userId, commentId);

      logger.info('LikeController: Comment like status retrieved successfully', {
        commentId,
        userId,
        liked,
      });

      res.status(200).json({
        data: { liked },
        message: 'Like status retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('LikeController: Get comment like status failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        commentId: req.params.commentId,
        userId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Get likes for a post
   * GET /api/posts/:postId/likes?page=1&limit=10
   */
  public static async getPostLikes(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { postId } = req.params;
      const { page = '1', limit = '10' } = req.query;

      if (!postId) {
        res.status(400).json({
          error: 'Missing post ID',
          message: 'Post ID is required',
          code: 'MISSING_POST_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const pageNum = parseInt(page as string, 10);
      const limitNum = parseInt(limit as string, 10);

      if (isNaN(pageNum) || isNaN(limitNum) || pageNum < 1 || limitNum < 1) {
        res.status(400).json({
          error: 'Invalid pagination parameters',
          message: 'Page and limit must be positive integers',
          code: 'INVALID_PAGINATION',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const offset = (pageNum - 1) * limitNum;

      const result = await LikeService.getPostLikes(postId, {
        limit: limitNum,
        offset,
        includeUser: true,
      });

      const totalPages = Math.ceil(result.total / limitNum);
      const pagination = {
        currentPage: pageNum,
        totalPages,
        totalItems: result.total,
        itemsPerPage: limitNum,
        hasNextPage: pageNum < totalPages,
        hasPreviousPage: pageNum > 1,
      };

      logger.info('LikeController: Post likes retrieved successfully', {
        postId,
        page: pageNum,
        limit: limitNum,
        count: result.likes.length,
        total: result.total,
      });

      res.status(200).json({
        data: {
          likes: result.likes,
          pagination,
        },
        message: 'Post likes retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('LikeController: Get post likes failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        postId: req.params.postId,
        query: req.query,
      });
      next(error);
    }
  }

  /**
   * Get likes for a comment
   * GET /api/comments/:commentId/likes?page=1&limit=10
   */
  public static async getCommentLikes(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { commentId } = req.params;
      const { page = '1', limit = '10' } = req.query;

      if (!commentId) {
        res.status(400).json({
          error: 'Missing comment ID',
          message: 'Comment ID is required',
          code: 'MISSING_COMMENT_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const pageNum = parseInt(page as string, 10);
      const limitNum = parseInt(limit as string, 10);

      if (isNaN(pageNum) || isNaN(limitNum) || pageNum < 1 || limitNum < 1) {
        res.status(400).json({
          error: 'Invalid pagination parameters',
          message: 'Page and limit must be positive integers',
          code: 'INVALID_PAGINATION',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const offset = (pageNum - 1) * limitNum;

      const result = await LikeService.getCommentLikes(commentId, {
        limit: limitNum,
        offset,
        includeUser: true,
      });

      const totalPages = Math.ceil(result.total / limitNum);
      const pagination = {
        currentPage: pageNum,
        totalPages,
        totalItems: result.total,
        itemsPerPage: limitNum,
        hasNextPage: pageNum < totalPages,
        hasPreviousPage: pageNum > 1,
      };

      logger.info('LikeController: Comment likes retrieved successfully', {
        commentId,
        page: pageNum,
        limit: limitNum,
        count: result.likes.length,
        total: result.total,
      });

      res.status(200).json({
        data: {
          likes: result.likes,
          pagination,
        },
        message: 'Comment likes retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('LikeController: Get comment likes failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        commentId: req.params.commentId,
        query: req.query,
      });
      next(error);
    }
  }

  /**
   * Get user's likes (posts and comments they liked)
   * GET /api/users/:userId/likes?page=1&limit=10&type=post|comment
   */
  public static async getUserLikes(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { userId } = req.params;
      const { page = '1', limit = '10', type } = req.query;

      if (!userId) {
        res.status(400).json({
          error: 'Missing user ID',
          message: 'User ID is required',
          code: 'MISSING_USER_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const pageNum = parseInt(page as string, 10);
      const limitNum = parseInt(limit as string, 10);

      if (isNaN(pageNum) || isNaN(limitNum) || pageNum < 1 || limitNum < 1) {
        res.status(400).json({
          error: 'Invalid pagination parameters',
          message: 'Page and limit must be positive integers',
          code: 'INVALID_PAGINATION',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const offset = (pageNum - 1) * limitNum;

      const result = await LikeService.getUserLikes(userId, {
        limit: limitNum,
        offset,
        type: type as 'post' | 'comment' | 'all',
        includeUser: true,
      });

      const totalPages = Math.ceil(result.total / limitNum);
      const pagination = {
        currentPage: pageNum,
        totalPages,
        totalItems: result.total,
        itemsPerPage: limitNum,
        hasNextPage: pageNum < totalPages,
        hasPreviousPage: pageNum > 1,
      };

      logger.info('LikeController: User likes retrieved successfully', {
        userId,
        page: pageNum,
        limit: limitNum,
        type,
        count: result.likes.length,
        total: result.total,
      });

      res.status(200).json({
        data: {
          likes: result.likes,
          pagination,
        },
        message: 'User likes retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('LikeController: Get user likes failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        userId: req.params.userId,
        query: req.query,
      });
      next(error);
    }
  }

  /**
   * Get most liked posts
   * GET /api/posts/most-liked?timeframe=week&limit=10
   */
  public static async getMostLikedPosts(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { timeframe = 'week', limit = '10' } = req.query;

      const limitNum = parseInt(limit as string, 10);

      if (isNaN(limitNum) || limitNum < 1 || limitNum > 100) {
        res.status(400).json({
          error: 'Invalid limit parameter',
          message: 'Limit must be a positive integer between 1 and 100',
          code: 'INVALID_LIMIT',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const posts = await LikeService.getMostLikedPosts({
        timeframe: timeframe as 'day' | 'week' | 'month' | 'all',
        limit: limitNum,
      });

      logger.info('LikeController: Most liked posts retrieved successfully', {
        timeframe,
        limit: limitNum,
        count: posts.length,
      });

      res.status(200).json({
        data: posts,
        message: 'Most liked posts retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('LikeController: Get most liked posts failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        query: req.query,
      });
      next(error);
    }
  }

  /**
   * Get user's like statistics
   * GET /api/users/:userId/like-stats
   */
  public static async getUserLikeStats(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { userId } = req.params;

      if (!userId) {
        res.status(400).json({
          error: 'Missing user ID',
          message: 'User ID is required',
          code: 'MISSING_USER_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const stats = await LikeService.getUserLikeStats(userId);

      logger.info('LikeController: User like stats retrieved successfully', {
        userId,
        stats,
      });

      res.status(200).json({
        data: stats,
        message: 'User like statistics retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('LikeController: Get user like stats failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        userId: req.params.userId,
      });
      next(error);
    }
  }

  /**
   * Check like status for multiple items
   * POST /api/likes/check-status
   * Body: { posts?: string[], comments?: string[] }
   */
  public static async checkMultipleLikeStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const { posts, comments } = req.body;

      if (!posts && !comments) {
        res.status(400).json({
          error: 'Missing required data',
          message: 'Either posts or comments array is required',
          code: 'MISSING_DATA',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const items: Array<{ type: 'post' | 'comment'; id: string }> = [];
      
      if (posts && Array.isArray(posts)) {
        items.push(...posts.map((id: string) => ({ type: 'post' as const, id })));
      }
      
      if (comments && Array.isArray(comments)) {
        items.push(...comments.map((id: string) => ({ type: 'comment' as const, id })));
      }

      const likeStatus = await LikeService.checkMultipleLikeStatus(userId, items);

      logger.info('LikeController: Multiple like status checked successfully', {
        userId,
        postsCount: posts?.length || 0,
        commentsCount: comments?.length || 0,
      });

      res.status(200).json({
        data: likeStatus,
        message: 'Like status checked successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('LikeController: Check multiple like status failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        userId: req.user?.id,
        body: req.body,
      });
      next(error);
    }
  }
}

export default LikeController;