import { Request, Response, NextFunction } from 'express';
import { UserService } from '../services/userService';
import { logger } from '../utils/logger';

export class UserController {
  /**
   * Get user profile by ID
   * GET /api/users/:id
   */
  public static async getUserProfile(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;

      if (!id) {
        res.status(400).json({
          error: 'Missing user ID',
          message: 'User ID is required',
          code: 'MISSING_USER_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const user = await UserService.getUserProfile(id);

      if (!user) {
        res.status(404).json({
          error: 'User not found',
          message: 'User with the specified ID does not exist',
          code: 'USER_NOT_FOUND',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      logger.info('UserController: User profile retrieved successfully', { userId: id });

      res.status(200).json({
        data: user.toPublicJSON(),
        message: 'User profile retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('UserController: Get user profile failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        userId: req.params.id,
      });
      next(error);
    }
  }

  /**
   * Update current user profile
   * PUT /api/users/profile
   */
  public static async updateProfile(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const { firstName, lastName, bio, profileImageUrl, location, website } = req.body;

      const updatedUser = await UserService.updateProfile(userId, {
        firstName,
        lastName,
        bio,
        profileImageUrl,
        location,
        website,
      });

      logger.info('UserController: User profile updated successfully', { userId });

      res.status(200).json({
        data: updatedUser.toPublicJSON(),
        message: 'Profile updated successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('UserController: Update profile failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        userId: req.user?.id,
        body: req.body,
      });
      next(error);
    }
  }

  /**
   * Search users by username or email
   * GET /api/users/search?q=query&page=1&limit=10
   */
  public static async searchUsers(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { q: query, page = '1', limit = '10' } = req.query;

      if (!query || typeof query !== 'string') {
        res.status(400).json({
          error: 'Missing search query',
          message: 'Search query is required',
          code: 'MISSING_QUERY',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const pageNum = parseInt(page as string, 10);
      const limitNum = parseInt(limit as string, 10);

      if (isNaN(pageNum) || isNaN(limitNum) || pageNum < 1 || limitNum < 1) {
        res.status(400).json({
          error: 'Invalid pagination parameters',
          message: 'Page and limit must be positive integers',
          code: 'INVALID_PAGINATION',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const offset = (pageNum - 1) * limitNum;
      const result = await UserService.searchUsers({
        query,
        limit: limitNum,
        offset,
      });

      const totalPages = Math.ceil(result.total / limitNum);
      const pagination = {
        currentPage: pageNum,
        totalPages,
        totalItems: result.total,
        itemsPerPage: limitNum,
        hasNextPage: pageNum < totalPages,
        hasPreviousPage: pageNum > 1,
      };

      logger.info('UserController: User search completed successfully', {
        query,
        page: pageNum,
        limit: limitNum,
        resultCount: result.users.length,
      });

      res.status(200).json({
        data: {
          users: result.users.map(user => user.toPublicJSON()),
          pagination,
        },
        message: 'User search completed successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('UserController: User search failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        query: req.query.q,
      });
      next(error);
    }
  }

  /**
   * Follow a user
   * POST /api/users/:id/follow
   */
  public static async followUser(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const followerId = req.user?.id;
      const { id: followeeId } = req.params;

      if (!followerId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (!followeeId) {
        res.status(400).json({
          error: 'Missing user ID',
          message: 'User ID to follow is required',
          code: 'MISSING_USER_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (followerId === followeeId) {
        res.status(400).json({
          error: 'Cannot follow yourself',
          message: 'You cannot follow yourself',
          code: 'SELF_FOLLOW',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const result = await UserService.toggleFollow(followerId, followeeId);

      if (!result.following) {
        res.status(400).json({
          error: 'User already not followed',
          message: 'You are not following this user',
          code: 'NOT_FOLLOWING',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      logger.info('UserController: User followed successfully', {
        followerId,
        followeeId,
      });

      res.status(201).json({
        data: { following: result.following },
        message: 'User followed successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('UserController: Follow user failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        followerId: req.user?.id,
        followeeId: req.params.id,
      });
      next(error);
    }
  }

  /**
   * Unfollow a user
   * DELETE /api/users/:id/follow
   */
  public static async unfollowUser(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const followerId = req.user?.id;
      const { id: followeeId } = req.params;

      if (!followerId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (!followeeId) {
        res.status(400).json({
          error: 'Missing user ID',
          message: 'User ID to unfollow is required',
          code: 'MISSING_USER_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const result = await UserService.toggleFollow(followerId, followeeId);

      if (result.following) {
        res.status(400).json({
          error: 'User still followed',
          message: 'You are still following this user',
          code: 'STILL_FOLLOWING',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      logger.info('UserController: User unfollowed successfully', {
        followerId,
        followeeId,
      });

      res.status(200).json({
        message: 'User unfollowed successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('UserController: Unfollow user failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        followerId: req.user?.id,
        followeeId: req.params.id,
      });
      next(error);
    }
  }

  /**
   * Get user's followers
   * GET /api/users/:id/followers?page=1&limit=10
   */
  public static async getFollowers(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;
      const { page = '1', limit = '10' } = req.query;

      if (!id) {
        res.status(400).json({
          error: 'Missing user ID',
          message: 'User ID is required',
          code: 'MISSING_USER_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const pageNum = parseInt(page as string, 10);
      const limitNum = parseInt(limit as string, 10);

      if (isNaN(pageNum) || isNaN(limitNum) || pageNum < 1 || limitNum < 1) {
        res.status(400).json({
          error: 'Invalid pagination parameters',
          message: 'Page and limit must be positive integers',
          code: 'INVALID_PAGINATION',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const offset = (pageNum - 1) * limitNum;
      const result = await UserService.getUserFollowers(id, {
        limit: limitNum,
        offset,
      });

      const totalPages = Math.ceil(result.total / limitNum);
      const pagination = {
        currentPage: pageNum,
        totalPages,
        totalItems: result.total,
        itemsPerPage: limitNum,
        hasNextPage: pageNum < totalPages,
        hasPreviousPage: pageNum > 1,
      };

      logger.info('UserController: Followers retrieved successfully', {
        userId: id,
        page: pageNum,
        limit: limitNum,
        count: result.followers.length,
      });

      res.status(200).json({
        data: {
          followers: result.followers.map((follower: any) => follower.toPublicJSON()),
          pagination,
        },
        message: 'Followers retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('UserController: Get followers failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        userId: req.params.id,
      });
      next(error);
    }
  }

  /**
   * Get users that a user is following
   * GET /api/users/:id/following?page=1&limit=10
   */
  public static async getFollowing(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;
      const { page = '1', limit = '10' } = req.query;

      if (!id) {
        res.status(400).json({
          error: 'Missing user ID',
          message: 'User ID is required',
          code: 'MISSING_USER_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const pageNum = parseInt(page as string, 10);
      const limitNum = parseInt(limit as string, 10);

      if (isNaN(pageNum) || isNaN(limitNum) || pageNum < 1 || limitNum < 1) {
        res.status(400).json({
          error: 'Invalid pagination parameters',
          message: 'Page and limit must be positive integers',
          code: 'INVALID_PAGINATION',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const offset = (pageNum - 1) * limitNum;
      const result = await UserService.getUserFollowing(id, {
        limit: limitNum,
        offset,
      });

      const totalPages = Math.ceil(result.total / limitNum);
      const pagination = {
        currentPage: pageNum,
        totalPages,
        totalItems: result.total,
        itemsPerPage: limitNum,
        hasNextPage: pageNum < totalPages,
        hasPreviousPage: pageNum > 1,
      };

      logger.info('UserController: Following retrieved successfully', {
        userId: id,
        page: pageNum,
        limit: limitNum,
        count: result.following.length,
      });

      res.status(200).json({
        data: {
          following: result.following.map((user: any) => user.toPublicJSON()),
          pagination,
        },
        message: 'Following retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('UserController: Get following failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        userId: req.params.id,
      });
      next(error);
    }
  }

  /**
   * Get user suggestions (people you might want to follow)
   * GET /api/users/suggestions?limit=5
   */
  public static async getUserSuggestions(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = req.user?.id;
      const { limit = '5' } = req.query;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const limitNum = parseInt(limit as string, 10);

      if (isNaN(limitNum) || limitNum < 1 || limitNum > 20) {
        res.status(400).json({
          error: 'Invalid limit parameter',
          message: 'Limit must be a positive integer between 1 and 20',
          code: 'INVALID_LIMIT',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const suggestions = await UserService.getSuggestedUsers(userId, {
        limit: limitNum,
      });

      logger.info('UserController: User suggestions retrieved successfully', {
        userId,
        limit: limitNum,
        count: suggestions.length,
      });

      res.status(200).json({
        data: suggestions.map((user: any) => user.toPublicJSON()),
        message: 'User suggestions retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('UserController: Get user suggestions failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        userId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Get user statistics
   * GET /api/users/:id/stats
   */
  public static async getUserStats(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;

      if (!id) {
        res.status(400).json({
          error: 'Missing user ID',
          message: 'User ID is required',
          code: 'MISSING_USER_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const stats = await UserService.getUserStats(id);

      logger.info('UserController: User stats retrieved successfully', { userId: id });

      res.status(200).json({
        data: stats,
        message: 'User statistics retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('UserController: Get user stats failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        userId: req.params.id,
      });
      next(error);
    }
  }

  /**
   * Delete user account
   * DELETE /api/users/account
   */
  public static async deleteAccount(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      await UserService.deactivateAccount(userId);

      logger.info('UserController: User account deactivated successfully', { userId });

      res.status(200).json({
        message: 'Account deactivated successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('UserController: Delete account failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        userId: req.user?.id,
      });
      next(error);
    }
  }
}

export default UserController;