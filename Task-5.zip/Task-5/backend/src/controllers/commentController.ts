import { Request, Response, NextFunction } from 'express';
import { CommentService } from '../services/commentService';
import { logger } from '../utils/logger';

export class CommentController {
  /**
   * Create a new comment
   * POST /api/posts/:postId/comments
   */
  public static async createComment(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { postId } = req.params;
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (!postId) {
        res.status(400).json({
          error: 'Missing post ID',
          message: 'Post ID is required',
          code: 'MISSING_POST_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const { content, parentId } = req.body;

      // Validate required fields
      if (!content || content.trim().length === 0) {
        res.status(400).json({
          error: 'Missing required fields',
          message: 'Comment content is required',
          code: 'MISSING_FIELDS',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const comment = await CommentService.createComment(postId, userId, {
        content: content.trim(),
        parentId,
      });

      logger.info('CommentController: Comment created successfully', {
        commentId: comment.id,
        postId,
        userId,
        parentId,
      });

      res.status(201).json({
        data: comment.toJSON(),
        message: 'Comment created successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('CommentController: Create comment failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        postId: req.params.postId,
        userId: req.user?.id,
        body: req.body,
      });
      next(error);
    }
  }

  /**
   * Get comment by ID
   * GET /api/comments/:id
   */
  public static async getComment(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;
      const viewerId = req.user?.id;

      if (!id) {
        res.status(400).json({
          error: 'Missing comment ID',
          message: 'Comment ID is required',
          code: 'MISSING_COMMENT_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const comment = await CommentService.getCommentById(id, viewerId);

      if (!comment) {
        res.status(404).json({
          error: 'Comment not found',
          message: 'Comment with the specified ID does not exist',
          code: 'COMMENT_NOT_FOUND',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      logger.info('CommentController: Comment retrieved successfully', {
        commentId: id,
        viewerId,
      });

      res.status(200).json({
        data: comment.toJSON(),
        message: 'Comment retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('CommentController: Get comment failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        commentId: req.params.id,
        viewerId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Update comment
   * PUT /api/comments/:id
   */
  public static async updateComment(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (!id) {
        res.status(400).json({
          error: 'Missing comment ID',
          message: 'Comment ID is required',
          code: 'MISSING_COMMENT_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const { content } = req.body;

      // Validate required fields
      if (!content || content.trim().length === 0) {
        res.status(400).json({
          error: 'Missing required fields',
          message: 'Comment content is required',
          code: 'MISSING_FIELDS',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const updatedComment = await CommentService.updateComment(id, userId, {
        content: content.trim(),
      });

      logger.info('CommentController: Comment updated successfully', {
        commentId: id,
        userId,
      });

      res.status(200).json({
        data: updatedComment.toJSON(),
        message: 'Comment updated successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('CommentController: Update comment failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        commentId: req.params.id,
        userId: req.user?.id,
        body: req.body,
      });
      next(error);
    }
  }

  /**
   * Delete comment
   * DELETE /api/comments/:id
   */
  public static async deleteComment(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (!id) {
        res.status(400).json({
          error: 'Missing comment ID',
          message: 'Comment ID is required',
          code: 'MISSING_COMMENT_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      await CommentService.deleteComment(id, userId);

      logger.info('CommentController: Comment deleted successfully', {
        commentId: id,
        userId,
      });

      res.status(200).json({
        message: 'Comment deleted successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('CommentController: Delete comment failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        commentId: req.params.id,
        userId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Get comments for a post
   * GET /api/posts/:postId/comments?page=1&limit=10&includeReplies=false
   */
  public static async getPostComments(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { postId } = req.params;
      const {
        page = '1',
        limit = '10',
        includeReplies = 'false',
        sortBy = 'createdAt',
        sortOrder = 'ASC',
      } = req.query;

      if (!postId) {
        res.status(400).json({
          error: 'Missing post ID',
          message: 'Post ID is required',
          code: 'MISSING_POST_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const pageNum = parseInt(page as string, 10);
      const limitNum = parseInt(limit as string, 10);

      if (isNaN(pageNum) || isNaN(limitNum) || pageNum < 1 || limitNum < 1) {
        res.status(400).json({
          error: 'Invalid pagination parameters',
          message: 'Page and limit must be positive integers',
          code: 'INVALID_PAGINATION',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const offset = (pageNum - 1) * limitNum;

      const result = await CommentService.getPostComments(postId, {
        limit: limitNum,
        offset,
        includeUser: true,
        includeReplies: includeReplies === 'true',
        sortBy: sortBy as any,
        sortOrder: sortOrder as any,
      });

      const totalPages = Math.ceil(result.total / limitNum);
      const pagination = {
        currentPage: pageNum,
        totalPages,
        totalItems: result.total,
        itemsPerPage: limitNum,
        hasNextPage: pageNum < totalPages,
        hasPreviousPage: pageNum > 1,
      };

      logger.info('CommentController: Post comments retrieved successfully', {
        postId,
        page: pageNum,
        limit: limitNum,
        count: result.comments.length,
        total: result.total,
      });

      res.status(200).json({
        data: {
          comments: result.comments.map(comment => comment.toJSON()),
          pagination,
        },
        message: 'Post comments retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('CommentController: Get post comments failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        postId: req.params.postId,
        query: req.query,
      });
      next(error);
    }
  }

  /**
   * Get replies for a comment
   * GET /api/comments/:id/replies?page=1&limit=10
   */
  public static async getCommentReplies(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;
      const {
        page = '1',
        limit = '10',
        sortBy = 'createdAt',
        sortOrder = 'ASC',
      } = req.query;

      if (!id) {
        res.status(400).json({
          error: 'Missing comment ID',
          message: 'Comment ID is required',
          code: 'MISSING_COMMENT_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const pageNum = parseInt(page as string, 10);
      const limitNum = parseInt(limit as string, 10);

      if (isNaN(pageNum) || isNaN(limitNum) || pageNum < 1 || limitNum < 1) {
        res.status(400).json({
          error: 'Invalid pagination parameters',
          message: 'Page and limit must be positive integers',
          code: 'INVALID_PAGINATION',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const offset = (pageNum - 1) * limitNum;

      const result = await CommentService.getCommentReplies(id, {
        limit: limitNum,
        offset,
        includeUser: true,
        sortBy: sortBy as any,
        sortOrder: sortOrder as any,
      });

      const totalPages = Math.ceil(result.total / limitNum);
      const pagination = {
        currentPage: pageNum,
        totalPages,
        totalItems: result.total,
        itemsPerPage: limitNum,
        hasNextPage: pageNum < totalPages,
        hasPreviousPage: pageNum > 1,
      };

      logger.info('CommentController: Comment replies retrieved successfully', {
        commentId: id,
        page: pageNum,
        limit: limitNum,
        count: result.comments.length,
        total: result.total,
      });

      res.status(200).json({
        data: {
          replies: result.comments.map(reply => reply.toJSON()),
          pagination,
        },
        message: 'Comment replies retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('CommentController: Get comment replies failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        commentId: req.params.id,
        query: req.query,
      });
      next(error);
    }
  }

  /**
   * Get comment thread (comment with all nested replies)
   * GET /api/comments/:id/thread
   */
  public static async getCommentThread(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;

      if (!id) {
        res.status(400).json({
          error: 'Missing comment ID',
          message: 'Comment ID is required',
          code: 'MISSING_COMMENT_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const thread = await CommentService.getCommentThread(id);

      if (!thread || thread.length === 0) {
        res.status(404).json({
          error: 'Comment not found',
          message: 'Comment with the specified ID does not exist',
          code: 'COMMENT_NOT_FOUND',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      logger.info('CommentController: Comment thread retrieved successfully', {
        commentId: id,
        threadLength: thread.length,
      });

      res.status(200).json({
        data: thread.map(comment => comment.toJSON()),
        message: 'Comment thread retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('CommentController: Get comment thread failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        commentId: req.params.id,
      });
      next(error);
    }
  }

  /**
   * Like or unlike a comment
   * POST /api/comments/:id/like
   */
  public static async toggleCommentLike(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (!id) {
        res.status(400).json({
          error: 'Missing comment ID',
          message: 'Comment ID is required',
          code: 'MISSING_COMMENT_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const result = await CommentService.toggleCommentLike(id, userId);

      logger.info('CommentController: Comment like toggled successfully', {
        commentId: id,
        userId,
        liked: result.liked,
      });

      res.status(200).json({
        data: result,
        message: result.liked ? 'Comment liked successfully' : 'Comment unliked successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('CommentController: Toggle comment like failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        commentId: req.params.id,
        userId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Get comment likes
   * GET /api/comments/:id/likes?page=1&limit=10
   */
  public static async getCommentLikes(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;
      const { page = '1', limit = '10' } = req.query;

      if (!id) {
        res.status(400).json({
          error: 'Missing comment ID',
          message: 'Comment ID is required',
          code: 'MISSING_COMMENT_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const pageNum = parseInt(page as string, 10);
      const limitNum = parseInt(limit as string, 10);

      if (isNaN(pageNum) || isNaN(limitNum) || pageNum < 1 || limitNum < 1) {
        res.status(400).json({
          error: 'Invalid pagination parameters',
          message: 'Page and limit must be positive integers',
          code: 'INVALID_PAGINATION',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const offset = (pageNum - 1) * limitNum;

      const result = await CommentService.getCommentLikes(id, {
        limit: limitNum,
        offset,
      });

      const totalPages = Math.ceil(result.total / limitNum);
      const pagination = {
        currentPage: pageNum,
        totalPages,
        totalItems: result.total,
        itemsPerPage: limitNum,
        hasNextPage: pageNum < totalPages,
        hasPreviousPage: pageNum > 1,
      };

      logger.info('CommentController: Comment likes retrieved successfully', {
        commentId: id,
        page: pageNum,
        limit: limitNum,
        count: result.likes.length,
        total: result.total,
      });

      res.status(200).json({
        data: {
          likes: result.likes.map(like => like.toJSON()),
          pagination,
        },
        message: 'Comment likes retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('CommentController: Get comment likes failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        commentId: req.params.id,
        query: req.query,
      });
      next(error);
    }
  }

  /**
   * Get user's comments
   * GET /api/users/:userId/comments?page=1&limit=10
   */
  public static async getUserComments(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { userId } = req.params;
      const {
        page = '1',
        limit = '10',
        sortBy = 'createdAt',
        sortOrder = 'DESC',
      } = req.query;

      if (!userId) {
        res.status(400).json({
          error: 'Missing user ID',
          message: 'User ID is required',
          code: 'MISSING_USER_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const pageNum = parseInt(page as string, 10);
      const limitNum = parseInt(limit as string, 10);

      if (isNaN(pageNum) || isNaN(limitNum) || pageNum < 1 || limitNum < 1) {
        res.status(400).json({
          error: 'Invalid pagination parameters',
          message: 'Page and limit must be positive integers',
          code: 'INVALID_PAGINATION',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const offset = (pageNum - 1) * limitNum;

      const result = await CommentService.getUserComments(userId, {
        limit: limitNum,
        offset,
        includeUser: true,
        sortBy: sortBy as any,
        sortOrder: sortOrder as any,
      });

      const totalPages = Math.ceil(result.total / limitNum);
      const pagination = {
        currentPage: pageNum,
        totalPages,
        totalItems: result.total,
        itemsPerPage: limitNum,
        hasNextPage: pageNum < totalPages,
        hasPreviousPage: pageNum > 1,
      };

      logger.info('CommentController: User comments retrieved successfully', {
        userId,
        page: pageNum,
        limit: limitNum,
        count: result.comments.length,
        total: result.total,
      });

      res.status(200).json({
        data: {
          comments: result.comments.map(comment => comment.toJSON()),
          pagination,
        },
        message: 'User comments retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('CommentController: Get user comments failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        userId: req.params.userId,
        query: req.query,
      });
      next(error);
    }
  }
}

export default CommentController;