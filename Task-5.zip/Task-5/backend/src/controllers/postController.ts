import { Request, Response, NextFunction } from 'express';
import { PostService } from '../services/postService';
import { logger } from '../utils/logger';

export class PostController {
  /**
   * Create a new post
   * POST /api/posts
   */
  public static async createPost(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const { content, mediaUrls, tagNames, visibility, allowComments, allowLikes } = req.body;

      // Validate required fields
      if (!content) {
        res.status(400).json({
          error: 'Missing required fields',
          message: 'Content is required',
          code: 'MISSING_FIELDS',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const post = await PostService.createPost(userId, {
        content,
        mediaUrls,
        tagNames,
        visibility,
        allowComments,
        allowLikes,
      });

      logger.info('PostController: Post created successfully', {
        postId: post.id,
        userId,
        hasContent: post.hasContent(),
      });

      res.status(201).json({
        data: post.toJSON(),
        message: 'Post created successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('PostController: Create post failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        userId: req.user?.id,
        body: req.body,
      });
      next(error);
    }
  }

  /**
   * Get post by ID
   * GET /api/posts/:id
   */
  public static async getPost(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;
      const viewerId = req.user?.id;

      if (!id) {
        res.status(400).json({
          error: 'Missing post ID',
          message: 'Post ID is required',
          code: 'MISSING_POST_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const post = await PostService.getPostById(id, viewerId);

      if (!post) {
        res.status(404).json({
          error: 'Post not found',
          message: 'Post with the specified ID does not exist or is not accessible',
          code: 'POST_NOT_FOUND',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      logger.info('PostController: Post retrieved successfully', {
        postId: id,
        viewerId,
      });

      res.status(200).json({
        data: post.toJSON(),
        message: 'Post retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('PostController: Get post failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        postId: req.params.id,
        viewerId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Update post
   * PUT /api/posts/:id
   */
  public static async updatePost(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (!id) {
        res.status(400).json({
          error: 'Missing post ID',
          message: 'Post ID is required',
          code: 'MISSING_POST_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const { content, mediaUrls, tagNames, visibility, allowComments, allowLikes } = req.body;

      const updatedPost = await PostService.updatePost(id, userId, {
        content,
        mediaUrls,
        tagNames,
        visibility,
        allowComments,
        allowLikes,
      });

      logger.info('PostController: Post updated successfully', {
        postId: id,
        userId,
      });

      res.status(200).json({
        data: updatedPost.toJSON(),
        message: 'Post updated successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('PostController: Update post failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        postId: req.params.id,
        userId: req.user?.id,
        body: req.body,
      });
      next(error);
    }
  }

  /**
   * Delete post
   * DELETE /api/posts/:id
   */
  public static async deletePost(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (!id) {
        res.status(400).json({
          error: 'Missing post ID',
          message: 'Post ID is required',
          code: 'MISSING_POST_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      await PostService.deletePost(id, userId);

      logger.info('PostController: Post deleted successfully', {
        postId: id,
        userId,
      });

      res.status(200).json({
        message: 'Post deleted successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('PostController: Delete post failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        postId: req.params.id,
        userId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Get posts with pagination and filtering
   * GET /api/posts?page=1&limit=10&sortBy=createdAt&sortOrder=DESC&userId=abc&tagName=tech
   */
  public static async getPosts(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const {
        page = '1',
        limit = '10',
        sortBy = 'createdAt',
        sortOrder = 'DESC',
        userId,
        tagName,
        includeUser = 'true',
        includeTags = 'true',
      } = req.query;

      const pageNum = parseInt(page as string, 10);
      const limitNum = parseInt(limit as string, 10);

      if (isNaN(pageNum) || isNaN(limitNum) || pageNum < 1 || limitNum < 1) {
        res.status(400).json({
          error: 'Invalid pagination parameters',
          message: 'Page and limit must be positive integers',
          code: 'INVALID_PAGINATION',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const offset = (pageNum - 1) * limitNum;

      const result = await PostService.getPosts({
        limit: limitNum,
        offset,
        sortBy: sortBy as any,
        sortOrder: sortOrder as any,
        userId: userId as string,
        tagName: tagName as string,
        includeUser: includeUser === 'true',
        includeTags: includeTags === 'true',
      });

      const totalPages = Math.ceil(result.total / limitNum);
      const pagination = {
        currentPage: pageNum,
        totalPages,
        totalItems: result.total,
        itemsPerPage: limitNum,
        hasNextPage: pageNum < totalPages,
        hasPreviousPage: pageNum > 1,
      };

      logger.info('PostController: Posts retrieved successfully', {
        page: pageNum,
        limit: limitNum,
        count: result.posts.length,
        total: result.total,
      });

      res.status(200).json({
        data: {
          posts: result.posts.map(post => post.toJSON()),
          pagination,
        },
        message: 'Posts retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('PostController: Get posts failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        query: req.query,
      });
      next(error);
    }
  }

  /**
   * Search posts
   * GET /api/posts/search?q=query&page=1&limit=10&sortBy=relevance&tagNames=tech,programming
   */
  public static async searchPosts(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const {
        q: query,
        page = '1',
        limit = '10',
        sortBy = 'relevance',
        tagNames,
        userId,
      } = req.query;

      if (!query || typeof query !== 'string') {
        res.status(400).json({
          error: 'Missing search query',
          message: 'Search query is required',
          code: 'MISSING_QUERY',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const pageNum = parseInt(page as string, 10);
      const limitNum = parseInt(limit as string, 10);

      if (isNaN(pageNum) || isNaN(limitNum) || pageNum < 1 || limitNum < 1) {
        res.status(400).json({
          error: 'Invalid pagination parameters',
          message: 'Page and limit must be positive integers',
          code: 'INVALID_PAGINATION',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const offset = (pageNum - 1) * limitNum;
      const tagNamesArray = tagNames ? (tagNames as string).split(',').map(t => t.trim()) : undefined;

      const result = await PostService.searchPosts({
        query,
        limit: limitNum,
        offset,
        ...(tagNamesArray && { tagNames: tagNamesArray }),
        ...(userId && { userId: userId as string }),
      });

      const totalPages = Math.ceil(result.total / limitNum);
      const pagination = {
        currentPage: pageNum,
        totalPages,
        totalItems: result.total,
        itemsPerPage: limitNum,
        hasNextPage: pageNum < totalPages,
        hasPreviousPage: pageNum > 1,
      };

      logger.info('PostController: Post search completed successfully', {
        query,
        page: pageNum,
        limit: limitNum,
        count: result.posts.length,
        total: result.total,
      });

      res.status(200).json({
        data: {
          posts: result.posts.map(post => post.toJSON()),
          pagination,
        },
        message: 'Post search completed successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('PostController: Search posts failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        query: req.query.q,
      });
      next(error);
    }
  }

  /**
   * Get trending posts
   * GET /api/posts/trending?timeframe=week&page=1&limit=10
   */
  public static async getTrendingPosts(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const {
        timeframe = 'week',
        page = '1',
        limit = '10',
      } = req.query;

      const pageNum = parseInt(page as string, 10);
      const limitNum = parseInt(limit as string, 10);

      if (isNaN(pageNum) || isNaN(limitNum) || pageNum < 1 || limitNum < 1) {
        res.status(400).json({
          error: 'Invalid pagination parameters',
          message: 'Page and limit must be positive integers',
          code: 'INVALID_PAGINATION',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const offset = (pageNum - 1) * limitNum;

      const result = await PostService.getTrendingPosts({
        timeframe: timeframe as any,
        limit: limitNum,
        offset,
      });

      const totalPages = Math.ceil(result.total / limitNum);
      const pagination = {
        currentPage: pageNum,
        totalPages,
        totalItems: result.total,
        itemsPerPage: limitNum,
        hasNextPage: pageNum < totalPages,
        hasPreviousPage: pageNum > 1,
      };

      logger.info('PostController: Trending posts retrieved successfully', {
        timeframe,
        page: pageNum,
        limit: limitNum,
        count: result.posts.length,
      });

      res.status(200).json({
        data: {
          posts: result.posts.map(post => post.toJSON()),
          pagination,
        },
        message: 'Trending posts retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('PostController: Get trending posts failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        query: req.query,
      });
      next(error);
    }
  }

  /**
   * Get user feed (posts from followed users)
   * GET /api/posts/feed?page=1&limit=10
   */
  public static async getUserFeed(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const { page = '1', limit = '10' } = req.query;

      const pageNum = parseInt(page as string, 10);
      const limitNum = parseInt(limit as string, 10);

      if (isNaN(pageNum) || isNaN(limitNum) || pageNum < 1 || limitNum < 1) {
        res.status(400).json({
          error: 'Invalid pagination parameters',
          message: 'Page and limit must be positive integers',
          code: 'INVALID_PAGINATION',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const offset = (pageNum - 1) * limitNum;

      const result = await PostService.getUserFeed(userId, {
        limit: limitNum,
        offset,
      });

      const totalPages = Math.ceil(result.total / limitNum);
      const pagination = {
        currentPage: pageNum,
        totalPages,
        totalItems: result.total,
        itemsPerPage: limitNum,
        hasNextPage: pageNum < totalPages,
        hasPreviousPage: pageNum > 1,
      };

      logger.info('PostController: User feed retrieved successfully', {
        userId,
        page: pageNum,
        limit: limitNum,
        count: result.posts.length,
      });

      res.status(200).json({
        data: {
          posts: result.posts.map(post => post.toJSON()),
          pagination,
        },
        message: 'User feed retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('PostController: Get user feed failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        userId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Get posts by user
   * GET /api/users/:userId/posts?page=1&limit=10&includePrivate=false
   */
  public static async getUserPosts(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { userId } = req.params;
      const viewerId = req.user?.id;
      const { page = '1', limit = '10', includePrivate = 'false' } = req.query;

      if (!userId) {
        res.status(400).json({
          error: 'Missing user ID',
          message: 'User ID is required',
          code: 'MISSING_USER_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const pageNum = parseInt(page as string, 10);
      const limitNum = parseInt(limit as string, 10);

      if (isNaN(pageNum) || isNaN(limitNum) || pageNum < 1 || limitNum < 1) {
        res.status(400).json({
          error: 'Invalid pagination parameters',
          message: 'Page and limit must be positive integers',
          code: 'INVALID_PAGINATION',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const offset = (pageNum - 1) * limitNum;

      const result = await PostService.getUserPosts(userId, viewerId, {
        limit: limitNum,
        offset,
        includePrivate: includePrivate === 'true',
      });

      const totalPages = Math.ceil(result.total / limitNum);
      const pagination = {
        currentPage: pageNum,
        totalPages,
        totalItems: result.total,
        itemsPerPage: limitNum,
        hasNextPage: pageNum < totalPages,
        hasPreviousPage: pageNum > 1,
      };

      logger.info('PostController: User posts retrieved successfully', {
        userId,
        viewerId,
        page: pageNum,
        limit: limitNum,
        count: result.posts.length,
      });

      res.status(200).json({
        data: {
          posts: result.posts.map(post => post.toJSON()),
          pagination,
        },
        message: 'User posts retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('PostController: Get user posts failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        userId: req.params.userId,
        viewerId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Like or unlike a post
   * POST /api/posts/:id/like
   */
  public static async toggleLike(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (!id) {
        res.status(400).json({
          error: 'Missing post ID',
          message: 'Post ID is required',
          code: 'MISSING_POST_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const result = await PostService.toggleLike(id, userId);

      logger.info('PostController: Post like toggled successfully', {
        postId: id,
        userId,
        liked: result.liked,
      });

      res.status(200).json({
        data: result,
        message: result.liked ? 'Post liked successfully' : 'Post unliked successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('PostController: Toggle post like failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        postId: req.params.id,
        userId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Get post statistics
   * GET /api/posts/:id/stats
   */
  public static async getPostStats(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { id } = req.params;

      if (!id) {
        res.status(400).json({
          error: 'Missing post ID',
          message: 'Post ID is required',
          code: 'MISSING_POST_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const stats = await PostService.getPostStats(id);

      logger.info('PostController: Post stats retrieved successfully', {
        postId: id,
        stats,
      });

      res.status(200).json({
        data: stats,
        message: 'Post statistics retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('PostController: Get post stats failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        postId: req.params.id,
      });
      next(error);
    }
  }
}

export default PostController;