import { Request, Response, NextFunction } from 'express';
import { AuthService } from '../services/authService';
import { logger } from '../utils/logger';

export class AuthController {
  /**
   * Register a new user
   * POST /api/auth/register
   */
  public static async register(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { email, username, password, firstName, lastName } = req.body;

      // Validate required fields
      if (!email || !username || !password || !firstName || !lastName) {
        res.status(400).json({
          error: 'Missing required fields',
          message: 'Email, username, password, firstName, and lastName are required',
          code: 'MISSING_FIELDS',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      // Register user
      const authTokens = await AuthService.register({
        email,
        username,
        password,
        firstName,
        lastName,
      });

      logger.info('AuthController: User registered successfully', {
        userId: authTokens.user.id,
        email: authTokens.user.email,
      });

      res.status(201).json({
        data: authTokens,
        message: 'User registered successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('AuthController: Registration failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        body: req.body,
      });
      next(error);
    }
  }

  /**
   * Login user
   * POST /api/auth/login
   */
  public static async login(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { email, password } = req.body;

      // Validate required fields
      if (!email || !password) {
        res.status(400).json({
          error: 'Missing required fields',
          message: 'Email and password are required',
          code: 'MISSING_FIELDS',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      // Login user
      const authTokens = await AuthService.login({ email, password });

      logger.info('AuthController: User logged in successfully', {
        userId: authTokens.user.id,
        email: authTokens.user.email,
      });

      res.status(200).json({
        data: authTokens,
        message: 'Login successful',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('AuthController: Login failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        email: req.body.email,
      });
      next(error);
    }
  }

  /**
   * Refresh access token
   * POST /api/auth/refresh
   */
  public static async refreshToken(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { refreshToken } = req.body;

      // Validate required fields
      if (!refreshToken) {
        res.status(400).json({
          error: 'Missing refresh token',
          message: 'Refresh token is required',
          code: 'MISSING_REFRESH_TOKEN',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      // Refresh token
      const { accessToken } = await AuthService.refreshToken(refreshToken);

      logger.info('AuthController: Token refreshed successfully');

      res.status(200).json({
        data: { accessToken },
        message: 'Token refreshed successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('AuthController: Token refresh failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
      });
      next(error);
    }
  }

  /**
   * Logout user
   * POST /api/auth/logout
   */
  public static async logout(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      // Logout user
      await AuthService.logout(userId);

      logger.info('AuthController: User logged out successfully', { userId });

      res.status(200).json({
        message: 'Logout successful',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('AuthController: Logout failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        userId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Change password
   * POST /api/auth/change-password
   */
  public static async changePassword(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { currentPassword, newPassword } = req.body;
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      // Validate required fields
      if (!currentPassword || !newPassword) {
        res.status(400).json({
          error: 'Missing required fields',
          message: 'Current password and new password are required',
          code: 'MISSING_FIELDS',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      // Change password
      await AuthService.changePassword(userId, currentPassword, newPassword);

      logger.info('AuthController: Password changed successfully', { userId });

      res.status(200).json({
        message: 'Password changed successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('AuthController: Password change failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        userId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Reset password
   * POST /api/auth/reset-password
   */
  public static async resetPassword(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { email, newPassword } = req.body;

      // Validate required fields
      if (!email || !newPassword) {
        res.status(400).json({
          error: 'Missing required fields',
          message: 'Email and new password are required',
          code: 'MISSING_FIELDS',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      // Reset password (simplified - in production would require email verification)
      await AuthService.resetPassword(email, newPassword);

      logger.info('AuthController: Password reset successfully', { email });

      res.status(200).json({
        message: 'Password reset successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('AuthController: Password reset failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        email: req.body.email,
      });
      next(error);
    }
  }

  /**
   * Get current user profile
   * GET /api/auth/me
   */
  public static async getCurrentUser(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      // Validate token and get fresh user data
      const user = await AuthService.validateToken(req.headers.authorization?.replace('Bearer ', '') || '');

      logger.info('AuthController: Current user retrieved successfully', { userId });

      res.status(200).json({
        data: user.toPublicJSON(),
        message: 'Current user retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('AuthController: Get current user failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        userId: req.user?.id,
      });
      next(error);
    }
  }

  /**
   * Validate token and get user (used by authentication middleware)
   * GET /api/auth/validate
   */
  public static async validateToken(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const token = req.headers.authorization?.replace('Bearer ', '');

      if (!token) {
        res.status(401).json({
          error: 'Missing token',
          message: 'Authorization token is required',
          code: 'MISSING_TOKEN',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      // Validate token
      const user = await AuthService.validateToken(token);

      res.status(200).json({
        data: {
          valid: true,
          user: user.toPublicJSON(),
        },
        message: 'Token is valid',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('AuthController: Token validation failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
      });
      
      res.status(401).json({
        data: {
          valid: false,
        },
        error: 'Invalid token',
        message: 'Authorization token is invalid or expired',
        code: 'INVALID_TOKEN',
        timestamp: new Date().toISOString(),
      });
    }
  }

  /**
   * Check account status
   * GET /api/auth/account-status
   */
  public static async getAccountStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = req.user?.id;

      if (!userId) {
        res.status(401).json({
          error: 'Unauthorized',
          message: 'User not authenticated',
          code: 'NOT_AUTHENTICATED',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      // Get account status
      const accountStatus = await AuthService.checkAccountStatus(userId);

      logger.info('AuthController: Account status retrieved successfully', { userId, accountStatus });

      res.status(200).json({
        data: accountStatus,
        message: 'Account status retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('AuthController: Get account status failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        userId: req.user?.id,
      });
      next(error);
    }
  }
}

export default AuthController;