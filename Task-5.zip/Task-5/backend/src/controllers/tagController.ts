import { Request, Response, NextFunction } from 'express';
import { TagService, CreateTagData, UpdateTagData } from '../services/tagService';
import { logger } from '../utils/logger';

export class TagController {
  /**
   * Create a new tag
   * POST /api/tags
   * Body: { name: string, description?: string, color?: string }
   */
  public static async createTag(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { name, description, color } = req.body;

      if (!name || typeof name !== 'string' || name.trim().length === 0) {
        res.status(400).json({
          error: 'Invalid tag name',
          message: 'Tag name is required and must be a non-empty string',
          code: 'INVALID_TAG_NAME',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const tagData: CreateTagData = {
        name: name.trim(),
        description: description ? description.trim() : undefined,
        color: color ? color.trim() : undefined,
      };

      const tag = await TagService.createTag(tagData);

      logger.info('TagController: Tag created successfully', {
        tagId: tag.id,
        name: tag.name,
      });

      res.status(201).json({
        data: tag,
        message: 'Tag created successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('TagController: Create tag failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        body: req.body,
      });
      next(error);
    }
  }

  /**
   * Get a tag by ID
   * GET /api/tags/:tagId
   */
  public static async getTagById(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { tagId } = req.params;

      if (!tagId) {
        res.status(400).json({
          error: 'Missing tag ID',
          message: 'Tag ID is required',
          code: 'MISSING_TAG_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const tag = await TagService.getTagById(tagId);

      if (!tag) {
        res.status(404).json({
          error: 'Tag not found',
          message: 'Tag with the specified ID does not exist',
          code: 'TAG_NOT_FOUND',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      logger.info('TagController: Tag retrieved successfully', {
        tagId: tag.id,
        name: tag.name,
      });

      res.status(200).json({
        data: tag,
        message: 'Tag retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('TagController: Get tag by ID failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        tagId: req.params.tagId,
      });
      next(error);
    }
  }

  /**
   * Get a tag by name
   * GET /api/tags/name/:tagName
   */
  public static async getTagByName(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { tagName } = req.params;

      if (!tagName) {
        res.status(400).json({
          error: 'Missing tag name',
          message: 'Tag name is required',
          code: 'MISSING_TAG_NAME',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const tag = await TagService.getTagByName(decodeURIComponent(tagName));

      if (!tag) {
        res.status(404).json({
          error: 'Tag not found',
          message: 'Tag with the specified name does not exist',
          code: 'TAG_NOT_FOUND',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      logger.info('TagController: Tag retrieved by name successfully', {
        tagId: tag.id,
        name: tag.name,
      });

      res.status(200).json({
        data: tag,
        message: 'Tag retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('TagController: Get tag by name failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        tagName: req.params.tagName,
      });
      next(error);
    }
  }

  /**
   * Update a tag
   * PUT /api/tags/:tagId
   * Body: { description?: string, color?: string }
   */
  public static async updateTag(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { tagId } = req.params;
      const { description, color } = req.body;

      if (!tagId) {
        res.status(400).json({
          error: 'Missing tag ID',
          message: 'Tag ID is required',
          code: 'MISSING_TAG_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const updateData: UpdateTagData = {};
      if (description !== undefined) {
        updateData.description = description ? description.trim() : null;
      }
      if (color !== undefined) {
        updateData.color = color ? color.trim() : null;
      }

      if (Object.keys(updateData).length === 0) {
        res.status(400).json({
          error: 'No update data provided',
          message: 'At least one field (description, color) must be provided',
          code: 'NO_UPDATE_DATA',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const tag = await TagService.updateTag(tagId, updateData);

      logger.info('TagController: Tag updated successfully', {
        tagId: tag.id,
        updatedFields: Object.keys(updateData),
      });

      res.status(200).json({
        data: tag,
        message: 'Tag updated successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('TagController: Update tag failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        tagId: req.params.tagId,
        body: req.body,
      });
      next(error);
    }
  }

  /**
   * Deactivate a tag
   * DELETE /api/tags/:tagId
   */
  public static async deactivateTag(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { tagId } = req.params;

      if (!tagId) {
        res.status(400).json({
          error: 'Missing tag ID',
          message: 'Tag ID is required',
          code: 'MISSING_TAG_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      await TagService.deactivateTag(tagId);

      logger.info('TagController: Tag deactivated successfully', {
        tagId,
      });

      res.status(200).json({
        data: { tagId, deactivated: true },
        message: 'Tag deactivated successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('TagController: Deactivate tag failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        tagId: req.params.tagId,
      });
      next(error);
    }
  }

  /**
   * Reactivate a tag
   * POST /api/tags/:tagId/reactivate
   */
  public static async reactivateTag(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { tagId } = req.params;

      if (!tagId) {
        res.status(400).json({
          error: 'Missing tag ID',
          message: 'Tag ID is required',
          code: 'MISSING_TAG_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      await TagService.reactivateTag(tagId);

      logger.info('TagController: Tag reactivated successfully', {
        tagId,
      });

      res.status(200).json({
        data: { tagId, reactivated: true },
        message: 'Tag reactivated successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('TagController: Reactivate tag failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        tagId: req.params.tagId,
      });
      next(error);
    }
  }

  /**
   * Search tags
   * GET /api/tags/search?query=string&page=1&limit=10
   */
  public static async searchTags(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { query, page = '1', limit = '10' } = req.query;

      if (!query || typeof query !== 'string' || query.trim().length === 0) {
        res.status(400).json({
          error: 'Missing search query',
          message: 'Search query is required and must be a non-empty string',
          code: 'MISSING_SEARCH_QUERY',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const pageNum = parseInt(page as string, 10);
      const limitNum = parseInt(limit as string, 10);

      if (isNaN(pageNum) || isNaN(limitNum) || pageNum < 1 || limitNum < 1) {
        res.status(400).json({
          error: 'Invalid pagination parameters',
          message: 'Page and limit must be positive integers',
          code: 'INVALID_PAGINATION',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const offset = (pageNum - 1) * limitNum;

      const result = await TagService.searchTags({
        query: query.trim(),
        limit: limitNum,
        offset,
      });

      const totalPages = Math.ceil(result.total / limitNum);
      const pagination = {
        currentPage: pageNum,
        totalPages,
        totalItems: result.total,
        itemsPerPage: limitNum,
        hasNextPage: pageNum < totalPages,
        hasPreviousPage: pageNum > 1,
      };

      logger.info('TagController: Tags searched successfully', {
        query: query.trim(),
        page: pageNum,
        limit: limitNum,
        count: result.tags.length,
        total: result.total,
      });

      res.status(200).json({
        data: {
          tags: result.tags,
          pagination,
        },
        message: 'Tags searched successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('TagController: Search tags failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        query: req.query,
      });
      next(error);
    }
  }

  /**
   * Get trending tags
   * GET /api/tags/trending?timeframe=week&limit=10
   */
  public static async getTrendingTags(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { timeframe = 'week', limit = '10' } = req.query;

      const limitNum = parseInt(limit as string, 10);

      if (isNaN(limitNum) || limitNum < 1 || limitNum > 100) {
        res.status(400).json({
          error: 'Invalid limit parameter',
          message: 'Limit must be a positive integer between 1 and 100',
          code: 'INVALID_LIMIT',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const validTimeframes = ['day', 'week', 'month'];
      if (!validTimeframes.includes(timeframe as string)) {
        res.status(400).json({
          error: 'Invalid timeframe',
          message: 'Timeframe must be one of: day, week, month',
          code: 'INVALID_TIMEFRAME',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const tags = await TagService.getTrendingTags({
        timeframe: timeframe as 'day' | 'week' | 'month',
        limit: limitNum,
      });

      logger.info('TagController: Trending tags retrieved successfully', {
        timeframe,
        limit: limitNum,
        count: tags.length,
      });

      res.status(200).json({
        data: tags,
        message: 'Trending tags retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('TagController: Get trending tags failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        query: req.query,
      });
      next(error);
    }
  }

  /**
   * Get popular tags
   * GET /api/tags/popular?limit=10&minPostCount=1&sortBy=postsCount&sortOrder=DESC
   */
  public static async getPopularTags(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { 
        limit = '10', 
        minPostCount = '1', 
        sortBy = 'postsCount', 
        sortOrder = 'DESC' 
      } = req.query;

      const limitNum = parseInt(limit as string, 10);
      const minPostCountNum = parseInt(minPostCount as string, 10);

      if (isNaN(limitNum) || limitNum < 1 || limitNum > 100) {
        res.status(400).json({
          error: 'Invalid limit parameter',
          message: 'Limit must be a positive integer between 1 and 100',
          code: 'INVALID_LIMIT',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (isNaN(minPostCountNum) || minPostCountNum < 0) {
        res.status(400).json({
          error: 'Invalid minPostCount parameter',
          message: 'MinPostCount must be a non-negative integer',
          code: 'INVALID_MIN_POST_COUNT',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const validSortBy = ['name', 'postsCount', 'createdAt'];
      const validSortOrder = ['ASC', 'DESC'];

      if (!validSortBy.includes(sortBy as string)) {
        res.status(400).json({
          error: 'Invalid sortBy parameter',
          message: 'SortBy must be one of: name, postsCount, createdAt',
          code: 'INVALID_SORT_BY',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (!validSortOrder.includes(sortOrder as string)) {
        res.status(400).json({
          error: 'Invalid sortOrder parameter',
          message: 'SortOrder must be one of: ASC, DESC',
          code: 'INVALID_SORT_ORDER',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const tags = await TagService.getPopularTags({
        limit: limitNum,
        minPostCount: minPostCountNum,
        sortBy: sortBy as 'name' | 'postsCount' | 'createdAt',
        sortOrder: sortOrder as 'ASC' | 'DESC',
      });

      logger.info('TagController: Popular tags retrieved successfully', {
        limit: limitNum,
        minPostCount: minPostCountNum,
        sortBy,
        sortOrder,
        count: tags.length,
      });

      res.status(200).json({
        data: tags,
        message: 'Popular tags retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('TagController: Get popular tags failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        query: req.query,
      });
      next(error);
    }
  }

  /**
   * Get recent tags
   * GET /api/tags/recent?limit=10&days=7
   */
  public static async getRecentTags(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { limit = '10', days = '7' } = req.query;

      const limitNum = parseInt(limit as string, 10);
      const daysNum = parseInt(days as string, 10);

      if (isNaN(limitNum) || limitNum < 1 || limitNum > 100) {
        res.status(400).json({
          error: 'Invalid limit parameter',
          message: 'Limit must be a positive integer between 1 and 100',
          code: 'INVALID_LIMIT',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (isNaN(daysNum) || daysNum < 1) {
        res.status(400).json({
          error: 'Invalid days parameter',
          message: 'Days must be a positive integer',
          code: 'INVALID_DAYS',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const tags = await TagService.getRecentTags({
        limit: limitNum,
        days: daysNum,
      });

      logger.info('TagController: Recent tags retrieved successfully', {
        limit: limitNum,
        days: daysNum,
        count: tags.length,
      });

      res.status(200).json({
        data: tags,
        message: 'Recent tags retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('TagController: Get recent tags failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        query: req.query,
      });
      next(error);
    }
  }

  /**
   * Get all tags with pagination
   * GET /api/tags?page=1&limit=10&sortBy=name&sortOrder=ASC&minPostCount=0
   */
  public static async getAllTags(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { 
        page = '1', 
        limit = '10', 
        sortBy = 'name', 
        sortOrder = 'ASC',
        minPostCount = '0'
      } = req.query;

      const pageNum = parseInt(page as string, 10);
      const limitNum = parseInt(limit as string, 10);
      const minPostCountNum = parseInt(minPostCount as string, 10);

      if (isNaN(pageNum) || isNaN(limitNum) || pageNum < 1 || limitNum < 1) {
        res.status(400).json({
          error: 'Invalid pagination parameters',
          message: 'Page and limit must be positive integers',
          code: 'INVALID_PAGINATION',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (isNaN(minPostCountNum) || minPostCountNum < 0) {
        res.status(400).json({
          error: 'Invalid minPostCount parameter',
          message: 'MinPostCount must be a non-negative integer',
          code: 'INVALID_MIN_POST_COUNT',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const validSortBy = ['name', 'postsCount', 'createdAt'];
      const validSortOrder = ['ASC', 'DESC'];

      if (!validSortBy.includes(sortBy as string)) {
        res.status(400).json({
          error: 'Invalid sortBy parameter',
          message: 'SortBy must be one of: name, postsCount, createdAt',
          code: 'INVALID_SORT_BY',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      if (!validSortOrder.includes(sortOrder as string)) {
        res.status(400).json({
          error: 'Invalid sortOrder parameter',
          message: 'SortOrder must be one of: ASC, DESC',
          code: 'INVALID_SORT_ORDER',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const offset = (pageNum - 1) * limitNum;

      const result = await TagService.getAllTags({
        limit: limitNum,
        offset,
        sortBy: sortBy as 'name' | 'postsCount' | 'createdAt',
        sortOrder: sortOrder as 'ASC' | 'DESC',
        minPostCount: minPostCountNum,
      });

      const totalPages = Math.ceil(result.total / limitNum);
      const pagination = {
        currentPage: pageNum,
        totalPages,
        totalItems: result.total,
        itemsPerPage: limitNum,
        hasNextPage: pageNum < totalPages,
        hasPreviousPage: pageNum > 1,
      };

      logger.info('TagController: All tags retrieved successfully', {
        page: pageNum,
        limit: limitNum,
        sortBy,
        sortOrder,
        minPostCount: minPostCountNum,
        count: result.tags.length,
        total: result.total,
      });

      res.status(200).json({
        data: {
          tags: result.tags,
          pagination,
        },
        message: 'Tags retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('TagController: Get all tags failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        query: req.query,
      });
      next(error);
    }
  }

  /**
   * Get posts by tag
   * GET /api/tags/:tagName/posts?page=1&limit=10&sortBy=createdAt&sortOrder=DESC
   */
  public static async getPostsByTag(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { tagName } = req.params;
      const { 
        page = '1', 
        limit = '10', 
        sortBy = 'createdAt', 
        sortOrder = 'DESC' 
      } = req.query;

      if (!tagName) {
        res.status(400).json({
          error: 'Missing tag name',
          message: 'Tag name is required',
          code: 'MISSING_TAG_NAME',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const pageNum = parseInt(page as string, 10);
      const limitNum = parseInt(limit as string, 10);

      if (isNaN(pageNum) || isNaN(limitNum) || pageNum < 1 || limitNum < 1) {
        res.status(400).json({
          error: 'Invalid pagination parameters',
          message: 'Page and limit must be positive integers',
          code: 'INVALID_PAGINATION',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      // Note: Sorting is handled internally by the TagService

      const offset = (pageNum - 1) * limitNum;

      const result = await TagService.getPostsByTag(decodeURIComponent(tagName), {
        limit: limitNum,
        offset,
        includeUser: true,
        includeTags: true,
      });

      const totalPages = Math.ceil(result.total / limitNum);
      const pagination = {
        currentPage: pageNum,
        totalPages,
        totalItems: result.total,
        itemsPerPage: limitNum,
        hasNextPage: pageNum < totalPages,
        hasPreviousPage: pageNum > 1,
      };

      logger.info('TagController: Posts by tag retrieved successfully', {
        tagName: decodeURIComponent(tagName),
        page: pageNum,
        limit: limitNum,
        sortBy,
        sortOrder,
        count: result.posts.length,
        total: result.total,
      });

      res.status(200).json({
        data: {
          posts: result.posts,
          pagination,
        },
        message: 'Posts retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('TagController: Get posts by tag failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        tagName: req.params.tagName,
        query: req.query,
      });
      next(error);
    }
  }

  /**
   * Get related tags
   * GET /api/tags/:tagName/related?limit=10
   */
  public static async getRelatedTags(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { tagName } = req.params;
      const { limit = '10' } = req.query;

      if (!tagName) {
        res.status(400).json({
          error: 'Missing tag name',
          message: 'Tag name is required',
          code: 'MISSING_TAG_NAME',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const limitNum = parseInt(limit as string, 10);

      if (isNaN(limitNum) || limitNum < 1 || limitNum > 50) {
        res.status(400).json({
          error: 'Invalid limit parameter',
          message: 'Limit must be a positive integer between 1 and 50',
          code: 'INVALID_LIMIT',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const tags = await TagService.getRelatedTags(decodeURIComponent(tagName), {
        limit: limitNum,
      });

      logger.info('TagController: Related tags retrieved successfully', {
        tagName: decodeURIComponent(tagName),
        limit: limitNum,
        count: tags.length,
      });

      res.status(200).json({
        data: tags,
        message: 'Related tags retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('TagController: Get related tags failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        tagName: req.params.tagName,
        query: req.query,
      });
      next(error);
    }
  }

  /**
   * Get tag statistics
   * GET /api/tags/:tagId/stats
   */
  public static async getTagStats(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { tagId } = req.params;

      if (!tagId) {
        res.status(400).json({
          error: 'Missing tag ID',
          message: 'Tag ID is required',
          code: 'MISSING_TAG_ID',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const stats = await TagService.getTagStats(tagId);

      logger.info('TagController: Tag stats retrieved successfully', {
        tagId,
        stats,
      });

      res.status(200).json({
        data: stats,
        message: 'Tag statistics retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('TagController: Get tag stats failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        tagId: req.params.tagId,
      });
      next(error);
    }
  }

  /**
   * Get tag analytics
   * GET /api/tags/analytics?timeframe=week&limit=20
   */
  public static async getTagAnalytics(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { timeframe = 'week', limit = '20' } = req.query;

      const limitNum = parseInt(limit as string, 10);

      if (isNaN(limitNum) || limitNum < 1 || limitNum > 100) {
        res.status(400).json({
          error: 'Invalid limit parameter',
          message: 'Limit must be a positive integer between 1 and 100',
          code: 'INVALID_LIMIT',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const validTimeframes = ['day', 'week', 'month'];
      if (!validTimeframes.includes(timeframe as string)) {
        res.status(400).json({
          error: 'Invalid timeframe',
          message: 'Timeframe must be one of: day, week, month',
          code: 'INVALID_TIMEFRAME',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const analytics = await TagService.getTagAnalytics({
        timeframe: timeframe as 'day' | 'week' | 'month',
        limit: limitNum,
      });

      logger.info('TagController: Tag analytics retrieved successfully', {
        timeframe,
        limit: limitNum,
        analyticsKeys: Object.keys(analytics),
      });

      res.status(200).json({
        data: analytics,
        message: 'Tag analytics retrieved successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('TagController: Get tag analytics failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        query: req.query,
      });
      next(error);
    }
  }

  /**
   * Find or create tags by names (bulk operation)
   * POST /api/tags/find-or-create
   * Body: { names: string[] }
   */
  public static async findOrCreateTags(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { names } = req.body;

      if (!names || !Array.isArray(names) || names.length === 0) {
        res.status(400).json({
          error: 'Invalid tag names',
          message: 'Names must be a non-empty array of strings',
          code: 'INVALID_TAG_NAMES',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      // Validate all names are strings
      const invalidNames = names.filter(name => typeof name !== 'string' || name.trim().length === 0);
      if (invalidNames.length > 0) {
        res.status(400).json({
          error: 'Invalid tag names',
          message: 'All names must be non-empty strings',
          code: 'INVALID_TAG_NAMES',
          timestamp: new Date().toISOString(),
        });
        return;
      }

      const trimmedNames = names.map(name => name.trim());
      const tags = await TagService.findOrCreateTagsByNames(trimmedNames);

      logger.info('TagController: Tags found/created successfully', {
        requestedCount: trimmedNames.length,
        returnedCount: tags.length,
        names: trimmedNames,
      });

      res.status(200).json({
        data: tags,
        message: 'Tags found/created successfully',
        timestamp: new Date().toISOString(),
      });
    } catch (error) {
      logger.error('TagController: Find/create tags failed', {
        error: error instanceof Error ? error.message : 'Unknown error',
        body: req.body,
      });
      next(error);
    }
  }
}

export default TagController;