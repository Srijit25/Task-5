import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { logger } from '../utils/logger';

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string;
          username: string;
          email: string;
          first_name: string | null;
          last_name: string | null;
          bio: string | null;
          profile_picture_url: string | null;
          is_verified: boolean;
          is_active: boolean;
          is_deleted: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          username: string;
          email: string;
          first_name?: string | null;
          last_name?: string | null;
          bio?: string | null;
          profile_picture_url?: string | null;
          is_verified?: boolean;
          is_active?: boolean;
          is_deleted?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          username?: string;
          email?: string;
          first_name?: string | null;
          last_name?: string | null;
          bio?: string | null;
          profile_picture_url?: string | null;
          is_verified?: boolean;
          is_active?: boolean;
          is_deleted?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      posts: {
        Row: {
          id: string;
          user_id: string;
          content: string | null;
          media_urls: string[] | null;
          location: string | null;
          visibility: 'public' | 'private' | 'friends';
          allow_comments: boolean;
          allow_likes: boolean;
          likes_count: number;
          comments_count: number;
          views_count: number;
          shares_count: number;
          is_deleted: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          content?: string | null;
          media_urls?: string[] | null;
          location?: string | null;
          visibility?: 'public' | 'private' | 'friends';
          allow_comments?: boolean;
          allow_likes?: boolean;
          likes_count?: number;
          comments_count?: number;
          views_count?: number;
          shares_count?: number;
          is_deleted?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          content?: string | null;
          media_urls?: string[] | null;
          location?: string | null;
          visibility?: 'public' | 'private' | 'friends';
          allow_comments?: boolean;
          allow_likes?: boolean;
          likes_count?: number;
          comments_count?: number;
          views_count?: number;
          shares_count?: number;
          is_deleted?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      comments: {
        Row: {
          id: string;
          post_id: string;
          user_id: string;
          parent_comment_id: string | null;
          content: string;
          like_count: number;
          reply_count: number;
          is_deleted: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          post_id: string;
          user_id: string;
          parent_comment_id?: string | null;
          content: string;
          like_count?: number;
          reply_count?: number;
          is_deleted?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          post_id?: string;
          user_id?: string;
          parent_comment_id?: string | null;
          content?: string;
          like_count?: number;
          reply_count?: number;
          is_deleted?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      likes: {
        Row: {
          id: string;
          user_id: string;
          post_id: string | null;
          comment_id: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          post_id?: string | null;
          comment_id?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          post_id?: string | null;
          comment_id?: string | null;
          created_at?: string;
        };
      };
      tags: {
        Row: {
          id: string;
          name: string;
          description: string | null;
          post_count: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          description?: string | null;
          post_count?: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          description?: string | null;
          post_count?: number;
          created_at?: string;
        };
      };
      post_tags: {
        Row: {
          post_id: string;
          tag_id: string;
          created_at: string;
        };
        Insert: {
          post_id: string;
          tag_id: string;
          created_at?: string;
        };
        Update: {
          post_id?: string;
          tag_id?: string;
          created_at?: string;
        };
      };
      follows: {
        Row: {
          follower_id: string;
          following_id: string;
          created_at: string;
        };
        Insert: {
          follower_id: string;
          following_id: string;
          created_at?: string;
        };
        Update: {
          follower_id?: string;
          following_id?: string;
          created_at?: string;
        };
      };
      notifications: {
        Row: {
          id: string;
          user_id: string;
          actor_id: string;
          type: string;
          post_id: string | null;
          comment_id: string | null;
          message: string | null;
          is_read: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          actor_id: string;
          type: string;
          post_id?: string | null;
          comment_id?: string | null;
          message?: string | null;
          is_read?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          actor_id?: string;
          type?: string;
          post_id?: string | null;
          comment_id?: string | null;
          message?: string | null;
          is_read?: boolean;
          created_at?: string;
        };
      };
    };
  };
}

// Configuration
const supabaseConfig = {
  url: process.env.SUPABASE_URL!,
  anonKey: process.env.SUPABASE_ANON_KEY!,
  serviceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY!,
};

// Validate required environment variables
const validateConfig = (): void => {
  const requiredVars = ['SUPABASE_URL', 'SUPABASE_ANON_KEY', 'SUPABASE_SERVICE_ROLE_KEY'];
  const missingVars = requiredVars.filter(varName => !process.env[varName]);
  
  if (missingVars.length > 0) {
    throw new Error(`Missing required Supabase environment variables: ${missingVars.join(', ')}`);
  }
};

// Create Supabase clients
let supabaseClient: SupabaseClient<Database>;
let supabaseAdmin: SupabaseClient<Database>;

export const initializeSupabase = (): void => {
  try {
    validateConfig();
    
    // Client for regular operations (uses anon key with RLS)
    supabaseClient = createClient<Database>(
      supabaseConfig.url,
      supabaseConfig.anonKey,
      {
        auth: {
          autoRefreshToken: true,
          persistSession: false, // We'll handle sessions manually
        },
      }
    );

    // Admin client for operations that bypass RLS
    supabaseAdmin = createClient<Database>(
      supabaseConfig.url,
      supabaseConfig.serviceRoleKey,
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      }
    );

    logger.info('Supabase clients initialized successfully');
  } catch (error) {
    logger.error('Failed to initialize Supabase clients:', error);
    throw error;
  }
};

// Test connection
export const testSupabaseConnection = async (): Promise<void> => {
  try {
    if (!supabaseAdmin) {
      throw new Error('Supabase not initialized');
    }

    // Test with a simple query
    const { data, error } = await supabaseAdmin
      .from('users')
      .select('count(*)', { count: 'exact', head: true });

    if (error) {
      throw error;
    }

    logger.info('Supabase connection test successful');
  } catch (error) {
    logger.error('Supabase connection test failed:', error);
    throw error;
  }
};

// Get regular client (with RLS)
export const getSupabaseClient = (): SupabaseClient<Database> => {
  if (!supabaseClient) {
    throw new Error('Supabase client not initialized. Call initializeSupabase() first.');
  }
  return supabaseClient;
};

// Get admin client (bypasses RLS)
export const getSupabaseAdmin = (): SupabaseClient<Database> => {
  if (!supabaseAdmin) {
    throw new Error('Supabase admin client not initialized. Call initializeSupabase() first.');
  }
  return supabaseAdmin;
};

// Helper to create user session for requests
export const createUserClient = (accessToken: string): SupabaseClient<Database> => {
  return createClient<Database>(
    supabaseConfig.url,
    supabaseConfig.anonKey,
    {
      global: {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      },
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    }
  );
};

export { supabaseClient, supabaseAdmin };
export default getSupabaseClient;