import AWS from 'aws-sdk';
import multer from 'multer';
import multerS3 from 'multer-s3';
import { Request } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { logger } from '../utils/logger';

const s3Config: AWS.S3.ClientConfiguration = {
  region: process.env.AWS_REGION || 'us-east-1',
};

if (process.env.AWS_ACCESS_KEY_ID) {
  s3Config.accessKeyId = process.env.AWS_ACCESS_KEY_ID;
}

if (process.env.AWS_SECRET_ACCESS_KEY) {
  s3Config.secretAccessKey = process.env.AWS_SECRET_ACCESS_KEY;
}

// Initialize S3 client
const s3 = new AWS.S3(s3Config);

// S3 bucket configuration
const BUCKET_NAME = process.env.AWS_S3_BUCKET_NAME || 'social-media-uploads';
const CLOUDFRONT_URL = process.env.AWS_CLOUDFRONT_URL || '';

// File type validation
const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
const ALLOWED_VIDEO_TYPES = ['video/mp4', 'video/webm', 'video/ogg'];
const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB
const MAX_IMAGE_SIZE = 10 * 1024 * 1024; // 10MB

// S3 folder structure
const S3_FOLDERS = {
  PROFILE_IMAGES: 'profiles/',
  POST_IMAGES: 'posts/images/',
  POST_VIDEOS: 'posts/videos/',
  THUMBNAILS: 'thumbnails/',
} as const;

// File upload configuration for profile images
export const profileImageUpload = multer({
  storage: multerS3({
    s3: s3 as any,
    bucket: BUCKET_NAME,
    acl: 'public-read',
    contentType: multerS3.AUTO_CONTENT_TYPE,
    key: (req: Request, file: Express.Multer.File, cb: (error: any, key?: string) => void) => {
      const userId = req.user?.id || 'anonymous';
      const fileExtension = file.originalname.split('.').pop();
      const fileName = `${S3_FOLDERS.PROFILE_IMAGES}${userId}-${uuidv4()}.${fileExtension}`;
      cb(null, fileName);
    },
  }),
  fileFilter: (req: Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
    if (ALLOWED_IMAGE_TYPES.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPEG, PNG, GIF, and WebP images are allowed.'));
    }
  },
  limits: {
    fileSize: MAX_IMAGE_SIZE,
  },
});

// File upload configuration for post media
export const postMediaUpload = multer({
  storage: multerS3({
    s3: s3 as any,
    bucket: BUCKET_NAME,
    acl: 'public-read',
    contentType: multerS3.AUTO_CONTENT_TYPE,
    key: (req: Request, file: Express.Multer.File, cb: (error: any, key?: string) => void) => {
      const userId = req.user?.id || 'anonymous';
      const fileExtension = file.originalname.split('.').pop();
      const isVideo = ALLOWED_VIDEO_TYPES.includes(file.mimetype);
      const folder = isVideo ? S3_FOLDERS.POST_VIDEOS : S3_FOLDERS.POST_IMAGES;
      const fileName = `${folder}${userId}-${uuidv4()}.${fileExtension}`;
      cb(null, fileName);
    },
  }),
  fileFilter: (req: Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
    const allowedTypes = [...ALLOWED_IMAGE_TYPES, ...ALLOWED_VIDEO_TYPES];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only images (JPEG, PNG, GIF, WebP) and videos (MP4, WebM, OGG) are allowed.'));
    }
  },
  limits: {
    fileSize: MAX_FILE_SIZE,
  },
});

// S3 utility functions
export class S3Service {
  static async uploadFile(
    buffer: Buffer,
    key: string,
    contentType: string,
    metadata?: Record<string, string>
  ): Promise<AWS.S3.ManagedUpload.SendData> {
    try {
      const params: AWS.S3.PutObjectRequest = {
        Bucket: BUCKET_NAME,
        Key: key,
        Body: buffer,
        ContentType: contentType,
        ACL: 'public-read',
        ...(metadata && { Metadata: metadata }),
      };

      const result = await s3.upload(params).promise();
      logger.info(`File uploaded to S3: ${key}`);
      return result;
    } catch (error) {
      logger.error(`S3 upload error for key ${key}:`, error);
      throw error;
    }
  }

  static async deleteFile(key: string): Promise<void> {
    try {
      const params: AWS.S3.DeleteObjectRequest = {
        Bucket: BUCKET_NAME,
        Key: key,
      };

      await s3.deleteObject(params).promise();
      logger.info(`File deleted from S3: ${key}`);
    } catch (error) {
      logger.error(`S3 delete error for key ${key}:`, error);
      throw error;
    }
  }

  static async getSignedUrl(key: string, expires: number = 3600): Promise<string> {
    try {
      const params = {
        Bucket: BUCKET_NAME,
        Key: key,
        Expires: expires,
      };

      const url = await s3.getSignedUrlPromise('getObject', params);
      return url;
    } catch (error) {
      logger.error(`S3 signed URL error for key ${key}:`, error);
      throw error;
    }
  }

  static async copyFile(sourceKey: string, destinationKey: string): Promise<void> {
    try {
      const params: AWS.S3.CopyObjectRequest = {
        Bucket: BUCKET_NAME,
        CopySource: `${BUCKET_NAME}/${sourceKey}`,
        Key: destinationKey,
        ACL: 'public-read',
      };

      await s3.copyObject(params).promise();
      logger.info(`File copied from ${sourceKey} to ${destinationKey}`);
    } catch (error) {
      logger.error(`S3 copy error from ${sourceKey} to ${destinationKey}:`, error);
      throw error;
    }
  }

  static async listFiles(prefix: string, maxKeys: number = 1000): Promise<AWS.S3.ListObjectsV2Output> {
    try {
      const params: AWS.S3.ListObjectsV2Request = {
        Bucket: BUCKET_NAME,
        Prefix: prefix,
        MaxKeys: maxKeys,
      };

      const result = await s3.listObjectsV2(params).promise();
      return result;
    } catch (error) {
      logger.error(`S3 list error for prefix ${prefix}:`, error);
      throw error;
    }
  }

  static getPublicUrl(key: string): string {
    if (CLOUDFRONT_URL) {
      return `${CLOUDFRONT_URL}/${key}`;
    }
    return `https://${BUCKET_NAME}.s3.${s3Config.region}.amazonaws.com/${key}`;
  }

  static extractKeyFromUrl(url: string): string | null {
    try {
      if (url.includes(CLOUDFRONT_URL)) {
        return url.replace(`${CLOUDFRONT_URL}/`, '');
      }

      const s3UrlPattern = new RegExp(`https://${BUCKET_NAME}\\.s3\\.[^/]+\\.amazonaws\\.com/(.+)`);
      const match = url.match(s3UrlPattern);
      return match && match[1] ? match[1] : null;
    } catch (error) {
      logger.error(`Error extracting S3 key from URL ${url}:`, error);
      return null;
    }
  }

  static generateThumbnailKey(originalKey: string): string {
    const pathParts = originalKey.split('/');
    const fileName = pathParts.pop();
    const nameWithoutExt = fileName?.split('.')[0];
    return `${S3_FOLDERS.THUMBNAILS}${nameWithoutExt}-thumb.jpg`;
  }
}

// File validation utilities
export const validateFileType = (file: Express.Multer.File): boolean => {
  const allowedTypes = [...ALLOWED_IMAGE_TYPES, ...ALLOWED_VIDEO_TYPES];
  return allowedTypes.includes(file.mimetype);
};

export const validateFileSize = (file: Express.Multer.File): boolean => {
  if (ALLOWED_IMAGE_TYPES.includes(file.mimetype)) {
    return file.size <= MAX_IMAGE_SIZE;
  }
  return file.size <= MAX_FILE_SIZE;
};

export const getFileType = (mimetype: string): 'image' | 'video' | 'unknown' => {
  if (ALLOWED_IMAGE_TYPES.includes(mimetype)) return 'image';
  if (ALLOWED_VIDEO_TYPES.includes(mimetype)) return 'video';
  return 'unknown';
};

// Error handling for multer
export const handleMulterError = (error: any): string => {
  if (error instanceof multer.MulterError) {
    switch (error.code) {
      case 'LIMIT_FILE_SIZE':
        return 'File size too large. Maximum size allowed is 50MB for videos and 10MB for images.';
      case 'LIMIT_FILE_COUNT':
        return 'Too many files uploaded.';
      case 'LIMIT_UNEXPECTED_FILE':
        return 'Unexpected file field.';
      default:
        return 'File upload error occurred.';
    }
  }
  return error.message || 'Unknown upload error occurred.';
};

export default {
  s3,
  S3Service,
  profileImageUpload,
  postMediaUpload,
  S3_FOLDERS,
  ALLOWED_IMAGE_TYPES,
  ALLOWED_VIDEO_TYPES,
  MAX_FILE_SIZE,
  MAX_IMAGE_SIZE,
};