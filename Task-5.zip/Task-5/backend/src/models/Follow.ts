import { FollowEntity } from '../types/database';
import { FollowRepository } from '../repositories/FollowRepository';

export interface FollowAttributes {
  id: string;
  followerId: string;
  followedId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface FollowCreationAttributes {
  followerId: string;
  followedId: string;
}

/**
 * Follow model with Supabase backend
 * Maintains Sequelize-compatible interface for backward compatibility
 */
export class Follow {
  public id!: string;
  public followerId!: string;
  public followedId!: string;
  public readonly createdAt!: Date;
  public readonly updatedAt!: Date;

  private static repository = new FollowRepository();

  constructor(data: FollowEntity) {
    this.id = data.id;
    this.followerId = data.follower_id;
    this.followedId = data.followed_id;
    this.createdAt = new Date(data.created_at);
    this.updatedAt = new Date(data.updated_at);
  }

  /**
   * Convert to JSON representation
   */
  toJSON(): FollowAttributes {
    return {
      id: this.id,
      followerId: this.followerId,
      followedId: this.followedId,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt,
    };
  }

  /**
   * Create a new follow relationship
   */
  static async create(data: FollowCreationAttributes): Promise<Follow> {
    const followEntity = await this.repository.followUser(data.followerId, data.followedId);
    return new Follow(followEntity);
  }

  /**
   * Find follow by ID
   */
  static async findByPk(id: string): Promise<Follow | null> {
    // For now, we'll use a workaround since BaseRepository's findById is protected
    try {
      const { data, error } = await this.repository['supabase'] || this.repository['adminClient']
        ? (this.repository as any).adminClient
          .from('follows')
          .select('*')
          .eq('id', id)
          .single()
        : null;

      if (error && error.code !== 'PGRST116') throw error;
      return data ? new Follow(data) : null;
    } catch (error) {
      // Fallback: check all follows for this ID
      const allFollows = await this.repository.findAll({ limit: 1000 });
      const follow = allFollows.data.find((f: FollowEntity) => f.id === id);
      return follow ? new Follow(follow) : null;
    }
  }

  /**
   * Find one follow relationship
   */
  static async findOne(options: {
    where: Partial<{
      id: string;
      followerId: string;
      followedId: string;
    }>;
  }): Promise<Follow | null> {
    const { where } = options;
    
    if (where.id) {
      return await this.findByPk(where.id);
    }
    
    if (where.followerId && where.followedId) {
      const followEntity = await this.repository.getFollow(where.followerId, where.followedId);
      return followEntity ? new Follow(followEntity) : null;
    }

    // For other queries, use findAll and return first result
    const follows = await this.findAll({ where, limit: 1 });
    return follows.length > 0 ? (follows[0] || null) : null;
  }

  /**
   * Find all follow relationships
   */
  static async findAll(options: {
    where?: Partial<{
      followerId: string;
      followedId: string;
    }>;
    limit?: number;
    offset?: number;
    order?: [string, 'ASC' | 'DESC'][];
    include?: any[];
  } = {}): Promise<Follow[]> {
    const { where = {}, limit = 20, offset = 0 } = options;
    
    if (where.followedId) {
      // Get followers
      const { data } = await this.repository.getFollowers(where.followedId, { limit, offset });
      return data.map((followEntity: FollowEntity) => new Follow(followEntity));
    }
    
    if (where.followerId) {
      // Get following
      const { data } = await this.repository.getFollowing(where.followerId, { limit, offset });
      return data.map((followEntity: FollowEntity) => new Follow(followEntity));
    }

    // Generic query - get all follows with pagination
    const allFollows = await this.repository.findAll({ limit, offset });
    return allFollows.data.map((followEntity: FollowEntity) => new Follow(followEntity));
  }

  /**
   * Count follow relationships
   */
  static async count(options: {
    where?: Partial<{
      followerId: string;
      followedId: string;
    }>;
  } = {}): Promise<number> {
    const { where = {} } = options;
    
    if (where.followedId) {
      return await this.repository.getFollowerCount(where.followedId);
    }
    
    if (where.followerId) {
      return await this.repository.getFollowingCount(where.followerId);
    }

    // Generic count
    const allFollows = await this.repository.findAll({ limit: 1 });
    return allFollows.total;
  }

  /**
   * Check if user is following another user
   */
  static async isFollowing(followerId: string, followedId: string): Promise<boolean> {
    return await this.repository.isFollowing(followerId, followedId);
  }

  /**
   * Toggle follow relationship
   */
  static async toggle(followerId: string, followedId: string): Promise<{
    isFollowing: boolean;
    follow?: Follow;
  }> {
    const result = await this.repository.toggleFollow(followerId, followedId);
    
    return {
      isFollowing: result.isFollowing,
      ...(result.follow ? { follow: new Follow(result.follow) } : {}),
    };
  }

  /**
   * Get follow statistics for a user
   */
  static async getStats(userId: string): Promise<{
    followerCount: number;
    followingCount: number;
  }> {
    return await this.repository.getFollowStats(userId);
  }

  /**
   * Get followers with user details
   */
  static async getFollowersWithDetails(
    userId: string,
    options: { limit?: number; offset?: number } = {}
  ) {
    return await this.repository.getFollowers(userId, options);
  }

  /**
   * Get following with user details
   */
  static async getFollowingWithDetails(
    userId: string,
    options: { limit?: number; offset?: number } = {}
  ) {
    return await this.repository.getFollowing(userId, options);
  }

  /**
   * Get mutual following between two users
   */
  static async getMutualFollowing(userId1: string, userId2: string): Promise<string[]> {
    return await this.repository.getMutualFollowing(userId1, userId2);
  }

  /**
   * Get follow suggestions for a user
   */
  static async getSuggestions(userId: string, limit = 10): Promise<string[]> {
    return await this.repository.getFollowSuggestions(userId, limit);
  }

  /**
   * Bulk follow check
   */
  static async bulkFollowCheck(
    followerId: string,
    userIds: string[]
  ): Promise<Record<string, boolean>> {
    return await this.repository.bulkFollowCheck(followerId, userIds);
  }

  /**
   * Delete follow relationship
   */
  async destroy(): Promise<void> {
    await Follow.repository.unfollowUser(this.followerId, this.followedId);
  }

  /**
   * Delete follow relationship by criteria
   */
  static async destroy(options: {
    where: {
      followerId: string;
      followedId: string;
    };
  }): Promise<void> {
    const { where } = options;
    await this.repository.unfollowUser(where.followerId, where.followedId);
  }

  /**
   * Remove follower (for blocking functionality)
   */
  static async removeFollower(userId: string, followerId: string): Promise<void> {
    await this.repository.removeFollower(userId, followerId);
  }
}