import { PostRepository } from '../repositories/PostRepository';
import { PostEntity, CreatePostData, UpdatePostData, PostFilters } from '../types/database';
import { logger } from '../utils/logger';

// Singleton repository instance
const postRepository = new PostRepository();

export interface PostAttributes extends PostEntity {}

export interface PostCreationAttributes extends CreatePostData {}

/**
 * Post model - Supabase implementation with Sequelize-compatible interface
 */
export class Post {
  public id!: string;
  public user_id!: string;
  public content?: string | null;
  public media_urls?: string[] | null;
  public location?: string | null;
  public visibility!: 'public' | 'private' | 'friends';
  public allow_comments!: boolean;
  public allow_likes!: boolean;
  public likes_count!: number;
  public comments_count!: number;
  public views_count!: number;
  public shares_count!: number;
  public is_deleted!: boolean;
  public created_at!: string;
  public updated_at!: string;

  // Legacy properties for backward compatibility
  public get userId(): string { return this.user_id; }
  public set userId(value: string) { this.user_id = value; }
  public get mediaUrls(): string[] | null { return this.media_urls || null; }
  public set mediaUrls(value: string[] | null | undefined) { 
    this.media_urls = value === undefined ? null : value; 
  }
  public get allowComments(): boolean { return this.allow_comments; }
  public set allowComments(value: boolean) { this.allow_comments = value; }
  public get allowLikes(): boolean { return this.allow_likes; }
  public set allowLikes(value: boolean) { this.allow_likes = value; }
  public get likesCount(): number { return this.likes_count; }
  public set likesCount(value: number) { this.likes_count = value; }
  public get commentsCount(): number { return this.comments_count; }
  public set commentsCount(value: number) { this.comments_count = value; }
  public get viewsCount(): number { return this.views_count; }
  public set viewsCount(value: number) { this.views_count = value; }
  public get sharesCount(): number { return this.shares_count; }
  public set sharesCount(value: number) { this.shares_count = value; }
  public get isDeleted(): boolean { return this.is_deleted; }
  public set isDeleted(value: boolean) { this.is_deleted = value; }
  public get createdAt(): Date { return new Date(this.created_at); }
  public set createdAt(value: Date) { this.created_at = value.toISOString(); }
  public get updatedAt(): Date { return new Date(this.updated_at); }
  public set updatedAt(value: Date) { this.updated_at = value.toISOString(); }

  // Association properties for compatibility
  public user?: any;
  public tags?: any[];

  constructor(data: PostEntity) {
    Object.assign(this, data);
  }

  /**
   * Create a new post
   */
  static async create(postData: CreatePostData): Promise<Post> {
    try {
      const post = await postRepository.createPost(postData);
      return new Post(post);
    } catch (error) {
      logger.error('Error creating post:', error);
      throw error;
    }
  }

  /**
   * Find post by primary key
   */
  static async findByPk(id: string): Promise<Post | null> {
    try {
      const post = await postRepository.getPostById(id, true);
      return post ? new Post(post) : null;
    } catch (error) {
      logger.error(`Error finding post by PK ${id}:`, error);
      throw error;
    }
  }

  /**
   * Find one post
   */
  static async findOne(options: { 
    where: Record<string, any>;
    include?: any[];
  }): Promise<Post | null> {
    try {
      const { where } = options;
      
      if (where.id) {
        const post = await postRepository.getPostById(where.id, true);
        return post ? new Post(post) : null;
      }

      // For other filters, use general search with single result
      if (where.user_id || where.userId) {
        const result = await postRepository.getPostsByUserId(where.user_id || where.userId, {
          limit: 1,
          includeUser: true,
        });
        return result.data.length > 0 && result.data[0] ? new Post(result.data[0]) : null;
      }

      return null;
    } catch (error) {
      logger.error('Error finding post:', error);
      throw error;
    }
  }

  /**
   * Find all posts
   */
  static async findAll(options: { 
    where?: Record<string, any>;
    limit?: number;
    offset?: number;
    order?: [string, string][];
    include?: any[];
  } = {}): Promise<Post[]> {
    try {
      const { where = {}, limit = 20, offset = 0, order, include } = options;
      
      // Handle ordering
      let sortBy = 'created_at';
      let sortOrder: 'asc' | 'desc' = 'desc';
      if (order && order.length > 0 && order[0]) {
        const [sortColumn, sortDir] = order[0];
        sortBy = sortColumn === 'createdAt' ? 'created_at' : sortColumn;
        sortOrder = sortDir.toLowerCase() as 'asc' | 'desc';
      }

      let result;
      if (where.user_id || where.userId) {
        result = await postRepository.getPostsByUserId(where.user_id || where.userId, {
          limit,
          offset,
          includeUser: true,
        });
      } else {
        result = await postRepository.getFeedPosts({
          limit,
          offset,
        });
      }

      return result.data.map(post => new Post(post));
    } catch (error) {
      logger.error('Error finding all posts:', error);
      throw error;
    }
  }

  /**
   * Find and count all
   */
  static async findAndCountAll(options: { 
    where?: Record<string, any>;
    limit?: number;
    offset?: number;
    order?: [string, string][];
    include?: any[];
  } = {}): Promise<{ rows: Post[]; count: number }> {
    try {
      const { where = {}, limit = 20, offset = 0, order, include } = options;
      
      // Handle ordering
      let sortBy = 'created_at';
      let sortOrder: 'asc' | 'desc' = 'desc';
      if (order && order.length > 0 && order[0]) {
        const [sortColumn, sortDir] = order[0];
        sortBy = sortColumn === 'createdAt' ? 'created_at' : sortColumn;
        sortOrder = sortDir.toLowerCase() as 'asc' | 'desc';
      }

      let result;
      if (where.user_id || where.userId) {
        result = await postRepository.getPostsByUserId(where.user_id || where.userId, {
          limit,
          offset,
          includeUser: true,
        });
      } else {
        result = await postRepository.getFeedPosts({
          limit,
          offset,
        });
      }

      return {
        rows: result.data.map(post => new Post(post)),
        count: result.total,
      };
    } catch (error) {
      logger.error('Error finding and counting posts:', error);
      throw error;
    }
  }

  /**
   * Update post instance
   */
  async update(data: UpdatePostData): Promise<Post> {
    try {
      const updated = await postRepository.updatePost(this.id, data);
      Object.assign(this, updated);
      return this;
    } catch (error) {
      logger.error(`Error updating post ${this.id}:`, error);
      throw error;
    }
  }

  /**
   * Delete post instance (soft delete)
   */
  async destroy(): Promise<void> {
    try {
      await postRepository.deletePost(this.id);
      this.is_deleted = true;
    } catch (error) {
      logger.error(`Error deleting post ${this.id}:`, error);
      throw error;
    }
  }

  /**
   * Save post instance
   */
  async save(): Promise<Post> {
    try {
      if (this.id) {
        return await this.update(this);
      } else {
        // Create new post - extract only creation fields
        const createData: CreatePostData = {
          user_id: this.user_id,
          content: this.content === undefined ? null : this.content,
          media_urls: this.media_urls === undefined ? null : this.media_urls,
          location: this.location === undefined ? null : this.location,
          visibility: this.visibility,
          allow_comments: this.allow_comments,
          allow_likes: this.allow_likes,
        };
        const created = await Post.create(createData);
        Object.assign(this, created);
        return this;
      }
    } catch (error) {
      logger.error('Error saving post:', error);
      throw error;
    }
  }

  /**
   * Reload post instance
   */
  async reload(): Promise<Post> {
    try {
      const updated = await postRepository.getPostById(this.id, true);
      if (updated) {
        Object.assign(this, updated);
      }
      return this;
    } catch (error) {
      logger.error(`Error reloading post ${this.id}:`, error);
      throw error;
    }
  }

  // Instance methods for compatibility
  public hasContent(): boolean {
    return !!(this.content && this.content.trim().length > 0);
  }

  public hasMedia(): boolean {
    return !!(this.media_urls && this.media_urls.length > 0);
  }

  public isValidPost(): boolean {
    return this.hasContent() || this.hasMedia();
  }

  public getMediaCount(): number {
    return this.media_urls ? this.media_urls.length : 0;
  }

  public addMediaUrl(url: string): void {
    if (!this.media_urls) {
      this.media_urls = [];
    }
    this.media_urls.push(url);
  }

  public removeMediaUrl(url: string): void {
    if (this.media_urls) {
      this.media_urls = this.media_urls.filter(mediaUrl => mediaUrl !== url);
    }
  }

  public toPublicJSON(): Partial<PostEntity> {
    const { is_deleted, ...publicPost } = this.toJSON();
    return publicPost;
  }

  /**
   * Static methods
   */
  static async findActiveById(id: string): Promise<Post | null> {
    try {
      const post = await postRepository.getPostById(id, true);
      return post && !post.is_deleted ? new Post(post) : null;
    } catch (error) {
      logger.error(`Error finding active post by ID ${id}:`, error);
      throw error;
    }
  }

  static async findByUserId(userId: string, options: { 
    limit?: number; 
    offset?: number; 
    includeDeleted?: boolean; 
  } = {}): Promise<Post[]> {
    try {
      const result = await postRepository.getPostsByUserId(userId, {
        ...options,
        includeUser: true,
      });
      return result.data.map(post => new Post(post));
    } catch (error) {
      logger.error(`Error finding posts by user ID ${userId}:`, error);
      throw error;
    }
  }

  static async getFeedPosts(options: {
    limit?: number;
    offset?: number;
    userIds?: string[];
  } = {}): Promise<{ posts: Post[]; total: number }> {
    try {
      const result = await postRepository.getFeedPosts(options);
      return {
        posts: result.data.map(post => new Post(post)),
        total: result.total,
      };
    } catch (error) {
      logger.error('Error getting feed posts:', error);
      throw error;
    }
  }

  static async searchPosts(query: string, options: {
    limit?: number;
    offset?: number;
  } = {}): Promise<{ posts: Post[]; total: number }> {
    try {
      const result = await postRepository.searchPosts(query, options);
      return {
        posts: result.data.map(post => new Post(post)),
        total: result.total,
      };
    } catch (error) {
      logger.error(`Error searching posts with query "${query}":`, error);
      throw error;
    }
  }

  static async getPostsByLocation(location: string, options: {
    limit?: number;
    offset?: number;
  } = {}): Promise<{ posts: Post[]; total: number }> {
    try {
      const result = await postRepository.getPostsByLocation(location, options);
      return {
        posts: result.data.map(post => new Post(post)),
        total: result.total,
      };
    } catch (error) {
      logger.error(`Error getting posts by location "${location}":`, error);
      throw error;
    }
  }

  static async getPopularPosts(options: {
    limit?: number;
    offset?: number;
    timeframe?: 'day' | 'week' | 'month' | 'all';
  } = {}): Promise<{ posts: Post[]; total: number }> {
    try {
      const result = await postRepository.getPopularPosts(options);
      return {
        posts: result.data.map(post => new Post(post)),
        total: result.total,
      };
    } catch (error) {
      logger.error('Error getting popular posts:', error);
      throw error;
    }
  }

  // Tag association methods (compatibility)
  public async getTags(): Promise<any[]> {
    try {
      const postsWithTags = await postRepository.getPostsWithTags([this.id]);
      return postsWithTags.length > 0 && postsWithTags[0] ? postsWithTags[0].tags : [];
    } catch (error) {
      logger.error(`Error getting tags for post ${this.id}:`, error);
      return [];
    }
  }

  public async setTags(tags: any[]): Promise<void> {
    try {
      const tagIds = tags.map(tag => tag.id || tag);
      await postRepository.setTagsForPost(this.id, tagIds);
    } catch (error) {
      logger.error(`Error setting tags for post ${this.id}:`, error);
      throw error;
    }
  }

  public async addTag(tag: any): Promise<void> {
    try {
      const tagId = tag.id || tag;
      await postRepository.addTagToPost(this.id, tagId);
    } catch (error) {
      logger.error(`Error adding tag to post ${this.id}:`, error);
      throw error;
    }
  }

  public async removeTag(tag: any): Promise<void> {
    try {
      const tagId = tag.id || tag;
      await postRepository.removeTagFromPost(this.id, tagId);
    } catch (error) {
      logger.error(`Error removing tag from post ${this.id}:`, error);
      throw error;
    }
  }

  // Counter methods
  async incrementLikesCount(): Promise<void> {
    try {
      await postRepository.incrementLikesCount(this.id);
      this.likes_count += 1;
    } catch (error) {
      logger.error(`Error incrementing likes count for post ${this.id}:`, error);
      throw error;
    }
  }

  async decrementLikesCount(): Promise<void> {
    try {
      await postRepository.decrementLikesCount(this.id);
      this.likes_count = Math.max(0, this.likes_count - 1);
    } catch (error) {
      logger.error(`Error decrementing likes count for post ${this.id}:`, error);
      throw error;
    }
  }

  async incrementCommentsCount(): Promise<void> {
    try {
      await postRepository.incrementCommentsCount(this.id);
      this.comments_count += 1;
    } catch (error) {
      logger.error(`Error incrementing comments count for post ${this.id}:`, error);
      throw error;
    }
  }

  async decrementCommentsCount(): Promise<void> {
    try {
      await postRepository.decrementCommentsCount(this.id);
      this.comments_count = Math.max(0, this.comments_count - 1);
    } catch (error) {
      logger.error(`Error decrementing comments count for post ${this.id}:`, error);
      throw error;
    }
  }

  async incrementViewsCount(): Promise<void> {
    try {
      await postRepository.incrementViewsCount(this.id);
      this.views_count += 1;
    } catch (error) {
      logger.error(`Error incrementing views count for post ${this.id}:`, error);
      throw error;
    }
  }

  async incrementSharesCount(): Promise<void> {
    try {
      await postRepository.incrementSharesCount(this.id);
      this.shares_count += 1;
    } catch (error) {
      logger.error(`Error incrementing shares count for post ${this.id}:`, error);
      throw error;
    }
  }

  /**
   * Convert to JSON
   */
  toJSON(): PostEntity {
    return {
      id: this.id,
      user_id: this.user_id,
      content: this.content === undefined ? null : this.content,
      media_urls: this.media_urls === undefined ? null : this.media_urls,
      location: this.location === undefined ? null : this.location,
      visibility: this.visibility,
      allow_comments: this.allow_comments,
      allow_likes: this.allow_likes,
      likes_count: this.likes_count,
      comments_count: this.comments_count,
      views_count: this.views_count,
      shares_count: this.shares_count,
      is_deleted: this.is_deleted,
      created_at: this.created_at,
      updated_at: this.updated_at,
    };
  }

  // Static utility methods
  static async getUserPostStats(userId: string): Promise<{
    totalPosts: number;
    totalLikes: number;
    totalComments: number;
    totalViews: number;
    totalShares: number;
  }> {
    try {
      return await postRepository.getUserPostStats(userId);
    } catch (error) {
      logger.error(`Error getting post stats for user ${userId}:`, error);
      throw error;
    }
  }

  isOwner(userId: string): boolean {
    return this.user_id === userId;
  }

  canUserComment(userId: string): boolean {
    return this.allow_comments && (this.visibility === 'public' || this.isOwner(userId));
  }

  canUserLike(userId: string): boolean {
    return this.allow_likes && (this.visibility === 'public' || this.isOwner(userId));
  }
}

export default Post;