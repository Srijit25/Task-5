import { CommentEntity, CreateCommentData, UpdateCommentData, CommentFilters } from '../types/database';
import { logger } from '../utils/logger';

// Define interface for the repository implementation
export interface ICommentRepository {
  createComment(data: any): Promise<any>;
  getCommentById(id: string, includeUser?: boolean): Promise<any | null>;
  updateComment(id: string, data: any, useAdmin?: boolean): Promise<any>;
  getCommentsByPostId(postId: string, options?: any): Promise<{ data: any[]; total: number }>;
  getCommentsByUserId(userId: string, options?: any): Promise<{ data: any[]; total: number }>;
  getReplies(parentId: string, options?: any): Promise<{ data: any[]; total: number }>;
  searchComments(query: string, options?: any): Promise<{ data: any[]; total: number }>;
  getPopularComments(options?: any): Promise<{ data: any[]; total: number }>;
  getCommentThread(commentId: string, options?: any): Promise<any | null>;
  deleteComment(id: string): Promise<void>;
  commentExists(id: string): Promise<boolean>;
  getUserCommentStats(userId: string): Promise<any>;
  incrementLikeCount(commentId: string): Promise<void>;
  decrementLikeCount(commentId: string): Promise<void>;
  incrementReplyCount(commentId: string): Promise<void>;
  decrementReplyCount(commentId: string): Promise<void>;
}

// Singleton repository instance
let commentRepository: any;

try {
  const CommentRepositoryClass = require('../repositories/CommentRepository').CommentRepository;
  commentRepository = new CommentRepositoryClass();
} catch (error) {
  console.warn('CommentRepository not found, using mock implementation:', error);
  commentRepository = {
    createComment: async () => ({ id: 'mock', content: 'mock' }),
    getCommentById: async () => null,
    updateComment: async () => ({ id: 'mock' }),
    getCommentsByPostId: async () => ({ data: [], total: 0 }),
    getCommentsByUserId: async () => ({ data: [], total: 0 }),
    getReplies: async () => ({ data: [], total: 0 }),
    searchComments: async () => ({ data: [], total: 0 }),
    getPopularComments: async () => ({ data: [], total: 0 }),
    getCommentThread: async () => null,
    deleteComment: async () => {},
    commentExists: async () => false,
    getUserCommentStats: async () => ({ totalComments: 0, totalLikes: 0, totalReplies: 0 }),
    incrementLikeCount: async () => {},
    decrementLikeCount: async () => {},
    incrementReplyCount: async () => {},
    decrementReplyCount: async () => {},
  };
}

export interface CommentAttributes extends CommentEntity {}

export interface CommentCreationAttributes extends CreateCommentData {}

/**
 * Comment model - Supabase implementation with Sequelize-compatible interface
 */
export class Comment {
  public id!: string;
  public post_id!: string;
  public user_id!: string;
  public parent_comment_id?: string | null;
  public content!: string;
  public like_count!: number;
  public reply_count!: number;
  public is_deleted!: boolean;
  public created_at!: string;
  public updated_at!: string;

  // Legacy properties for backward compatibility
  public get postId(): string { return this.post_id; }
  public set postId(value: string) { this.post_id = value; }
  public get userId(): string { return this.user_id; }
  public set userId(value: string) { this.user_id = value; }
  public get parentId(): string | null | undefined { return this.parent_comment_id; }
  public set parentId(value: string | null | undefined) { 
    this.parent_comment_id = value === undefined ? null : value; 
  }
  public get likesCount(): number { return this.like_count; }
  public set likesCount(value: number) { this.like_count = value; }
  public get repliesCount(): number { return this.reply_count; }
  public set repliesCount(value: number) { this.reply_count = value; }
  public get isDeleted(): boolean { return this.is_deleted; }
  public set isDeleted(value: boolean) { this.is_deleted = value; }
  public get createdAt(): Date { return new Date(this.created_at); }
  public set createdAt(value: Date) { this.created_at = value.toISOString(); }
  public get updatedAt(): Date { return new Date(this.updated_at); }
  public set updatedAt(value: Date) { this.updated_at = value.toISOString(); }

  // Association properties for compatibility
  public user?: any;
  public post?: any;
  public parentComment?: Comment;
  public replies?: Comment[];

  constructor(data: CommentEntity) {
    Object.assign(this, data);
  }

  /**
   * Create a new comment
   */
  static async create(commentData: CreateCommentData): Promise<Comment> {
    try {
      const comment = await commentRepository.createComment(commentData);
      return new Comment(comment);
    } catch (error) {
      logger.error('Error creating comment:', error);
      throw error;
    }
  }

  /**
   * Find comment by primary key
   */
  static async findByPk(id: string): Promise<Comment | null> {
    try {
      const comment = await commentRepository.getCommentById(id, true);
      return comment ? new Comment(comment) : null;
    } catch (error) {
      logger.error(`Error finding comment by PK ${id}:`, error);
      throw error;
    }
  }

  /**
   * Find one comment
   */
  static async findOne(options: { 
    where: Record<string, any>;
    include?: any[];
  }): Promise<Comment | null> {
    try {
      const { where } = options;
      
      if (where.id) {
        const comment = await commentRepository.getCommentById(where.id, true);
        return comment ? new Comment(comment) : null;
      }

      // For other filters, use specific methods
      if (where.post_id || where.postId) {
        const result = await commentRepository.getCommentsByPostId(where.post_id || where.postId, {
          limit: 1,
          includeUser: true,
        });
        return result.data.length > 0 && result.data[0] ? new Comment(result.data[0]) : null;
      }

      return null;
    } catch (error) {
      logger.error('Error finding comment:', error);
      throw error;
    }
  }

  /**
   * Find all comments
   */
  static async findAll(options: { 
    where?: Record<string, any>;
    limit?: number;
    offset?: number;
    order?: [string, string][];
    include?: any[];
  } = {}): Promise<Comment[]> {
    try {
      const { where = {}, limit = 20, offset = 0, order, include } = options;
      
      let result;
      if (where.post_id || where.postId) {
        result = await commentRepository.getCommentsByPostId(where.post_id || where.postId, {
          limit,
          offset,
          includeUser: true,
          parentId: where.parent_comment_id || where.parentId || null,
        });
      } else if (where.user_id || where.userId) {
        result = await commentRepository.getCommentsByUserId(where.user_id || where.userId, {
          limit,
          offset,
          includeUser: true,
        });
      } else {
        // Default: get recent comments across all posts
        result = await commentRepository.getPopularComments({
          limit,
          offset,
          includeUser: true,
        });
      }

      return result.data.map((comment: any) => new Comment(comment));
    } catch (error) {
      logger.error('Error finding all comments:', error);
      throw error;
    }
  }

  /**
   * Find and count all
   */
  static async findAndCountAll(options: { 
    where?: Record<string, any>;
    limit?: number;
    offset?: number;
    order?: [string, string][];
    include?: any[];
  } = {}): Promise<{ rows: Comment[]; count: number }> {
    try {
      const { where = {}, limit = 20, offset = 0, order, include } = options;
      
      let result;
      if (where.post_id || where.postId) {
        result = await commentRepository.getCommentsByPostId(where.post_id || where.postId, {
          limit,
          offset,
          includeUser: true,
          parentId: where.parent_comment_id || where.parentId || null,
        });
      } else if (where.user_id || where.userId) {
        result = await commentRepository.getCommentsByUserId(where.user_id || where.userId, {
          limit,
          offset,
          includeUser: true,
        });
      } else {
        result = await commentRepository.getPopularComments({
          limit,
          offset,
          includeUser: true,
        });
      }

      return {
        rows: result.data.map((comment: any) => new Comment(comment)),
        count: result.total,
      };
    } catch (error) {
      logger.error('Error finding and counting comments:', error);
      throw error;
    }
  }

  /**
   * Update comment instance
   */
  async update(data: UpdateCommentData): Promise<Comment> {
    try {
      const updated = await commentRepository.updateComment(this.id, data);
      Object.assign(this, updated);
      return this;
    } catch (error) {
      logger.error(`Error updating comment ${this.id}:`, error);
      throw error;
    }
  }

  /**
   * Delete comment instance (soft delete)
   */
  async destroy(): Promise<void> {
    try {
      await commentRepository.deleteComment(this.id);
      this.is_deleted = true;
    } catch (error) {
      logger.error(`Error deleting comment ${this.id}:`, error);
      throw error;
    }
  }

  /**
   * Save comment instance
   */
  async save(): Promise<Comment> {
    try {
      if (this.id) {
        return await this.update(this);
      } else {
        // Create new comment - extract only creation fields
        const createData: CreateCommentData = {
          post_id: this.post_id,
          user_id: this.user_id,
          parent_comment_id: this.parent_comment_id === undefined ? null : this.parent_comment_id,
          content: this.content,
        };
        const created = await Comment.create(createData);
        Object.assign(this, created);
        return this;
      }
    } catch (error) {
      logger.error('Error saving comment:', error);
      throw error;
    }
  }

  /**
   * Reload comment instance
   */
  async reload(): Promise<Comment> {
    try {
      const updated = await commentRepository.getCommentById(this.id, true);
      if (updated) {
        Object.assign(this, updated);
      }
      return this;
    } catch (error) {
      logger.error(`Error reloading comment ${this.id}:`, error);
      throw error;
    }
  }

  // Instance methods for compatibility
  public isReply(): boolean {
    return !!this.parent_comment_id;
  }

  public isTopLevel(): boolean {
    return !this.parent_comment_id;
  }

  public getDepthLevel(): number {
    // For now, simple implementation (0 = top level, 1 = reply)
    return this.parent_comment_id ? 1 : 0;
  }

  public toPublicJSON(): Partial<CommentEntity> {
    const { is_deleted, ...publicComment } = this.toJSON();
    return publicComment;
  }

  /**
   * Static methods
   */
  static async findActiveById(id: string): Promise<Comment | null> {
    try {
      const comment = await commentRepository.getCommentById(id, true);
      return comment && !comment.is_deleted ? new Comment(comment) : null;
    } catch (error) {
      logger.error(`Error finding active comment by ID ${id}:`, error);
      throw error;
    }
  }

  static async findByPostId(postId: string, options: {
    limit?: number;
    offset?: number;
    includeReplies?: boolean;
    parentId?: string | null;
  } = {}): Promise<{ comments: Comment[]; total: number }> {
    try {
      const result = await commentRepository.getCommentsByPostId(postId, {
        ...options,
        includeUser: true,
      });
      return {
        comments: result.data.map((comment: any) => new Comment(comment)),
        total: result.total,
      };
    } catch (error) {
      logger.error(`Error finding comments by post ID ${postId}:`, error);
      throw error;
    }
  }

  static async findReplies(parentId: string, options: {
    limit?: number;
    offset?: number;
  } = {}): Promise<{ comments: Comment[]; total: number }> {
    try {
      const result = await commentRepository.getReplies(parentId, {
        ...options,
        includeUser: true,
      });
      return {
        comments: result.data.map((comment: any) => new Comment(comment)),
        total: result.total,
      };
    } catch (error) {
      logger.error(`Error finding replies for comment ${parentId}:`, error);
      throw error;
    }
  }

  static async searchComments(query: string, options: {
    limit?: number;
    offset?: number;
    postId?: string;
  } = {}): Promise<{ comments: Comment[]; total: number }> {
    try {
      const result = await commentRepository.searchComments(query, {
        ...options,
        includeUser: true,
      });
      return {
        comments: result.data.map((comment: any) => new Comment(comment)),
        total: result.total,
      };
    } catch (error) {
      logger.error(`Error searching comments with query "${query}":`, error);
      throw error;
    }
  }

  static async getPopularComments(options: {
    limit?: number;
    offset?: number;
    postId?: string;
    timeframe?: 'day' | 'week' | 'month' | 'all';
  } = {}): Promise<{ comments: Comment[]; total: number }> {
    try {
      const result = await commentRepository.getPopularComments({
        ...options,
        includeUser: true,
      });
      return {
        comments: result.data.map((comment: any) => new Comment(comment)),
        total: result.total,
      };
    } catch (error) {
      logger.error('Error getting popular comments:', error);
      throw error;
    }
  }

  // Counter methods
  async incrementLikeCount(): Promise<void> {
    try {
      await commentRepository.incrementLikeCount(this.id);
      this.like_count += 1;
    } catch (error) {
      logger.error(`Error incrementing like count for comment ${this.id}:`, error);
      throw error;
    }
  }

  async decrementLikeCount(): Promise<void> {
    try {
      await commentRepository.decrementLikeCount(this.id);
      this.like_count = Math.max(0, this.like_count - 1);
    } catch (error) {
      logger.error(`Error decrementing like count for comment ${this.id}:`, error);
      throw error;
    }
  }

  async incrementReplyCount(): Promise<void> {
    try {
      await commentRepository.incrementReplyCount(this.id);
      this.reply_count += 1;
    } catch (error) {
      logger.error(`Error incrementing reply count for comment ${this.id}:`, error);
      throw error;
    }
  }

  async decrementReplyCount(): Promise<void> {
    try {
      await commentRepository.decrementReplyCount(this.id);
      this.reply_count = Math.max(0, this.reply_count - 1);
    } catch (error) {
      logger.error(`Error decrementing reply count for comment ${this.id}:`, error);
      throw error;
    }
  }

  /**
   * Get comment thread
   */
  async getThread(options: {
    maxDepth?: number;
  } = {}): Promise<Comment> {
    try {
      const thread = await commentRepository.getCommentThread(this.id, {
        ...options,
        includeUser: true,
      });
      return thread ? new Comment(thread) : this;
    } catch (error) {
      logger.error(`Error getting thread for comment ${this.id}:`, error);
      return this;
    }
  }

  /**
   * Convert to JSON
   */
  toJSON(): CommentEntity {
    return {
      id: this.id,
      post_id: this.post_id,
      user_id: this.user_id,
      parent_comment_id: this.parent_comment_id === undefined ? null : this.parent_comment_id,
      content: this.content,
      like_count: this.like_count,
      reply_count: this.reply_count,
      is_deleted: this.is_deleted,
      created_at: this.created_at,
      updated_at: this.updated_at,
    };
  }

  // Static utility methods
  static async getUserCommentStats(userId: string): Promise<{
    totalComments: number;
    totalLikes: number;
    totalReplies: number;
  }> {
    try {
      return await commentRepository.getUserCommentStats(userId);
    } catch (error) {
      logger.error(`Error getting comment stats for user ${userId}:`, error);
      throw error;
    }
  }

  static async commentExists(commentId: string): Promise<boolean> {
    try {
      return await commentRepository.commentExists(commentId);
    } catch (error) {
      logger.error(`Error checking if comment exists ${commentId}:`, error);
      return false;
    }
  }

  isOwner(userId: string): boolean {
    return this.user_id === userId;
  }

  canEdit(userId: string): boolean {
    return this.isOwner(userId) && !this.is_deleted;
  }

  canDelete(userId: string): boolean {
    return this.isOwner(userId) && !this.is_deleted;
  }
}

export default Comment;