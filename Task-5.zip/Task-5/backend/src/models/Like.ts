import { LikeEntity } from '../types/database';
import { LikeRepository } from '../repositories/LikeRepository';

export interface LikeAttributes {
  id: string;
  userId: string;
  targetId: string; // Can be post or comment ID
  targetType: 'post' | 'comment';
  createdAt: Date;
  updatedAt: Date;
}

export interface LikeCreationAttributes {
  userId: string;
  targetId: string;
  targetType: 'post' | 'comment';
}

/**
 * Like model with Supabase backend
 * Maintains Sequelize-compatible interface for backward compatibility
 */
export class Like {
  public id!: string;
  public userId!: string;
  public targetId!: string;
  public targetType!: 'post' | 'comment';
  public readonly createdAt!: Date;
  public readonly updatedAt!: Date;

  private static repository = new LikeRepository();

  constructor(data: LikeEntity) {
    this.id = data.id;
    this.userId = data.user_id;
    this.targetId = data.target_id;
    this.targetType = data.target_type;
    this.createdAt = new Date(data.created_at);
    this.updatedAt = new Date(data.updated_at);
  }

  /**
   * Convert to JSON representation
   */
  toJSON(): LikeAttributes {
    return {
      id: this.id,
      userId: this.userId,
      targetId: this.targetId,
      targetType: this.targetType,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt,
    };
  }

  /**
   * Create a new like
   */
  static async create(data: LikeCreationAttributes): Promise<Like> {
    const likeData = {
      user_id: data.userId,
      target_id: data.targetId,
      target_type: data.targetType,
    };
    
    const likeEntity = await this.repository.createLike(likeData);
    return new Like(likeEntity);
  }

  /**
   * Find like by ID
   */
  static async findByPk(id: string): Promise<Like | null> {
    const likeEntity = await this.repository.getLikeById(id);
    return likeEntity ? new Like(likeEntity) : null;
  }

  /**
   * Find one like
   */
  static async findOne(options: {
    where: Partial<{
      userId: string;
      targetId: string;
      targetType: 'post' | 'comment';
    }>;
  }): Promise<Like | null> {
    const { where } = options;
    
    if (where.userId && where.targetId && where.targetType) {
      const likeEntity = await this.repository.getLike(
        where.userId,
        where.targetId,
        where.targetType
      );
      return likeEntity ? new Like(likeEntity) : null;
    }

    // For other queries, use the base findAll and return first result
    const likes = await this.findAll({ where, limit: 1 });
    return likes.length > 0 ? likes[0] || null : null;
  }

  /**
   * Find all likes
   */
  static async findAll(options: {
    where?: Partial<{
      userId: string;
      targetId: string;
      targetType: 'post' | 'comment';
    }>;
    limit?: number;
    offset?: number;
    order?: [string, 'ASC' | 'DESC'][];
  } = {}): Promise<Like[]> {
    const { where = {}, limit = 20, offset = 0, order } = options;
    
    let sortBy: 'created_at' | 'updated_at' = 'created_at';
    let sortOrder: 'asc' | 'desc' = 'desc';
    
    if (order && order.length > 0) {
      const [field, direction] = order?.[0] || ['created_at', 'DESC'];
      if (field === 'createdAt' || field === 'created_at') {
        sortBy = 'created_at';
      } else if (field === 'updatedAt' || field === 'updated_at') {
        sortBy = 'updated_at';
      }
      sortOrder = direction.toLowerCase() as 'asc' | 'desc';
    }

    const { data } = await this.repository.getLikes({
      userId: where.userId,
      targetId: where.targetId,
      targetType: where.targetType,
      limit,
      offset,
      sortBy,
      sortOrder,
    });

    return data.map(likeEntity => new Like(likeEntity));
  }

  /**
   * Count likes
   */
  static async count(options: {
    where?: Partial<{
      userId: string;
      targetId: string;
      targetType: 'post' | 'comment';
    }>;
  } = {}): Promise<number> {
    const { where = {} } = options;
    
    if (where.targetId && where.targetType) {
      return await this.repository.getLikeCount(where.targetId, where.targetType);
    }
    
    if (where.userId) {
      const stats = await this.repository.getUserLikeStats(where.userId);
      return stats.totalLikesGiven;
    }

    // Generic count - get all and count
    const { total } = await this.repository.getLikes({ limit: 1 });
    return total;
  }

  /**
   * Toggle like
   */
  static async toggle(
    userId: string,
    targetId: string,
    targetType: 'post' | 'comment'
  ): Promise<{ liked: boolean; like?: Like }> {
    const result = await this.repository.toggleLike(userId, targetId, targetType);
    
    return {
      liked: result.liked,
      ...(result.like && { like: new Like(result.like) }),
    };
  }

  /**
   * Delete/unlike
   */
  async destroy(): Promise<void> {
    await Like.repository.deleteLike(this.id);
  }

  /**
   * Delete like by criteria
   */
  static async destroy(options: {
    where: {
      userId: string;
      targetId: string;
      targetType: 'post' | 'comment';
    };
  }): Promise<void> {
    const { where } = options;
    await this.repository.unlike(where.userId, where.targetId, where.targetType);
  }

  /**
   * Check if user liked target
   */
  static async hasUserLiked(
    userId: string,
    targetId: string,
    targetType: 'post' | 'comment'
  ): Promise<boolean> {
    return await this.repository.hasUserLiked(userId, targetId, targetType);
  }

  /**
   * Get user's like statistics
   */
  static async getUserStats(userId: string) {
    return await this.repository.getUserLikeStats(userId);
  }
}