import { TagEntity } from '../types/database';
import { TagRepository } from '../repositories/TagRepository';

export interface TagAttributes {
  id: string;
  name: string;
  description?: string;
  color?: string;
  isOfficial: boolean;
  postCount: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface TagCreationAttributes {
  name: string;
  description?: string;
  color?: string;
  isOfficial?: boolean;
}

/**
 * Tag model with Supabase backend
 * Maintains Sequelize-compatible interface for backward compatibility
 */
export class Tag {
  public id!: string;
  public name!: string;
  public description?: string;
  public color?: string;
  public isOfficial!: boolean;
  public postCount!: number;
  public readonly createdAt!: Date;
  public readonly updatedAt!: Date;

  private static repository = new TagRepository();

  constructor(data: TagEntity) {
    this.id = data.id;
    this.name = data.name;
    this.description = data.description || undefined;
    this.color = data.color || undefined;
    this.isOfficial = data.is_official || false;
    this.postCount = data.post_count || 0;
    this.createdAt = new Date(data.created_at);
    this.updatedAt = new Date(data.updated_at);
  }

  /**
   * Convert to JSON representation
   */
  toJSON(): TagAttributes {
    return {
      id: this.id,
      name: this.name,
      description: this.description,
      color: this.color,
      isOfficial: this.isOfficial,
      postCount: this.postCount,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt,
    };
  }

  /**
   * Create a new tag
   */
  static async create(data: TagCreationAttributes): Promise<Tag> {
    const tagData = {
      name: data.name,
      description: data.description || null,
      color: data.color || null,
      is_official: data.isOfficial || false,
    };
    
    const tagEntity = await this.repository.createTag(tagData);
    return new Tag(tagEntity);
  }

  /**
   * Find tag by ID
   */
  static async findByPk(id: string): Promise<Tag | null> {
    const tagEntity = await this.repository.getTagById(id);
    return tagEntity ? new Tag(tagEntity) : null;
  }

  /**
   * Find one tag
   */
  static async findOne(options: {
    where: Partial<{
      id: string;
      name: string;
      isOfficial: boolean;
    }>;
  }): Promise<Tag | null> {
    const { where } = options;
    
    if (where.id) {
      return await this.findByPk(where.id);
    }
    
    if (where.name) {
      const tagEntity = await this.repository.getTagByName(where.name);
      return tagEntity ? new Tag(tagEntity) : null;
    }

    // For other queries, use findAll and return first result
    const tags = await this.findAll({ where, limit: 1 });
    return tags.length > 0 ? tags[0] : null;
  }

  /**
   * Find all tags
   */
  static async findAll(options: {
    where?: Partial<{
      name: string;
      isOfficial: boolean;
    }>;
    limit?: number;
    offset?: number;
    order?: [string, 'ASC' | 'DESC'][];
  } = {}): Promise<Tag[]> {
    const { where = {}, limit = 20, offset = 0, order } = options;
    
    let sortBy: 'name' | 'post_count' | 'created_at' = 'post_count';
    let sortOrder: 'asc' | 'desc' = 'desc';
    
    if (order && order.length > 0) {
      const [field, direction] = order[0];
      if (field === 'name') {
        sortBy = 'name';
      } else if (field === 'postCount' || field === 'post_count') {
        sortBy = 'post_count';
      } else if (field === 'createdAt' || field === 'created_at') {
        sortBy = 'created_at';
      }
      sortOrder = direction.toLowerCase() as 'asc' | 'desc';
    }

    const { data } = await this.repository.getTags({
      limit,
      offset,
      sortBy,
      sortOrder,
    });

    // Filter in memory for now (could be optimized with database filters)
    let filteredData = data;
    if (where.isOfficial !== undefined) {
      filteredData = data.filter(tag => tag.is_official === where.isOfficial);
    }
    if (where.name) {
      filteredData = filteredData.filter(tag => 
        tag.name.toLowerCase().includes(where.name!.toLowerCase())
      );
    }

    return filteredData.map(tagEntity => new Tag(tagEntity));
  }

  /**
   * Count tags
   */
  static async count(options: {
    where?: Partial<{
      name: string;
      isOfficial: boolean;
    }>;
  } = {}): Promise<number> {
    const { total } = await this.repository.getTags({ limit: 1 });
    return total;
  }

  /**
   * Search tags
   */
  static async search(query: string, limit = 10): Promise<Tag[]> {
    const tagEntities = await this.repository.searchTags(query, limit);
    return tagEntities.map(tagEntity => new Tag(tagEntity));
  }

  /**
   * Get popular tags
   */
  static async getPopular(limit = 20): Promise<Tag[]> {
    const tagEntities = await this.repository.getPopularTags(limit);
    return tagEntities.map(tagEntity => new Tag(tagEntity));
  }

  /**
   * Update tag
   */
  async update(data: Partial<TagCreationAttributes>): Promise<void> {
    const updateData: any = {};
    
    if (data.name !== undefined) updateData.name = data.name;
    if (data.description !== undefined) updateData.description = data.description;
    if (data.color !== undefined) updateData.color = data.color;
    if (data.isOfficial !== undefined) updateData.is_official = data.isOfficial;

    const updatedEntity = await Tag.repository.updateTag(this.id, updateData);
    
    // Update current instance
    this.name = updatedEntity.name;
    this.description = updatedEntity.description || undefined;
    this.color = updatedEntity.color || undefined;
    this.isOfficial = updatedEntity.is_official || false;
    this.postCount = updatedEntity.post_count || 0;
  }

  /**
   * Delete tag
   */
  async destroy(): Promise<void> {
    await Tag.repository.deleteTag(this.id);
  }

  /**
   * Increment post count
   */
  async incrementPostCount(): Promise<void> {
    await Tag.repository.incrementPostCount(this.id);
    this.postCount += 1;
  }

  /**
   * Decrement post count
   */
  async decrementPostCount(): Promise<void> {
    await Tag.repository.decrementPostCount(this.id);
    this.postCount = Math.max(0, this.postCount - 1);
  }

  /**
   * Check if tag name exists
   */
  static async nameExists(name: string, excludeTagId?: string): Promise<boolean> {
    return await this.repository.tagNameExists(name, excludeTagId);
  }
}