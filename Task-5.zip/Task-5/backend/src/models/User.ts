import { UserRepository } from '../repositories/UserRepository';
import { UserEntity, CreateUserData, UpdateUserData, UserFilters } from '../types/database';
import { logger } from '../utils/logger';

// Singleton repository instance
const userRepository = new UserRepository();

export interface UserAttributes extends UserEntity {}

export interface UserCreationAttributes extends CreateUserData {}

/**
 * User model - Supabase implementation with Sequelize-compatible interface
 */
export class User {
  public id!: string;
  public auth_user_id!: string;
  public username!: string;
  public email!: string;
  public first_name?: string;
  public last_name?: string;
  public bio?: string;
  public profile_picture_url?: string;
  public is_verified!: boolean;
  public is_active!: boolean;
  public is_deleted!: boolean;
  public created_at!: string;
  public updated_at?: string;

  // Legacy properties for backward compatibility
  public get authUserId(): string { return this.auth_user_id; }
  public set authUserId(value: string) { this.auth_user_id = value; }
  public get firstName(): string | undefined { return this.first_name; }
  public set firstName(value: string | undefined) { this.first_name = value; }
  public get lastName(): string | undefined { return this.last_name; }
  public set lastName(value: string | undefined) { this.last_name = value; }
  public get profilePictureUrl(): string | undefined { return this.profile_picture_url; }
  public set profilePictureUrl(value: string | undefined) { this.profile_picture_url = value; }
  public get isVerified(): boolean { return this.is_verified; }
  public set isVerified(value: boolean) { this.is_verified = value; }
  public get isActive(): boolean { return this.is_active; }
  public set isActive(value: boolean) { this.is_active = value; }
  public get isDeleted(): boolean { return this.is_deleted; }
  public set isDeleted(value: boolean) { this.is_deleted = value; }
  public get createdAt(): Date { return new Date(this.created_at); }
  public set createdAt(value: Date) { this.created_at = value.toISOString(); }
  public get updatedAt(): Date | undefined { return this.updated_at ? new Date(this.updated_at) : undefined; }
  public set updatedAt(value: Date | undefined) { this.updated_at = value?.toISOString(); }

  constructor(data: UserEntity) {
    Object.assign(this, data);
  }

  /**
   * Create a new user
   */
  static async create(userData: CreateUserData): Promise<User> {
    try {
      const user = await userRepository.createUser(userData);
      return new User(user);
    } catch (error) {
      logger.error('Error creating user:', error);
      throw error;
    }
  }

  /**
   * Find user by primary key
   */
  static async findByPk(id: string): Promise<User | null> {
    try {
      const user = await userRepository.getUserById(id);
      return user ? new User(user) : null;
    } catch (error) {
      logger.error(`Error finding user by PK ${id}:`, error);
      throw error;
    }
  }

  /**
   * Find one user
   */
  static async findOne(options: {
    where: Record<string, any>;
    include?: any[];
  }): Promise<User | null> {
    try {
      const { where } = options;

      if (where.id) {
        const user = await userRepository.getUserById(where.id);
        return user ? new User(user) : null;
      }

      if (where.auth_user_id || where.authUserId) {
        const user = await userRepository.getUserByAuthId(where.auth_user_id || where.authUserId);
        return user ? new User(user) : null;
      }

      if (where.username) {
        const user = await userRepository.getUserByUsername(where.username);
        return user ? new User(user) : null;
      }

      if (where.email) {
        const user = await userRepository.getUserByEmail(where.email);
        return user ? new User(user) : null;
      }

      return null;
    } catch (error) {
      logger.error('Error finding user:', error);
      throw error;
    }
  }

  /**
   * Find all users
   */
  static async findAll(options: {
    where?: Record<string, any>;
    limit?: number;
    offset?: number;
    order?: [string, string][];
    include?: any[];
  } = {}): Promise<User[]> {
    try {
      const { where = {}, limit = 20, offset = 0, order } = options;

      // Handle ordering
      let sortBy = 'created_at';
      let sortOrder: 'asc' | 'desc' = 'desc';
      if (order && order.length > 0 && order[0]) {
        const [sortColumn, sortDir] = order[0];
        sortBy = sortColumn === 'createdAt' ? 'created_at' : sortColumn;
        sortOrder = sortDir.toLowerCase() as 'asc' | 'desc';
      }

      const result = await userRepository.getUsers({
        limit,
        offset,
        sortBy,
        sortOrder,
        ...where,
      });

      return result.data.map(user => new User(user));
    } catch (error) {
      logger.error('Error finding all users:', error);
      throw error;
    }
  }

  /**
   * Find and count all
   */
  static async findAndCountAll(options: {
    where?: Record<string, any>;
    limit?: number;
    offset?: number;
    order?: [string, string][];
    include?: any[];
  } = {}): Promise<{ rows: User[]; count: number }> {
    try {
      const { where = {}, limit = 20, offset = 0, order } = options;

      // Handle ordering
      let sortBy = 'created_at';
      let sortOrder: 'asc' | 'desc' = 'desc';
      if (order && order.length > 0 && order[0]) {
        const [sortColumn, sortDir] = order[0];
        sortBy = sortColumn === 'createdAt' ? 'created_at' : sortColumn;
        sortOrder = sortDir.toLowerCase() as 'asc' | 'desc';
      }

      const result = await userRepository.getUsers({
        limit,
        offset,
        sortBy,
        sortOrder,
        ...where,
      });

      return {
        rows: result.data.map(user => new User(user)),
        count: result.total,
      };
    } catch (error) {
      logger.error('Error finding and counting users:', error);
      throw error;
    }
  }

  /**
   * Update user instance
   */
  async update(data: UpdateUserData): Promise<User> {
    try {
      const updated = await userRepository.updateUser(this.id, data);
      Object.assign(this, updated);
      return this;
    } catch (error) {
      logger.error(`Error updating user ${this.id}:`, error);
      throw error;
    }
  }

  /**
   * Delete user instance (soft delete)
   */
  async destroy(): Promise<void> {
    try {
      await userRepository.deleteUser(this.id);
      this.is_deleted = true;
    } catch (error) {
      logger.error(`Error deleting user ${this.id}:`, error);
      throw error;
    }
  }

  /**
   * Save user instance
   */
  async save(): Promise<User> {
    try {
      if (this.id) {
        return await this.update(this);
      } else {
        // Create new user - extract only creation fields
        const createData: CreateUserData = {
          auth_user_id: this.auth_user_id,
          username: this.username,
          email: this.email,
          first_name: this.first_name,
          last_name: this.last_name,
          bio: this.bio,
          profile_picture_url: this.profile_picture_url,
        };
        const created = await User.create(createData);
        Object.assign(this, created);
        return this;
      }
    } catch (error) {
      logger.error('Error saving user:', error);
      throw error;
    }
  }

  /**
   * Reload user instance
   */
  async reload(): Promise<User> {
    try {
      const updated = await userRepository.getUserById(this.id);
      if (updated) {
        Object.assign(this, updated);
      }
      return this;
    } catch (error) {
      logger.error(`Error reloading user ${this.id}:`, error);
      throw error;
    }
  }

  // Instance methods for compatibility
  public getFullName(): string {
    const parts = [this.first_name, this.last_name].filter(Boolean);
    return parts.length > 0 ? parts.join(' ') : this.username;
  }

  public getProfileData(): any {
    return {
      id: this.id,
      username: this.username,
      first_name: this.first_name,
      last_name: this.last_name,
      bio: this.bio,
      profile_picture_url: this.profile_picture_url,
      is_verified: this.is_verified,
      created_at: this.created_at,
    };
  }

  public async updateLastActive(): Promise<void> {
    try {
      await userRepository.updateLastActive(this.id);
    } catch (error) {
      logger.warn(`Failed to update last active for user ${this.id}:`, error);
    }
  }

  /**
   * Static methods
   */
  static async findByUsername(username: string): Promise<User | null> {
    try {
      const user = await userRepository.getUserByUsername(username);
      return user ? new User(user) : null;
    } catch (error) {
      logger.error(`Error finding user by username ${username}:`, error);
      throw error;
    }
  }

  static async findByEmail(email: string): Promise<User | null> {
    try {
      const user = await userRepository.getUserByEmail(email);
      return user ? new User(user) : null;
    } catch (error) {
      logger.error(`Error finding user by email ${email}:`, error);
      throw error;
    }
  }

  static async findByAuthId(authUserId: string): Promise<User | null> {
    try {
      const user = await userRepository.getUserByAuthId(authUserId);
      return user ? new User(user) : null;
    } catch (error) {
      logger.error(`Error finding user by auth ID ${authUserId}:`, error);
      throw error;
    }
  }

  static async searchUsers(query: string, options: {
    limit?: number;
    offset?: number;
  } = {}): Promise<User[]> {
    try {
      const users = await userRepository.searchUsers(query, options);
      return users.map(user => new User(user));
    } catch (error) {
      logger.error(`Error searching users with query "${query}":`, error);
      throw error;
    }
  }

  static async usernameExists(username: string, excludeUserId?: string): Promise<boolean> {
    try {
      return await userRepository.usernameExists(username, excludeUserId);
    } catch (error) {
      logger.error(`Error checking username existence for "${username}":`, error);
      throw error;
    }
  }

  static async emailExists(email: string, excludeUserId?: string): Promise<boolean> {
    try {
      return await userRepository.emailExists(email, excludeUserId);
    } catch (error) {
      logger.error(`Error checking email existence for "${email}":`, error);
      throw error;
    }
  }

  static async getUserStats(userId: string): Promise<{
    postsCount: number;
    followersCount: number;
    followingCount: number;
  }> {
    try {
      return await userRepository.getUserStats(userId);
    } catch (error) {
      logger.error(`Error getting stats for user ${userId}:`, error);
      throw error;
    }
  }

  // Utility methods
  public isOwner(userId: string): boolean {
    return this.id === userId;
  }

  public isActiveUser(): boolean {
    return this.is_active && !this.is_deleted;
  }

  /**
   * Convert to JSON
   */
  toJSON(): any {
    return {
      id: this.id,
      auth_user_id: this.auth_user_id,
      username: this.username,
      email: this.email,
      first_name: this.first_name,
      last_name: this.last_name,
      bio: this.bio,
      profile_picture_url: this.profile_picture_url,
      is_verified: this.is_verified,
      is_active: this.is_active,
      is_deleted: this.is_deleted,
      created_at: this.created_at,
      updated_at: this.updated_at,
    };
  }
}

export default User;