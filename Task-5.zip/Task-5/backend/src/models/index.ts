// Export all models for Supabase-based social media app
// Note: These models now use Supabase backend instead of Sequelize

import { User } from './User';
import { Post } from './Post';
import { Comment } from './Comment';
import { Like } from './Like';
import { Tag } from './Tag';
import { Follow } from './Follow';

// Export models
export {
  User,
  Post,
  Comment,
  Like,
  Tag,
  Follow,
};

// For backward compatibility with existing code that expects initializeModelAssociations
export function initializeModelAssociations() {
  // With Supabase, associations are handled at the database level through foreign keys
  // and relationships are managed through repository pattern
  console.log('Model associations are now handled by Supabase foreign key relationships');
}

// For backward compatibility with existing code that expects syncDatabase
export async function syncDatabase() {
  // With Supabase, database schema is managed through migrations
  console.log('Database sync is handled by Supabase migrations');
  return Promise.resolve();
}